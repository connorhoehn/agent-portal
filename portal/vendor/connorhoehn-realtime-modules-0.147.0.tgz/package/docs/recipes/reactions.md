# Recipe: Reactions

> Plug `reactions` into an app you already have. Three steps + a graduation path.

Per-channel (and per-target, via targetId) emoji reactions.

## 1 — Server (attach to your existing http.Server)

```ts
import http from 'http';
import { attachRealtime, reactions } from '@connorhoehn/realtime-modules/server';

const httpServer = http.createServer(app);      // your existing app
const realtime = attachRealtime(httpServer, {
    features: [reactions()],
    auth: async (req) => {
        const claims = await verifyToken(req);
        return { userId: claims.sub, exp: claims.exp };   // exp: the token's expiry, in seconds
    },
    // Required since 0.147.0: judges every channel read (`subscribe`) and write (`publish`).
    authorize: ({ kind, channel, ctx }) => !!ctx && canUseChannel(ctx, channel, kind),
    // Browser upgrades from any other Origin are refused with 403.
    allowedOrigins: ['https://app.example.com'],
    path: '/realtime',   // omit this and the handler claims EVERY upgrade on the server
});
httpServer.listen(3000);
```

Add more capabilities by adding entries to `features` — nothing else changes.

### Identity comes from the auth context

Since 0.98.5 a reaction's `userId` / `displayName` come from the connection's
auth context (or `identityResolver`), and for an identified sender the
frame's `metadata.userId` / `displayName` / `avatarUrl` are replaced with the
server's. `reactions({ resolveSender })` maps a differently shaped context;
`reactions({ trustFrameSender })` no longer has an effect.

## 2 — Client (React hook)

```tsx
import { useReactions } from '@connorhoehn/realtime-modules/client';

function MessageReactions({ channel, messageId, userId }: Props) {
  // targetId scopes the list to one message; omit it for floating call reactions.
  const { reactions, toggle } = useReactions(channel, { targetId: messageId });

  return (
    <>
      {reactions.map((r) => <span key={r.id}>{r.emoji}</span>)}
      {/* The chip is a toggle — `toggle` decides which way from the list it holds. */}
      <button onClick={() => toggle('🔥', { userId })}>🔥</button>
    </>
  );
}
```

`react` / `unreact` are there when you want to force a direction. Only
targeted reactions are removable — a floating one is an event that already
happened.

Point the client at the same origin and the `path` set above —
`ws://localhost:3000/realtime`. There is no default path: leave `path` off and
the upgrade listener takes every WebSocket upgrade on that server, including
one meant for an endpoint you already had. All hooks share one WebSocket via
the provider from `@connorhoehn/realtime-modules/client`.

## 3 — UI (ui-components)

Use **ReactionBar / your own emoji strip**.

## Graduate to production

Zero-config uses in-memory state (single process, non-durable). To graduate:

```ts
// ephemeral counters — persist externally if you need durability:
reactions({
    // After the broadcast, fire-and-forget. `reaction.org` (0.99.0) is the
    // sender's auth-context org, on this copy only — never broadcast.
    onReaction: (reaction) => record(reaction),
})
```

or observe every publish with a plugin (`onMessage` gets the sender's
`userId` since 0.99.0 — see [plugins](./README.md#plugins--observe-every-publish)).

Multi-node? Swap the transport, not the features: pass a Redis-backed
`RealtimeRouter` via `attachRealtime(server, { router })` — the
websocket-gateway MessageRouter is the reference implementation.
