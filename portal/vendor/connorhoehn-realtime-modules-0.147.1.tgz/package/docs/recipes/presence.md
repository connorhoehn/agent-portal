# Recipe: Presence

> Plug `presence` into an app you already have. Three steps + a graduation path.

Who is here, per channel, with display names and colors derived from the auth context (`auth: () => ({ userId, displayName })`).

## 1 — Server (attach to your existing http.Server)

```ts
import http from 'http';
import { attachRealtime, presence } from '@connorhoehn/realtime-modules/server';

const httpServer = http.createServer(app);      // your existing app
const realtime = attachRealtime(httpServer, {
    features: [presence()],
    auth: async (req) => {
        const claims = await verifyToken(req);
        return { userId: claims.sub, exp: claims.exp };   // exp: the token's expiry, in seconds
    },
    // Required since 0.147.0: judges every channel read (`subscribe`) and write (`publish`).
    authorize: ({ kind, channel, ctx }) => !!ctx && canUseChannel(ctx, channel, kind),
    // Browser upgrades from any other Origin are refused with 403.
    allowedOrigins: ['https://app.example.com'],
    path: '/realtime',   // omit this and the handler claims EVERY upgrade on the server
});
httpServer.listen(3000);
```

Add more capabilities by adding entries to `features` — nothing else changes.

### Identity comes from the auth context

Since 0.98.5, for an authenticated connection the presence entry carries
`userId` and its `metadata.userId` / `displayName` / `avatarUrl` come from
the auth context; the `set` frame's copies are dropped, so nobody can appear
online as somebody else. `presence({ resolveSender })` maps a differently
shaped context, and `presence({ trustFrameSender: true })` lets the frame's
metadata stand. Anonymous connections are unaffected. (Only chat ignores
`trustFrameSender` since 0.147.0.)

## 2 — Client (React hook)

```tsx
import { usePresence } from '@connorhoehn/realtime-modules/client';

function Roster({ channel }: { channel: string }) {
  const { roster, setStatus, updateMetadata } = usePresence(channel);

  useEffect(() => {
    updateMetadata({ displayName: me.name });
    setStatus('online');
  }, [setStatus, updateMetadata]);

  return <ul>{roster.map((p) => <li key={p.clientId}>{p.status}</li>)}</ul>;
}
```

Point the client at the same origin and the `path` set above —
`ws://localhost:3000/realtime`. There is no default path: leave `path` off and
the upgrade listener takes every WebSocket upgrade on that server, including
one meant for an endpoint you already had. All hooks share one WebSocket via
the provider from `@connorhoehn/realtime-modules/client`.

## 3 — UI (ui-components)

Use **PresenceAvatars fed from the hook**.

## Graduate to production

Zero-config uses in-memory state (single process, non-durable). To graduate:

```ts
// presence is ephemeral by design — no store to graduate; tune sweep intervals via presence({ heartbeatIntervalMs, … })
```

Multi-node? Swap the transport, not the features: pass a Redis-backed
`RealtimeRouter` via `attachRealtime(server, { router })` — the
websocket-gateway MessageRouter is the reference implementation.
