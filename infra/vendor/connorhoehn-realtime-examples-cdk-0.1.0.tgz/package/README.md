# @connorhoehn/realtime-examples-cdk

CDK constructs from realtime-examples: `ApplicationTables`, `DocumentWorkspaceServices`,
`RedisService`, `MessageQueueTask`, and `dynamodb-schemas.json` (the manifest `ApplicationTables` reads).
Peers: `aws-cdk-lib`, `constructs`. No runtime dependencies.

npm cannot install a subdirectory of a git repo, so consumers vendor a tarball:

    npm --prefix cdk run build      # after editing lib/*.ts or infra/dynamodb-schemas.json
    npm --prefix cdk pack --pack-destination <consumer>/vendor
    # consumer package.json: "@connorhoehn/realtime-examples-cdk": "file:vendor/connorhoehn-realtime-examples-cdk-<version>.tgz"

Commit `cdk/dist` with the source change. Bump `version` for each new tarball.
