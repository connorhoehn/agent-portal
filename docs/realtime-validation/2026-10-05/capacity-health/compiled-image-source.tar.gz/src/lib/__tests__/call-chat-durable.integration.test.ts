// Opt in with BOTH CALL_CHAT_TEST_DYNAMODB_ENDPOINT and
// CALL_CHAT_TEST_REDIS_URL. Real SDK requests and Redis Lua are required;
// configured-but-unreachable stores fail rather than silently skip. Identity
// fixtures and the transport handle are controlled here; root browser/WS tests
// separately establish authentication/media boundaries. No media is exercised.
jest.mock('../../config.js', () => ({ config: { region: 'us-east-1', auth: { sessionSigningSecretArn: '' }, cognito: { portalOrigin: '' }, mock: { aurora: true } } }));

import { randomBytes } from 'node:crypto';
import { execFile } from 'node:child_process';
import { resolve } from 'node:path';
import { promisify } from 'node:util';
import { DynamoDBClient, DescribeTableCommand, QueryCommand, DeleteItemCommand } from '@aws-sdk/client-dynamodb';
import { RedisCallStateStore } from '@connorhoehnslalom/realtime-modules/call';
import { LocalRealtimeRouter } from '@connorhoehnslalom/realtime-modules/server';
import { DynamoChatStore } from '@connorhoehnslalom/realtime-modules/server/stores/dynamo';
import { RedisLite } from '../redis-lite.js';
import { CallChatRuntime, callChatChannel, callChatStorageChannel, type CallChatReceipt } from '../call-chat.js';
import { RedisCallChatStateStore } from '../call-chat-state.js';
import { observeCallPageLifecycle } from '../call-pages.js';
import { AppError } from '../async-handler.js';
import type { Session } from '../session.js';

// The default SDK HTTP handler's dynamic import does not work in Jest's VM;
// the SDK's fetch transport still executes real DynamoDB HTTP requests.
const { FetchHttpHandler } = require('@smithy/fetch-http-handler');
const endpoint = process.env['CALL_CHAT_TEST_DYNAMODB_ENDPOINT'];
const redisUrl = process.env['CALL_CHAT_TEST_REDIS_URL'];
if (!!endpoint !== !!redisUrl) throw new Error('Durable huddle integration requires BOTH real DynamoDB and Redis endpoints');
const suite = endpoint && redisUrl ? describe : describe.skip;
const prefix = 'orgiq-chat-';
const table = `${prefix}chat-messages`;
const timestamp = Date.parse('2026-10-03T12:00:00.000Z');
const loopback = new Set(['127.0.0.1', 'localhost', '[::1]', '::1']);
const execFileAsync = promisify(execFile);
const restartStores = process.env['CALL_CHAT_TEST_RESTART_STORES'] === '1';

/** Only the separately owned Compose profile may be restarted by this opt-in. */
async function restartOwnedStores() {
  const dockerHost = process.env['CALL_CHAT_TEST_DOCKER_HOST'];
  if (dockerHost !== 'unix:///tmp/orgiq-soak-docker.sock'
    || new URL(endpoint!).port !== '18061' || new URL(redisUrl!).port !== '16479') {
    throw new Error('Store restart requires the dedicated local Docker host and ports 18061/16479');
  }
  const names = ['orgiq-chat-redis', 'orgiq-chat-dynamodb'];
  const { stdout } = await execFileAsync('docker', ['--host', dockerHost, 'inspect', ...names], { timeout: 10000 });
  const inspected = JSON.parse(stdout) as Array<{
    Id: string; Name: string; State: { Running: boolean };
    Config: { Labels: Record<string, string>; Image: string };
    HostConfig: { PortBindings: Record<string, Array<{ HostIp: string; HostPort: string }>> };
    Mounts: Array<{ Type: string; Name: string; Destination: string }>;
  }>;
  expect(inspected).toHaveLength(2);
  for (const [index, container] of inspected.entries()) {
    const service = index === 0 ? 'chat-redis' : 'chat-dynamodb';
    const containerPort = index === 0 ? '6379/tcp' : '8000/tcp';
    const hostPort = index === 0 ? '16479' : '18061';
    expect(container.Name).toBe(`/${names[index]}`);
    expect(container.Id).toMatch(/^[a-f0-9]{64}$/);
    expect(container.State.Running).toBe(true);
    expect(container.Config.Labels['com.docker.compose.project']).toBe('orgiq-chat-test');
    expect(container.Config.Labels['com.docker.compose.service']).toBe(service);
    expect(container.HostConfig.PortBindings[containerPort]).toEqual([{ HostIp: '127.0.0.1', HostPort: hostPort }]);
    expect(container.Mounts).toContainEqual(expect.objectContaining({ Type: 'volume',
      Name: `orgiq-chat-test_${service}-data`, Destination: '/data' }));
  }
  // IDs from the validated inspection prevent a same-name replacement from
  // becoming the target. No selectors, volume deletion, or unrelated restart.
  await execFileAsync('docker', ['--host', dockerHost, 'restart', '--time', '1', ...inspected.map(value => value.Id)], { timeout: 30000 });
  const client = dynamo(); const redis = new RedisLite(redisUrl!, { commandTimeoutMs: 2000 });
  try {
    const deadline = Date.now() + 30000;
    while (true) {
      try {
        expect(await redis.command('PING')).toBe('PONG');
        expect((await client.send(new DescribeTableCommand({ TableName: table }))).Table?.TableStatus).toBe('ACTIVE');
        break;
      } catch (error) {
        if (Date.now() >= deadline) throw error;
        await new Promise(resolve => setTimeout(resolve, 250));
      }
    }
  } finally { client.destroy(); await redis.quit(); }
}

type Bundle = ReturnType<typeof bundle>;
let callId: string, lobby: string;
let sessions: Record<'alice' | 'bob' | 'charlie', Session>;
let bundles: Bundle[];
let identities: Map<string, Session>;
let allClientIds: Set<string>;
let storageChannels: Set<string>;

function dynamo() {
  return new DynamoDBClient({ endpoint, region: 'us-east-1', maxAttempts: 2,
    credentials: { accessKeyId: 'local', secretAccessKey: 'local' }, requestHandler: new FetchHttpHandler({ requestTimeout: 5000 }) });
}
function bundle(generation: string) {
  const redis = new RedisLite(redisUrl!, { commandTimeoutMs: 5000 });
  const calls = new RedisCallStateStore(redis);
  const client = dynamo();
  const messages = new DynamoChatStore({ client, tablePrefix: prefix });
  const state = new RedisCallChatStateStore(redis);
  const contexts = new Map<string, Record<string, unknown>>();
  let seatIndex = 0;
  const frames: Array<{ clientId: string; frame: Record<string, unknown> }> = [];
  const router = new LocalRealtimeRouter();
  router._setHandle({
    wss: null, dispose: async () => {}, listClients: () => [...contexts.keys()],
    getClientContext: id => contexts.get(id) ?? null,
    sendToClient: (id, frame) => { if (!contexts.has(id)) return false; frames.push({ clientId: id, frame }); return true; },
  });
  const runtime = new CallChatRuntime({ calls, messages, state, router, maintenanceIntervalMs: 0, now: () => timestamp,
    lobbyAllowed: (auth, name) => name === lobby && name.split(':').includes(String(auth.userId)),
    authority: async session => {
      const current = identities.get(session.sub);
      if (session.tenant !== 'orgiq' || !current || current.epoch !== session.epoch || current.role !== session.role) throw new AppError(401, 'Session revoked');
      return { displayName: `${session.sub} Directory`, grants: current.grants };
    },
    grant: async (_session, authority, action) => authority.grants.social?.includes('participant') === true
      && ['ViewSocial', 'PostMessage'].includes(action),
  });
  const observed = observeCallPageLifecycle(calls, () => null, () => runtime);
  const connect = (person: keyof typeof sessions) => {
    const session = sessions[person]; const id = `${generation}-${++seatIndex}-${session.sub}`; allClientIds.add(id);
    contexts.set(id, { userId: session.sub, org: session.tenant, role: session.role, epoch: session.epoch,
      displayName: 'Untrusted socket display name', sessionIat: session.iat });
    return id;
  };
  return { redis, calls, observed, client, messages, state, contexts, frames, router, runtime, connect };
}
async function register(b: Bundle, person: keyof typeof sessions) {
  const id = b.connect(person);
  await b.observed.registerParticipant(callId, id, sessions.alice.sub, lobby, [sessions.bob.sub, sessions.charlie.sub]);
  await b.calls.registerUserCall(sessions[person].sub, callId, 14400);
  await storageChannel(b);
  return id;
}
async function storageChannel(b: Bundle) {
  const incarnation = (await b.state.get(callId)).incarnation;
  expect(incarnation).toMatch(/^[a-f0-9-]{36}$/);
  const channel = callChatStorageChannel(callId, incarnation); storageChannels.add(channel); return channel;
}
async function restart(previous: Bundle, people: Array<keyof typeof sessions>) {
  previous.runtime.dispose(); previous.contexts.clear();
  const fresh = bundle(`fresh-${bundles.length}`); bundles.push(fresh);
  // A cold router recognizes only the new connection IDs. Resume must use
  // existing Redis seats and retire the old roster without a replacement invite.
  const old = (await fresh.calls.getCall(callId))!.participantClientIds;
  for (const [index, person] of people.entries()) {
    const id = fresh.connect(person);
    expect(await fresh.observed.resumeParticipant!(callId, id, sessions[person].sub, lobby, index === 0 ? old : [])).toBe(true);
  }
  await storageChannel(fresh);
  return fresh;
}
async function history(b: Bundle, person: keyof typeof sessions, ids: string[], limit = 50) {
  const deadline = Date.now() + 5000;
  while (true) {
    const result = await b.runtime.get(callId, sessions[person], limit);
    if (JSON.stringify(result.messages.map(message => message.id)) === JSON.stringify(ids)) return result;
    if (Date.now() > deadline) { expect(result.messages.map(message => message.id)).toEqual(ids); return result; }
    await new Promise(resolve => setTimeout(resolve, 25));
  }
}

suite('durable huddle over real Redis and DynamoDB Local', () => {
  beforeAll(async () => {
    if (new URL(endpoint!).protocol !== 'http:' || !loopback.has(new URL(endpoint!).hostname)
      || new URL(redisUrl!).protocol !== 'redis:' || !loopback.has(new URL(redisUrl!).hostname)) throw new Error('Durable huddle tests require explicit loopback stores');
    const client = dynamo(); const redis = new RedisLite(redisUrl!);
    try {
      expect(await redis.command('PING')).toBe('PONG');
      for (const suffix of ['chat-messages', 'chat-conversations', 'chat-members', 'chat-reads', 'chat-pins']) {
        expect((await client.send(new DescribeTableCommand({ TableName: prefix + suffix }))).Table?.TableStatus).toBe('ACTIVE');
      }
    } finally { client.destroy(); await redis.quit(); }
  }, 15000);

  beforeEach(async () => {
    const tag = `${Date.now()}-${randomBytes(6).toString('hex')}`;
    callId = `chat-durable-${tag}`;
    const person = (name: string): Session => ({
      sub: `durable-${tag}-${name}`, name: 'Untrusted cookie display name', tenant: 'orgiq', role: 'member', epoch: 0,
      grants: { orgiq: ['member'], social: ['participant'] }, iat: 100,
    });
    sessions = { alice: person('alice'), bob: person('bob'), charlie: person('charlie') };
    lobby = `orgiq:dm:${Object.values(sessions).map(session => session.sub).sort().join(':')}`;
    identities = new Map(Object.values(sessions).map(session => [session.sub, structuredClone(session)]));
    allClientIds = new Set(); storageChannels = new Set(); bundles = [];
    const first = bundle('old'); bundles.push(first);
    await register(first, 'alice'); await register(first, 'bob');
    await first.calls.registerLobbyCall(lobby, callId, 14400); await first.calls.markAccepted(callId, 14400);
    await first.calls.setInviteMetadata(callId, { invitedAt: timestamp - 1000, callerName: 'Original caller' });
  });

  afterEach(async () => {
    for (const b of bundles ?? []) b.runtime.dispose();
    if (!bundles?.length) return;
    const b = bundles.at(-1)!;
    // Delete only this test's channel rows and exact Redis keys. Keep the
    // bootstrapped tables and unrelated runs; no FLUSHDB or table deletion.
    try {
      for (const channel of storageChannels) {
        const rows = await b.client.send(new QueryCommand({ TableName: table, KeyConditionExpression: 'channelId = :ch',
          ExpressionAttributeValues: { ':ch': { S: channel } }, ConsistentRead: true }));
        await Promise.all((rows.Items ?? []).map(item => b.client.send(new DeleteItemCommand({ TableName: table,
          Key: { channelId: item.channelId!, messageId: item.messageId! } }))));
      }
      const key = `orgiq:call-chat:${encodeURIComponent(callId)}`;
      const receipts = await b.redis.command('SMEMBERS', `${key}:deliveries`) as string[];
      await b.redis.del(key, `${key}:deliveries`, ...receipts,
        `call:active:${callId}`, `call:active:${callId}:participants`, `call:accepted:${callId}`, `call:lobby:${lobby}`,
        ...[...allClientIds].map(id => `client:calls:${id}`), ...Object.values(sessions).map(session => `call:user:${session.sub}`));
    } finally { await Promise.allSettled(bundles.map(async value => { value.client.destroy(); await value.redis.quit(); })); }
  }, 15000);

  it('persists 120 sends, replays the exact newest50 after cold resume and retries with immutable IDs/timestamps', async () => {
    const first = bundles[0]!; const sent: CallChatReceipt[] = [];
    for (let index = 1; index <= 120; index++) {
      sent.push(await first.runtime.send(callId, sessions.alice, { text: `message-${index}`, clientDeliveryId: `delivery-${index}` }));
    }
    expect(new Set(sent.map(receipt => receipt.message.id)).size).toBe(120);
    expect(sent.map(receipt => receipt.message.id)).toEqual(sent.map(receipt => receipt.message.id).sort());
    expect(sent.every(receipt => receipt.message.timestamp === new Date(timestamp).toISOString())).toBe(true);
    expect(sent.every(receipt => receipt.message.channel === callChatChannel(callId))).toBe(true);
    const bobClient = [...first.contexts.keys()].find(id => id.endsWith(sessions.bob.sub))!;
    const deliveries = first.frames.filter(({ clientId, frame }) => clientId === bobClient && frame.type === 'chat' && frame.action === 'message')
      .map(({ frame }) => (frame.message as { id: string }).id);
    expect(deliveries).toEqual(sent.map(receipt => receipt.message.id));
    expect(new Set(deliveries).size).toBe(120); // Per-message evidence, not aggregate observation counts.
    // Re-running the shared schema initializer must preserve populated tables.
    await execFileAsync(process.execPath, [resolve(__dirname, '../../../../scripts/loadtest/init-chat-dynamodb.mjs')], {
      env: { ...process.env, CHAT_DDB_ENDPOINT: endpoint, CHAT_TABLE_PREFIX: prefix }, timeout: 15000,
    });
    const newest = sent.slice(-50).map(receipt => receipt.message.id);
    await history(first, 'bob', newest);
    const fresh = await restart(first, ['alice', 'bob']);
    const replay = await history(fresh, 'bob', newest);
    expect(replay.messages).toEqual(sent.slice(-50).map(receipt => receipt.message));
    expect(await fresh.calls.getCall(callId)).toMatchObject({ callerId: sessions.alice.sub, callerName: 'Original caller', invitedAt: timestamp - 1000 });
    const retry = await fresh.runtime.send(callId, sessions.alice, { text: 'message-1', clientDeliveryId: 'delivery-1' });
    expect(retry).toMatchObject({ duplicate: true, deliveryId: 'delivery-1', message: sent[0]!.message });
    await expect(fresh.runtime.send(callId, sessions.alice, { text: 'Changed', clientDeliveryId: 'delivery-1' })).rejects.toMatchObject({ status: 409 });
    const rows = await fresh.client.send(new QueryCommand({ TableName: table, KeyConditionExpression: 'channelId = :ch',
      ExpressionAttributeValues: { ':ch': { S: await storageChannel(fresh) } }, ConsistentRead: true, Select: 'COUNT' }));
    expect(rows.Count).toBe(120);
    expect((await fresh.state.get(callId)).sequence).toBe(120);
    await history(fresh, 'bob', newest);
  }, 60000);

  it('preserves join floors on cold resume and advances them on explicit leave/rejoin even at the same timestamp', async () => {
    const first = bundles[0]!;
    const early = await first.runtime.send(callId, sessions.alice, { text: 'Before Charlie joined', clientDeliveryId: 'early' });
    const unseatedCharlie = first.connect('charlie');
    await expect(first.runtime.get(callId, sessions.charlie)).rejects.toMatchObject({ status: 403 });
    await expect(first.runtime.send(callId, sessions.charlie, { text: 'Unjoined', clientDeliveryId: 'denied' })).rejects.toMatchObject({ status: 403 });
    const oldCharlie = await register(first, 'charlie');
    await history(first, 'charlie', []);
    expect((await first.state.get(callId)).members[sessions.charlie.sub]?.sequenceFrom).toBe(1);
    const joined = await first.runtime.send(callId, sessions.alice, { text: 'After Charlie joined', clientDeliveryId: 'joined' });
    await history(first, 'charlie', [joined.message.id]);
    expect(first.frames.some(({ clientId, frame }) => clientId === unseatedCharlie && frame.type === 'chat')).toBe(false);
    const fresh = await restart(first, ['alice', 'bob', 'charlie']);
    await history(fresh, 'charlie', [joined.message.id]);
    const resumedCharlie = [...fresh.contexts.keys()].find(id => id.endsWith(sessions.charlie.sub))!;
    await fresh.observed.removeParticipant(callId, resumedCharlie); fresh.contexts.delete(resumedCharlie);
    await expect(fresh.runtime.get(callId, sessions.charlie)).rejects.toMatchObject({ status: 403 });
    await fresh.runtime.send(callId, sessions.alice, { text: 'While Charlie absent', clientDeliveryId: 'absent' });
    fresh.contexts.delete(oldCharlie); // Old-generation connections never become live again.
    await register(fresh, 'charlie');
    expect((await fresh.state.get(callId)).members[sessions.charlie.sub]?.sequenceFrom).toBe(3);
    await history(fresh, 'charlie', []);
    const rejoined = await fresh.runtime.send(callId, sessions.alice, { text: 'After explicit rejoin', clientDeliveryId: 'rejoined' });
    const after = await history(fresh, 'charlie', [rejoined.message.id]);
    expect(after.messages.some(message => message.id === early.message.id)).toBe(false);
    expect(after.historyFrom).toBe(new Date(timestamp).toISOString());
  }, 20000);

  it('rejects revoked or mismatched actors and keeps terminal history inaccessible to fresh runtimes', async () => {
    const first = bundles[0]!;
    await first.runtime.send(callId, sessions.alice, { text: 'Protected', clientDeliveryId: 'protected' });
    const changed = { ...sessions.bob, epoch: 1 };
    await expect(first.runtime.get(callId, changed)).rejects.toMatchObject({ status: 401 });
    identities.get(sessions.bob.sub)!.grants.social = [];
    await expect(first.runtime.get(callId, sessions.bob)).rejects.toMatchObject({ status: 403 });
    await expect(first.runtime.send(callId, sessions.bob, { text: 'Revoked', clientDeliveryId: 'revoked' })).rejects.toMatchObject({ status: 403 });
    expect((await first.messages.listMessages(await storageChannel(first), 100))).toHaveLength(1);
    await first.observed.forgetCall(callId);
    const fresh = bundle('terminal'); bundles.push(fresh); fresh.connect('alice');
    expect((await fresh.state.get(callId)).ended).toBe(true);
    await expect(fresh.runtime.get(callId, sessions.alice)).rejects.toMatchObject({ status: 404 });
    await expect(fresh.runtime.send(callId, sessions.alice, { text: 'After end', clientDeliveryId: 'ended' })).rejects.toMatchObject({ status: 404 });
  }, 20000);

  it('isolates retained Dynamo history after Redis state expiry and callId reuse by a new participant', async () => {
    const first = bundles[0]!; const oldChannel = await storageChannel(first);
    const oldIncarnation = (await first.state.get(callId)).incarnation;
    for (let index = 1; index <= 3; index++) await first.runtime.send(callId, sessions.alice,
      { text: `Old private history ${index}`, clientDeliveryId: `old-${index}` });
    await first.observed.forgetCall(callId); first.runtime.dispose(); first.contexts.clear();
    // Model the bounded Redis state/tombstone expiring while Dynamo retains
    // its90day rows. Old receipt keys deliberately remain until test cleanup.
    await first.redis.del(`orgiq:call-chat:${encodeURIComponent(callId)}`);
    const fresh = bundle('reused-call'); bundles.push(fresh);
    const charlie = fresh.connect('charlie');
    await fresh.observed.registerParticipant(callId, charlie, sessions.charlie.sub, lobby, []);
    await fresh.calls.registerUserCall(sessions.charlie.sub, callId, 14400);
    const newChannel = await storageChannel(fresh);
    expect((await fresh.state.get(callId)).incarnation).not.toBe(oldIncarnation);
    expect(newChannel).not.toBe(oldChannel);
    await history(fresh, 'charlie', []);
    const next = await fresh.runtime.send(callId, sessions.charlie, { text: 'New incarnation only', clientDeliveryId: 'old-1' });
    expect(next.duplicate).toBe(false);
    expect(next.message.channel).toBe(callChatChannel(callId));
    const snapshot = await history(fresh, 'charlie', [next.message.id]);
    expect(snapshot.messages.map(message => message.message)).toEqual(['New incarnation only']);
    // Reset sequence1 is safe because the durable partition differs.
    expect((await fresh.messages.getMessage(newChannel, next.message.id))?.metadata).toMatchObject({ _callSequence: 1 });
    const old = await fresh.client.send(new QueryCommand({ TableName: table, KeyConditionExpression: 'channelId = :ch',
      ExpressionAttributeValues: { ':ch': { S: oldChannel } }, ConsistentRead: true, Select: 'COUNT' }));
    expect(old.Count).toBe(3); // Privacy comes from isolation, not deleting retained history.
    await expect(fresh.runtime.get(callId, sessions.alice)).rejects.toMatchObject({ status: 403 });
  }, 20000);

  (restartStores ? it : it.skip)('keeps persisted messages, call incarnation and immutable retries across both storage-container restarts', async () => {
    const first = bundles[0]!;
    const sent: CallChatReceipt[] = [];
    for (let index = 1; index <= 12; index++) sent.push(await first.runtime.send(callId, sessions.alice,
      { text: `Before storage restart ${index}`, clientDeliveryId: `store-restart-${index}` }));
    const originalState = await first.state.get(callId);
    const originalChannel = await storageChannel(first);
    await history(first, 'bob', sent.map(receipt => receipt.message.id));
    await restartOwnedStores();
    const fresh = await restart(first, ['alice', 'bob']);
    expect(await storageChannel(fresh)).toBe(originalChannel);
    expect((await fresh.state.get(callId)).incarnation).toBe(originalState.incarnation);
    const replay = await history(fresh, 'bob', sent.map(receipt => receipt.message.id));
    expect(replay.messages).toEqual(sent.map(receipt => receipt.message));
    const retry = await fresh.runtime.send(callId, sessions.alice,
      { text: 'Before storage restart 1', clientDeliveryId: 'store-restart-1' });
    expect(retry).toMatchObject({ duplicate: true, message: sent[0]!.message });
    const after = await fresh.runtime.send(callId, sessions.alice,
      { text: 'After storage restart', clientDeliveryId: 'store-restart-after' });
    expect(after.duplicate).toBe(false);
    await history(fresh, 'bob', [...sent.map(receipt => receipt.message.id), after.message.id]);
    const rows = await fresh.client.send(new QueryCommand({ TableName: table, KeyConditionExpression: 'channelId = :ch',
      ExpressionAttributeValues: { ':ch': { S: originalChannel } }, ConsistentRead: true, Select: 'COUNT' }));
    expect(rows.Count).toBe(13);
    expect((await fresh.state.get(callId)).sequence).toBe(13);
  }, 90000);
});
