jest.mock('../../config.js', () => ({ config: { region: 'us-east-1', auth: { sessionSigningSecretArn: '' }, cognito: { portalOrigin: '' }, mock: { aurora: true } } }));
jest.mock('../../providers/identity.js', () => ({ getUser: jest.fn() }));
jest.mock('../../providers/projects.js', () => ({ getProject: jest.fn() }));
jest.mock('../../providers/work-items.js', () => ({ getWorkItem: jest.fn() }));
jest.mock('../role-registry.js', () => ({ roleRegistry: () => [{ id: 'participant', tenant: 'social', capabilities: ['ViewSocial', 'PostMessage'] }] }));
import express from 'express';
import http from 'node:http';
import type { AddressInfo } from 'node:net';
import WebSocket from 'ws';
import request from '../../test-support/http.js';
import { attachRealtimeGateway } from '../realtime-gateway.js';
import { createMemorySocialChatBackend } from '../social-chat.js';
import { callChatChannel } from '../call-chat.js';
import { callChatRouter } from '../../routes/call-chat.js';
import { chatPinsRouter } from '../../routes/chat-pins.js';
import { errorHandler } from '../async-handler.js';
import { signRealtimeToken, realtimeClaims } from '../realtime-token.js';
import { getUser } from '../../providers/identity.js';
import { getProject } from '../../providers/projects.js';
import { getWorkItem } from '../../providers/work-items.js';
import type { Session } from '../session.js';

const SECRET = 'huddle-gateway-test-secret';
type Frame = Record<string, unknown>; type Client = { ws: WebSocket; frames: Frame[] };
const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));
async function until(check: () => boolean, timeout = 4000) {
  const start = Date.now(); while (!check()) { if (Date.now() - start > timeout) throw new Error('Gateway condition timed out'); await sleep(10); }
}
it('integrates real call/chat lifecycle, protected HTTP receipts and WS recipient isolation, denying all raw bypass paths', async () => {
  const previous = process.env['REALTIME_JWT_SECRET']; process.env['REALTIME_JWT_SECRET'] = SECRET;
  const sessions = new Map(['alice', 'bob', 'charlie'].map(sub => [sub, { sub, name: `${sub} cookie`, tenant: 'orgiq', role: 'member', epoch: 0,
    grants: { orgiq: ['member'], social: ['participant'] }, iat: Math.floor(Date.now() / 1000) } as Session]));
  jest.mocked(getUser).mockImplementation(async id => sessions.has(id) ? { id, displayName: `${id} Directory`, epoch: 0,
    email: null, personId: null, grants: sessions.get(id)!.grants } : null);
  jest.mocked(getProject).mockResolvedValue({ id: 'p-auth', name: 'Auth Migration' } as Awaited<ReturnType<typeof getProject>>);
  jest.mocked(getWorkItem).mockResolvedValue({ id: 'wi-auth', projectId: 'p-auth', title: 'Cutover runbook' } as Awaited<ReturnType<typeof getWorkItem>>);
  const app = express(); app.use(express.json());
  app.use((req, _res, next) => { req.session = sessions.get(String(req.headers['x-user'])); next(); });
  app.use('/api/calls', callChatRouter); app.use('/api/chat', chatPinsRouter); app.use(errorHandler);
  const server = http.createServer(app); const backend = createMemorySocialChatBackend({ fixtures: false });
  const handle = attachRealtimeGateway(server, { redisUrl: null, socialChat: backend, statsIntervalMs: 0, pingIntervalMs: 0 });
  const clients: Client[] = []; const warning = jest.spyOn(console, 'warn').mockImplementation(() => undefined);
  try {
    await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve));
    const port = (server.address() as AddressInfo).port;
    const connect = async (user: string): Promise<Client> => {
      const signed = await signRealtimeToken(realtimeClaims(sessions.get(user)!), SECRET);
      const ws = new WebSocket(`ws://127.0.0.1:${port}/ws`, ['bearer-token-v1', signed.token]); const frames: Frame[] = [];
      ws.on('message', data => frames.push(JSON.parse(String(data)) as Frame));
      const client = { ws, frames }; clients.push(client); await until(() => frames.some(frame => frame.type === 'session')); return client;
    };
    const alice = await connect('alice'); const bob = await connect('bob'); const charlie = await connect('charlie'); const bobOtherTab = await connect('bob');
    // Charlie is eligible for the initiative Discussion, but never accepts the call.
    await backend.membershipStore.putMember({ channel: 'social:ch:auth-migration', userId: 'charlie', role: 'member',
      addedBy: 'alice', addedAt: new Date().toISOString(), historyFrom: null, removedAt: null });
    charlie.ws.send(JSON.stringify({ service: 'chat', action: 'join', channel: 'social:ch:auth-migration' }));
    await until(() => charlie.frames.some(frame => frame.type === 'chat' && frame.action === 'joined'));
    const callId = 'actual-call-chat'; const lobbyName = 'orgiq:initiative:p-auth'; const channel = callChatChannel(callId);
    alice.ws.send(JSON.stringify({ service: 'call', action: 'invite', callId, lobbyName, callerId: 'alice', targetUserIds: ['bob', 'charlie'] }));
    await until(() => bob.frames.some(frame => frame.type === 'call' && frame.action === 'invite'));
    bob.ws.send(JSON.stringify({ service: 'call', action: 'accepted', callId, lobbyName, callerId: 'bob', userId: 'bob', targetUserIds: ['alice'] }));
    await until(() => alice.frames.some(frame => frame.type === 'call' && frame.action === 'accepted'));
    for (const [client, userId] of [[alice, 'alice'], [bob, 'bob']] as const) client.ws.send(JSON.stringify({ service: 'call', action: 'participant-state',
      callId, lobbyName, callerId: userId, userId, participantId: `pid-${userId}`, audioOn: true, cameraOn: false, screenSharing: false, targetUserIds: ['alice', 'bob'].filter(id => id !== userId) }));
    await until(() => alice.frames.some(frame => frame.type === 'call-chat' && frame.action === 'members' && (frame.participants as unknown[])?.length === 2));
    expect((await request(app).get(`/api/calls/${callId}/chat`).set('x-user', 'charlie')).status).toBe(403);
    const snapshot = await request(app).get(`/api/calls/${callId}/chat`).set('x-user', 'alice');
    expect(snapshot.body.participants.map((p: { userId: string }) => p.userId)).toEqual(['alice', 'bob']);
    const result = await request(app).post(`/api/calls/${callId}/chat/messages`).set('x-user', 'alice')
      .send({ text: 'Actual huddle only', clientDeliveryId: 'actual-delivery', page: { kind: 'work-item', id: 'wi-auth' } });
    expect(result.status).toBe(201);
    await until(() => bob.frames.some(frame => frame.type === 'chat' && (frame.message as Frame | undefined)?.id === result.body.message.id));
    for (const outsider of [charlie, bobOtherTab]) expect(outsider.frames.some(frame => frame.type === 'chat' && frame.channel === channel)).toBe(false);
    // A joined participant cannot bypass attachment validation or widen membership either.
    for (const frame of [
      { service: 'subscribe', action: 'subscribe' }, { service: 'chat', action: 'join' }, { service: 'chat', action: 'history' },
      { service: 'chat', action: 'send', message: 'forged', metadata: { pageReference: { href: 'https://evil.invalid' } } },
      { service: 'chat', action: 'addMembers', userIds: ['charlie'], history: { mode: 'all' } },
      { service: 'chat', action: 'removeMember', userId: 'bob' }, { service: 'presence', action: 'subscribe' },
    ]) {
      const errors = alice.frames.filter(value => value.type === 'error').length;
      alice.ws.send(JSON.stringify({ ...frame, channel }));
      await until(() => alice.frames.filter(value => value.type === 'error').length > errors);
      expect(alice.frames.filter(value => value.type === 'error').at(-1)).toMatchObject({ code: 'AUTHZ_CHANNEL_DENIED' });
    }
    expect((await request(app).get('/api/chat/message').set('x-user', 'alice').query({ channel, messageId: result.body.message.id })).status).toBe(400);
    expect((await request(app).get('/api/chat/pins').set('x-user', 'alice').query({ channel })).status).toBe(400);
    expect((await request(app).post('/api/chat/pins').set('x-user', 'alice').send({ channel, messageId: result.body.message.id })).status).toBe(400);
    const replay = await request(app).get(`/api/calls/${callId}/chat`).set('x-user', 'bob'); expect(replay.body.messages).toEqual([result.body.message]);
    bob.ws.send(JSON.stringify({ service: 'call', action: 'user-status', callId, lobbyName, callerId: 'bob', userId: 'bob', status: 'left', targetUserIds: ['alice'] }));
    bob.ws.send(JSON.stringify({ service: 'call', action: 'ended', callId, lobbyName, callerId: 'bob', targetUserIds: ['bob'] }));
    await until(() => alice.frames.some(frame => frame.type === 'call-chat' && frame.action === 'members'
      && Number(frame.revision) > Number(snapshot.body.revision) && (frame.participants as unknown[])?.length === 1));
    expect((await request(app).get(`/api/calls/${callId}/chat`).set('x-user', 'bob')).status).toBe(403);
    const second = await request(app).post(`/api/calls/${callId}/chat/messages`).set('x-user', 'alice').send({ text: 'After Bob left', clientDeliveryId: 'second-delivery' });
    expect(second.status).toBe(201); await sleep(50);
    expect(bob.frames.some(frame => frame.type === 'chat' && (frame.message as Frame | undefined)?.id === second.body.message.id)).toBe(false);
    expect(await backend.chatStore.listMessages('social:ch:auth-migration', 100)).toEqual([]);
  } finally {
    clients.forEach(client => client.ws.close()); await handle.dispose(); await new Promise<void>(resolve => server.close(() => resolve()));
    warning.mockRestore(); if (previous === undefined) delete process.env['REALTIME_JWT_SECRET']; else process.env['REALTIME_JWT_SECRET'] = previous;
  }
}, 20000);
