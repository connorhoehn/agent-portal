jest.mock('../../config.js', () => ({ config: { region: 'us-east-1', auth: { sessionSigningSecretArn: '' }, cognito: { portalOrigin: '' }, mock: { aurora: true } } }));
import { MemoryCallChatStateStore, type CallChatDelivery } from '../call-chat-state.js';
const first: CallChatDelivery = { hash: 'hash', status: 'pending', message: { id: 'provisional', clientId: 'a',
  userId: 'alice', channel: 'orgiq:huddle:call', message: 'Hello', metadata: { clientDeliveryId: 'draft' }, timestamp: '2026-10-03T00:00:00.000Z' } };

it('assigns ordered immutable delivery ids and sequence floors even at identical timestamps', async () => {
  const store = new MemoryCallChatStateStore();
  try {
    const incarnation = (await store.join('call', 'alice', first.message.timestamp, false)).incarnation;
    const one = await store.reserve('call', 'receipt-a', first, incarnation);
    await store.join('call', 'bob', first.message.timestamp, false);
    const two = await store.reserve('call', 'receipt-b', { ...first, hash: 'different' }, incarnation);
    expect(one.delivery.message.id).toBe(`huddle-00000000000000000001-${incarnation}-receipt-a`);
    expect(two.delivery.message.id).toBe(`huddle-00000000000000000002-${incarnation}-receipt-b`);
    expect((await store.get('call')).members.bob?.sequenceFrom).toBe(1);
    expect((await store.reserve('call', 'receipt-a', { ...first, hash: 'forged' }, incarnation)).delivery).toEqual(one.delivery);
    await store.complete('call', 'receipt-a', 'hash', 'persisted', incarnation);
    expect((await store.reserve('call', 'receipt-a', first, incarnation)).delivery.status).toBe('persisted');
  } finally { store.dispose(); }
});

it('preserves the floor on resume, replaces it on explicit rejoin, and retains a terminal tombstone', async () => {
  const store = new MemoryCallChatStateStore();
  try {
    const incarnation = (await store.join('call', 'alice', first.message.timestamp, false)).incarnation;
    await store.reserve('call', 'a', first, incarnation); await store.leave('call', 'alice');
    expect((await store.join('call', 'alice', 'later', true)).members.alice?.sequenceFrom).toBe(0);
    await store.leave('call', 'alice');
    expect((await store.join('call', 'alice', 'latest', false)).members.alice).toEqual({ sequenceFrom: 1, historyFrom: 'latest', active: true });
    const terminal = await store.finish('call'); expect(terminal.members).toEqual({});
    expect(await store.finish('call')).toEqual(terminal);
    await expect(store.join('call', 'bob', 'never', false)).rejects.toMatchObject({ status: 404 });
    await expect(store.reserve('call', 'new', first, incarnation)).rejects.toMatchObject({ status: 404 });
    await store.complete('call', 'a', 'hash', 'cancelled', incarnation);
    await expect(store.complete('call', 'a', 'hash', 'persisted', incarnation)).rejects.toMatchObject({ status: 409 });
  } finally { store.dispose(); }
});

it('bounds memory state/receipts by TTL and renews all receipts only while the call state is active', async () => {
  let time = 1000; const store = new MemoryCallChatStateStore(60, () => time);
  try {
    await expect(store.reserve('missing', 'a', first, 'missing')).rejects.toMatchObject({ status: 404 });
    const incarnation = (await store.join('call', 'alice', first.message.timestamp, false)).incarnation; const original = await store.reserve('call', 'a', first, incarnation);
    time += 59000; await store.keepAlive('call'); time += 59000;
    expect((await store.reserve('call', 'a', first, incarnation)).delivery.message.id).toBe(original.delivery.message.id);
    await store.finish('call'); time += 61000;
    expect(await store.get('call')).toEqual({ incarnation: '', revision: 0, sequence: 0, ended: false, members: {} });
    const nextIncarnation = (await store.join('call', 'alice', first.message.timestamp, false)).incarnation;
    expect(nextIncarnation).not.toBe(incarnation);
    await expect(store.reserve('call', 'a', first, incarnation)).rejects.toMatchObject({ status: 409 });
    expect((await store.reserve('call', 'a', first, nextIncarnation)).created).toBe(true);
  } finally { store.dispose(); }
});

it('uses own keys for unusual user ids and returns detached records', async () => {
  const store = new MemoryCallChatStateStore();
  try {
    const state = await store.join('call', '__proto__', first.message.timestamp, false);
    state.members['__proto__']!.historyFrom = 'changed';
    expect((await store.get('call')).members['__proto__']?.historyFrom).toBe(first.message.timestamp);
    expect(await store.join('call', 'constructor', first.message.timestamp, false)).toMatchObject({ revision: 2 });
  } finally { store.dispose(); }
});
