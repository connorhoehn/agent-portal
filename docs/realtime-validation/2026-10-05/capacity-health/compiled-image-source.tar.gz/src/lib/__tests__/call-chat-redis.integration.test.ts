// Opt in with CALL_CHAT_TEST_REDIS_URL. These tests execute real Redis Lua.
jest.mock('../../config.js', () => ({ config: { region: 'us-east-1', auth: { sessionSigningSecretArn: '' }, cognito: { portalOrigin: '' }, mock: { aurora: true } } }));
import { RedisLite } from '../redis-lite.js';
import { RedisCallChatStateStore, type CallChatDelivery } from '../call-chat-state.js';
const url = process.env['CALL_CHAT_TEST_REDIS_URL']; const testRedis = url ? it : it.skip;
testRedis('real Redis retains atomic delivery identity, ordered sequences, join floors, TTL and terminal closure across two instances', async () => {
  const one = new RedisLite(url!); const two = new RedisLite(url!);
  const first = new RedisCallChatStateStore(one, 60); const second = new RedisCallChatStateStore(two, 60);
  const callId = `chat-test-${process.pid}-${Date.now()}`; const key = `orgiq:call-chat:${callId}`;
  const candidate: CallChatDelivery = { hash: 'body-a', status: 'pending', message: { id: 'placeholder', clientId: 'a', userId: 'alice',
    channel: `orgiq:huddle:${callId}`, message: 'Persist once', timestamp: new Date().toISOString(), metadata: { clientDeliveryId: 'draft-a' } } };
  try {
    const incarnation = (await first.join(callId, 'alice', candidate.message.timestamp, false)).incarnation;
    const claims = await Promise.all([first.reserve(callId, 'same-delivery', candidate, incarnation), second.reserve(callId, 'same-delivery', { ...candidate, hash: 'other' }, incarnation)]);
    expect(claims.filter(value => value.created)).toHaveLength(1); expect(claims[0]?.delivery).toEqual(claims[1]?.delivery);
    expect(claims[0]?.delivery.message.id).toBe(`huddle-00000000000000000001-${incarnation}-same-delivery`);
    const hash = claims[0]!.delivery.hash;
    await second.complete(callId, 'same-delivery', hash, 'persisted', incarnation);
    await second.join(callId, 'bob', candidate.message.timestamp, false);
    expect((await first.get(callId)).members.bob?.sequenceFrom).toBe(1);
    const next = await first.reserve(callId, 'second-delivery', candidate, incarnation);
    expect(next.delivery.message.id).toBe(`huddle-00000000000000000002-${incarnation}-second-delivery`);
    await first.leave(callId, 'bob'); await second.join(callId, 'bob', 'resume', true);
    expect((await first.get(callId)).members.bob?.sequenceFrom).toBe(1);
    await second.leave(callId, 'bob'); await first.join(callId, 'bob', 'explicit-rejoin', false);
    expect((await second.get(callId)).members.bob?.sequenceFrom).toBe(2);
    const receipt = `${key}:delivery:${incarnation}:same-delivery`;
    await one.command('EXPIRE', key, 1); await one.command('EXPIRE', receipt, 1);
    await second.keepAlive(callId);
    expect(Number(await one.command('TTL', key))).toBeGreaterThan(55); expect(Number(await one.command('TTL', receipt))).toBeGreaterThan(55);
    expect((await first.reserve(callId, 'same-delivery', candidate, incarnation)).delivery.status).toBe('persisted');
    const ended = await first.finish(callId); expect(ended).toMatchObject({ ended: true, members: {} });
    expect(await second.finish(callId)).toEqual(ended);
    await expect(second.reserve(callId, 'after-end', candidate, incarnation)).rejects.toMatchObject({ status: 404 });
    await expect(second.join(callId, 'charlie', 'after-end', false)).rejects.toMatchObject({ status: 404 });
    await first.complete(callId, 'second-delivery', 'body-a', 'cancelled', incarnation);
    await expect(second.complete(callId, 'second-delivery', 'body-a', 'persisted', incarnation)).rejects.toMatchObject({ status: 409 });
    // Durable messages/receipts can outlive this bounded floor record. A
    // new claimant must use a new partition and cannot revive an old receipt.
    await one.del(key);
    const fresh = await Promise.all([first.join(callId, 'charlie', 'fresh', false), second.join(callId, 'dana', 'fresh', false)]);
    const nextIncarnation = fresh[0]!.incarnation;
    expect(nextIncarnation).not.toBe(incarnation); expect(fresh[1]!.incarnation).toBe(nextIncarnation);
    await expect(first.reserve(callId, 'same-delivery', candidate, incarnation)).rejects.toMatchObject({ status: 409 });
    const nextClaim = await second.reserve(callId, 'same-delivery', { ...candidate, hash: 'fresh-body' }, nextIncarnation);
    expect(nextClaim.created).toBe(true); expect(nextClaim.delivery.hash).toBe('fresh-body');
    await first.complete(callId, 'same-delivery', hash, 'cancelled', incarnation);
    expect((await second.reserve(callId, 'same-delivery', candidate, nextIncarnation)).delivery.status).toBe('pending');
  } finally {
    const receipts = await one.command('SMEMBERS', `${key}:deliveries`) as string[];
    await one.del(key, `${key}:deliveries`, ...receipts).catch(() => undefined);
    await Promise.allSettled([one.quit(), two.quit()]);
  }
});
