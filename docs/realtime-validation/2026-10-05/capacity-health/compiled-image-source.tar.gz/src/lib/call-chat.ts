// A huddle is a call-scoped conversation, never the initiative's Discussion
// or the invite lobby. Client chat frames cannot write this namespace.
import { createHash } from 'node:crypto';
import type { ChatMessage, ChatStore } from '@connorhoehnslalom/realtime-modules/chat';
import type { ActiveCallStateView } from '@connorhoehnslalom/realtime-modules/call';
import { AppError } from './async-handler.js';
import { activeCallParticipant, callContextSession, callProvenance, connectedCallSession, resolveConnectedCallSession, currentCallChatGrant, currentCallAuthority,
  type CallAccessOptions, type CallAuthority } from './call-access.js';
import { canonicalCallPage, type CallPageDescriptor, type CanonicalCallPage, type CallLifecycleObserver } from './call-pages.js';
import type { Session } from './session.js';
import type { CallChatStateStore, CallChatState, CallChatMember } from './call-chat-state.js';

export const CALL_CHAT_PREFIX = 'orgiq:huddle:';
/** Also reserves malformed variants, so they cannot fall through tenant auth. */
export function inCallChatNamespace(channel: string): boolean { return channel === 'orgiq:huddle' || channel.startsWith(CALL_CHAT_PREFIX); }
export function callChatChannel(callId: string): string { return `${CALL_CHAT_PREFIX}${callId}`; }
/** Private durable partition; its lifetime is independent of membership TTL. */
export function callChatStorageChannel(callId: string, incarnation: string): string { return `${callChatChannel(callId)}:${incarnation}`; }
export interface CallChatPeer { userId: string; displayName: string }
export interface CallChatSnapshot {
  callId: string; channel: string; revision: number; participants: CallChatPeer[];
  messages: ChatMessage[]; canSend: boolean; historyFrom: string;
}
export interface CallChatSend { text: string; clientDeliveryId: string; page?: CallPageDescriptor }
export interface CallChatReceipt { callId: string; channel: string; deliveryId: string; message: ChatMessage; duplicate: boolean }
export type CallChatPageReference = ({ status: 'available' } & CanonicalCallPage) | ({ status: 'unavailable' } & CallPageDescriptor);
interface Seat { clientId: string; session: Session; authority: CallAuthority }
interface Control { generation: number; ended: boolean; departed: Set<string>; users: Map<string, string>; until: number }
class CallMembershipChanged extends AppError {
  constructor() { super(409, 'Call membership changed. Refresh the conversation.'); }
}
export interface CallChatRuntimeOptions extends CallAccessOptions {
  state: CallChatStateStore; messages: ChatStore;
  canonical?: typeof canonicalCallPage;
  grant?: typeof currentCallChatGrant;
  now?: () => number;
  maintenanceIntervalMs?: number;
}
const clone = <T>(value: T): T => structuredClone(value);
const digest = (value: string) => createHash('sha256').update(value).digest('hex');
const privateHash = (message: ChatMessage) => message.metadata?.['_requestHash'];
const sequence = (message: ChatMessage) => Number(message.metadata?.['_callSequence']);
function descriptor(raw: unknown): CallPageDescriptor | null {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const value = raw as Record<string, unknown>;
  return ['initiative', 'work-item'].includes(String(value.kind)) && typeof value.id === 'string'
    ? { kind: value.kind as CallPageDescriptor['kind'], id: value.id } : null;
}

export class CallChatRuntime implements CallLifecycleObserver {
  private readonly controls = new Map<string, Control>();
  private readonly queues = new Map<string, Promise<unknown>>();
  private readonly maintenance: ReturnType<typeof setInterval> | null;
  private disposed = false;
  constructor(private readonly opts: CallChatRuntimeOptions) {
    const interval = opts.maintenanceIntervalMs ?? 60_000;
    this.maintenance = interval > 0 ? setInterval(() => {
      for (const [id, control] of this.controls) {
        if (control.until <= this.now()) { this.controls.delete(id); continue; }
        if (!control.ended) void this.reconcile(id, true).then(() => this.opts.state.keepAlive(id)).catch(() => undefined);
      }
    }, interval) : null;
    this.maintenance?.unref?.();
  }
  private now() { return (this.opts.now ?? Date.now)(); }
  private control(callId: string): Control {
    let control = this.controls.get(callId);
    if (!control || control.until <= this.now()) {
      control = { generation: 0, ended: false, departed: new Set(), users: new Map(), until: 0 };
      this.controls.set(callId, control);
    }
    control.until = this.now() + 4 * 60 * 60 * 1000;
    return control;
  }
  private check(callId: string) {
    if (this.disposed || this.control(callId).ended) throw new AppError(404, 'Call conversation has ended');
  }
  private fence(callId: string, generation: number) {
    this.check(callId);
    if (this.control(callId).generation !== generation) throw new CallMembershipChanged();
  }
  private async lifecycle(work: () => Promise<void>) {
    try { await work(); }
    catch (error) {
      // A newer lifecycle callback owns reconciliation. The stale operation
      // stays fenced; HTTP reads/sends still receive the actionable conflict.
      if (!(error instanceof CallMembershipChanged)) throw error;
    }
  }
  private grant = (session: Session, authority: CallAuthority, action: 'ViewSocial' | 'PostMessage') =>
    (this.opts.grant ?? currentCallChatGrant)(session, authority, action);
  private enqueue<T>(callId: string, work: () => Promise<T>): Promise<T> {
    const previous = this.queues.get(callId) ?? Promise.resolve();
    const next = previous.catch(() => undefined).then(work);
    this.queues.set(callId, next);
    void next.finally(() => { if (this.queues.get(callId) === next) this.queues.delete(callId); }).catch(() => undefined);
    return next;
  }
  private async participant(callId: string, session: Session, write = false, incarnation?: string) {
    this.check(callId);
    const result = await activeCallParticipant(this.opts, callId, session);
    if (!await this.grant(session, result.authority, 'ViewSocial')
      || (write && !await this.grant(session, result.authority, 'PostMessage'))) {
      throw new AppError(403, write ? 'Your Social grants do not allow huddle messages' : 'Your Social grants do not allow huddle chat');
    }
    const current = await this.opts.calls.getCall(callId); this.check(callId);
    if (!current) throw new AppError(404, 'Call is no longer active');
    const state = await this.opts.state.get(callId); this.check(callId);
    if (state.ended) throw new AppError(404, 'Call conversation has ended');
    if (incarnation !== undefined && state.incarnation !== incarnation) throw new AppError(409, 'Call conversation changed. Refresh before sending.');
    const provenance = callProvenance(session);
    const connections = await Promise.all(current.participantClientIds.map(id => resolveConnectedCallSession(this.opts.router, id)));
    const clientIds = current.participantClientIds.filter((id, index) => !this.control(callId).departed.has(id)
      && connections[index] && callProvenance(connections[index]!) === provenance);
    if (!clientIds.length || current.lobbyName !== result.call.lobbyName) throw new AppError(403, 'Join this call before opening its conversation');
    return { ...result, call: current, clientIds, state };
  }
  private async seats(callId: string): Promise<Seat[]> {
    this.check(callId);
    const call = await this.opts.calls.getCall(callId); this.check(callId);
    if (!call) throw new AppError(404, 'Call is no longer active');
    if (!call.lobbyName.startsWith('orgiq:') || inCallChatNamespace(call.lobbyName)) throw new AppError(403, 'This call cannot open a huddle conversation');
    const seats: Seat[] = [];
    for (const clientId of call.participantClientIds) {
      const session = await resolveConnectedCallSession(this.opts.router, clientId);
      if (!session || this.control(callId).departed.has(clientId)) continue;
      try {
        const result = await this.participant(callId, session);
        if (result.clientIds.includes(clientId)) seats.push({ clientId, session, authority: result.authority });
      } catch (error) {
        if (!(error instanceof AppError) || error.status >= 500) throw error;
      }
    }
    return seats;
  }
  private peers(seats: Seat[]): CallChatPeer[] {
    return [...new Map(seats.map(seat => [seat.session.sub, { userId: seat.session.sub, displayName: seat.authority.displayName }])).values()]
      .sort((a, b) => a.userId.localeCompare(b.userId));
  }
  /** Immediately revoke the old connection, before an asynchronous store write. */
  invalidate(callId: string, clientId?: string) {
    const control = this.controls.get(callId);
    if (!control) return;
    control.generation += 1;
    if (clientId) {
      control.departed.add(clientId);
      const session = connectedCallSession(this.opts.router, clientId);
      if (session) control.users.set(clientId, session.sub);
      // No normal chat subscription should exist; remove one defensively.
      void this.opts.router.unsubscribeFromChannel?.(clientId, callChatChannel(callId));
    }
  }
  async registered(callId: string, clientId: string, preserveHistory = false) {
    return this.lifecycle(() => this.registeredCurrent(callId, clientId, preserveHistory));
  }
  private async registeredCurrent(callId: string, clientId: string, preserveHistory: boolean) {
    const call = await this.opts.calls.getCall(callId);
    // The shared call store also owns Social/document calls. They do not
    // acquire an OrgIQ huddle conversation during registration or recovery.
    if (call && !call.lobbyName.startsWith('orgiq:')) return;
    this.check(callId);
    if (!call?.participantClientIds.includes(clientId)) return;
    const control = this.control(callId); control.departed.delete(clientId); control.generation += 1;
    const session = await resolveConnectedCallSession(this.opts.router, clientId);
    if (session) control.users.set(clientId, session.sub);
    // Explicit admission resets this person's floor even if a delayed old
    // reconciliation restored an active flag after their final seat left.
    // Another actual seat (or public atomic resume) preserves their history.
    const others = session ? await Promise.all(call.participantClientIds.map(id => resolveConnectedCallSession(this.opts.router, id))) : [];
    const anotherSeat = session && call.participantClientIds.some((id, index) => id !== clientId && !control.departed.has(id)
      && others[index] && callProvenance(others[index]!) === callProvenance(session));
    if (session && !preserveHistory && !anotherSeat) {
      const generation = control.generation;
      await this.participant(callId, session); this.fence(callId, generation);
      await this.opts.state.join(callId, session.sub, new Date(this.now()).toISOString(), false); this.fence(callId, generation);
    }
    await this.reconcile(callId, true);
    await this.broadcastMembers(callId);
  }
  async removed(callId: string, clientId: string) {
    const call = await this.opts.calls.getCall(callId);
    // The library may remove the final old socket after terminal cleanup.
    // That callback cannot change a finished conversation or reopen its floor.
    if (this.disposed || this.controls.get(callId)?.ended) return;
    if ((call && !call.lobbyName.startsWith('orgiq:')) || (!call && !this.controls.has(callId))) return;
    this.check(callId);
    const userId = this.control(callId).users.get(clientId);
    // Zero seats may be recoverable. Retain floors and delivery receipts.
    const ids = call?.participantClientIds ?? [];
    const connections = await Promise.all(ids.map(id => resolveConnectedCallSession(this.opts.router, id)));
    if (userId && !ids.some((id, index) => !this.control(callId).departed.has(id)
      && connections[index]?.sub === userId)) await this.opts.state.leave(callId, userId);
    if (call?.participantClientIds.length) await this.broadcastMembers(callId);
  }
  async restored(callId: string, call: ActiveCallStateView) {
    return this.lifecycle(() => this.restoredCurrent(callId, call));
  }
  private async restoredCurrent(callId: string, call: ActiveCallStateView) {
    if (!call.lobbyName.startsWith('orgiq:')) return;
    this.check(callId); const control = this.control(callId); control.generation += 1;
    for (const id of call.participantClientIds) {
      control.departed.delete(id);
      const session = await resolveConnectedCallSession(this.opts.router, id); if (session) control.users.set(id, session.sub);
    }
    await this.reconcile(callId, true); await this.broadcastMembers(callId);
  }
  private async reconcile(callId: string, preserveHistory: boolean) {
    const generation = this.control(callId).generation;
    const seats = await this.seats(callId); this.fence(callId, generation);
    const users = new Set(seats.map(seat => seat.session.sub));
    const state = await this.opts.state.get(callId); this.fence(callId, generation);
    for (const seat of seats) {
      await this.participant(callId, seat.session); this.fence(callId, generation);
      await this.opts.state.join(callId, seat.session.sub, new Date(this.now()).toISOString(), preserveHistory);
      this.fence(callId, generation);
      this.control(callId).users.set(seat.clientId, seat.session.sub);
    }
    for (const [userId, member] of Object.entries(state.members)) {
      if (member.active && !users.has(userId)) { this.fence(callId, generation); await this.opts.state.leave(callId, userId); }
    }
  }
  private async render(callId: string, message: ChatMessage): Promise<ChatMessage> {
    const metadata: Record<string, unknown> = {};
    if (typeof message.metadata?.['displayName'] === 'string') metadata['displayName'] = message.metadata['displayName'];
    if (typeof message.metadata?.['clientDeliveryId'] === 'string') metadata['clientDeliveryId'] = message.metadata['clientDeliveryId'];
    const page = descriptor(message.metadata?.['pageReference']);
    if (page) {
      try { metadata['pageReference'] = { ...await (this.opts.canonical ?? canonicalCallPage)(page), status: 'available' }; }
      catch (error) {
        if (!(error instanceof AppError) || ![403, 404].includes(error.status)) throw error;
        metadata['pageReference'] = { ...page, status: 'unavailable' };
      }
    }
    return { ...clone(message), channel: callChatChannel(callId), metadata };
  }
  private visible(message: ChatMessage, member: CallChatMember, incarnation: string) {
    return !message.deletedAt && message.metadata?.['_callIncarnation'] === incarnation
      && Number.isSafeInteger(sequence(message)) && sequence(message) > member.sequenceFrom;
  }
  async get(callId: string, session: Session, limit = 50): Promise<CallChatSnapshot> {
    await this.participant(callId, session);
    await this.reconcile(callId, true);
    const generation = this.control(callId).generation;
    const actor = await this.participant(callId, session);
    const floor = actor.state.members[session.sub];
    if (!floor?.active) throw new AppError(403, 'Join this call before opening its conversation');
    const incarnation = actor.state.incarnation;
    let stored: ChatMessage[];
    try { stored = await this.opts.messages.listMessages(callChatStorageChannel(callId, incarnation), Math.min(100, Math.max(1, limit))); }
    catch (error) {
      if (error instanceof AppError) throw error;
      throw new AppError(503, 'Huddle history is temporarily unavailable. Try again.');
    }
    const messages = await Promise.all(stored.filter(message => this.visible(message, floor, incarnation)).map(message => this.render(callId, message)));
    const seats = await this.seats(callId);
    const canSend = await this.grant(session, actor.authority, 'PostMessage');
    const current = await this.participant(callId, session, false, incarnation); this.fence(callId, generation);
    return { callId, channel: callChatChannel(callId), revision: current.state.revision,
      participants: this.peers(seats), messages, canSend, historyFrom: floor.historyFrom };
  }
  async send(callId: string, session: Session, input: CallChatSend): Promise<CallChatReceipt> {
    return this.enqueue(callId, async () => {
      await this.participant(callId, session, true);
      if (input.page) await (this.opts.canonical ?? canonicalCallPage)(input.page);
      await this.reconcile(callId, true);
      const generation = this.control(callId).generation;
      const actor = await this.participant(callId, session, true); this.fence(callId, generation);
      const channel = callChatChannel(callId);
      const incarnation = actor.state.incarnation;
      const storageChannel = callChatStorageChannel(callId, incarnation);
      const receiptId = digest(JSON.stringify([callId, callProvenance(session), input.clientDeliveryId]));
      const hash = digest(JSON.stringify([input.text, input.page ?? null]));
      const candidate: ChatMessage = { id: receiptId, channel: storageChannel, clientId: actor.clientIds[0]!, userId: session.sub,
        message: input.text, timestamp: new Date(this.now()).toISOString(), metadata: {
          displayName: actor.authority.displayName, clientDeliveryId: input.clientDeliveryId, _requestHash: hash,
          _senderContext: { userId: session.sub, org: session.tenant, role: session.role, epoch: session.epoch ?? 0,
            sessionIat: session.iat, ...(session.act ? { act: { sub: session.act.sub, epoch: session.act.epoch ?? 0 } } : {}) },
          ...(input.page ? { pageReference: input.page } : {}),
        } };
      if (!this.opts.messages.getMessage) throw new AppError(503, 'This chat store cannot confirm message delivery');
      const reservation = await this.opts.state.reserve(callId, receiptId, { hash, message: candidate, status: 'pending' }, incarnation);
      const { delivery } = reservation;
      if (delivery.hash !== hash || delivery.status === 'cancelled') throw new AppError(409, 'This delivery id already belongs to another message');
      const id = delivery.message.id;
      let prior: ChatMessage | null;
      try { prior = await this.opts.messages.getMessage(storageChannel, id); }
      catch (error) {
        if (error instanceof AppError) throw error;
        throw new AppError(503, 'The previous delivery could not be confirmed. Your draft has been kept.');
      }
      if (prior && (privateHash(prior) !== hash || prior.deletedAt)) throw new AppError(409, 'This delivery id already belongs to another message');
      // A receipt can outlive a transient backend or a message's own TTL.
      // Only the authoritative message read proves that replay still exists.
      let persisted = !!prior;
      try {
        await this.participant(callId, session, true, incarnation); this.fence(callId, generation);
        if (!persisted) {
          try { await this.opts.messages.putMessage(delivery.message); }
          catch { throw new AppError(503, 'The message could not be stored. Your draft has been kept.'); }
          persisted = true;
        }
        await this.participant(callId, session, true, incarnation); this.fence(callId, generation);
        await this.opts.state.complete(callId, receiptId, hash, 'persisted', incarnation);
        const current = await this.participant(callId, session, true, incarnation); this.fence(callId, generation);
        const member = current.state.members[session.sub];
        if (!member || !this.visible(delivery.message, member, incarnation)) throw new AppError(409, 'This message is outside your current huddle history');
        const message = await this.render(callId, delivery.message);
        await this.participant(callId, session, true, incarnation); this.fence(callId, generation);
        await this.broadcastMessage(callId, delivery.message, session);
        await this.participant(callId, session, true, incarnation); this.fence(callId, generation);
        return { callId, channel, deliveryId: input.clientDeliveryId, message, duplicate: !reservation.created };
      } catch (error) {
        // If the sender loses membership/authority during persistence, do not
        // leave an unacknowledged publish in the replay history.
        if (persisted && !prior && error instanceof AppError && error.status < 500) {
          await this.opts.state.complete(callId, receiptId, hash, 'cancelled', incarnation).catch(() => undefined);
          await this.opts.messages.updateMessage(storageChannel, id, { message: '', metadata: { deleted: true },
            deletedAt: new Date(this.now()).toISOString() });
        }
        throw error;
      }
    });
  }
  private async broadcastMessage(callId: string, stored: ChatMessage, sender: Session) {
    const incarnation = String(stored.metadata?.['_callIncarnation'] ?? '');
    const seats = await this.seats(callId);
    for (const seat of seats) {
      try {
        const member = (await this.participant(callId, seat.session, false, incarnation)).state.members[seat.session.sub];
        if (!member || !this.visible(stored, member, incarnation)) continue;
        const message = await this.render(callId, stored);
        // Canonical/resource reads can outlive revocation, leave, or end.
        await this.participant(callId, sender, true, incarnation);
        const current = await this.participant(callId, seat.session, false, incarnation);
        const connected = await resolveConnectedCallSession(this.opts.router, seat.clientId);
        if (!current.clientIds.includes(seat.clientId) || !connected
          || callProvenance(connected) !== callProvenance(seat.session)) continue;
        await this.opts.router.sendToClient(seat.clientId, { type: 'chat', action: 'message', callId, channel: callChatChannel(callId), message });
      } catch (error) {
        if (!(error instanceof AppError) || error.status >= 500) throw error;
      }
    }
  }
  /** Application data gets a fresh, asynchronous destination fence as well
   * as the producer checks. Stored private sender provenance is never rendered. */
  async filterFrame(clientId: string, frame: Record<string, unknown>): Promise<unknown | null> {
    if (this.disposed || typeof frame.callId !== 'string') return null;
    const session = await resolveConnectedCallSession(this.opts.router, clientId);
    if (!session) return null;
    const callId = frame.callId;
    if (frame.type === 'call-chat' && frame.action === 'ended') {
      const authority = await (this.opts.authority ?? currentCallAuthority)(session);
      const state = await this.opts.state.get(callId);
      return state.ended && await this.grant(session, authority, 'ViewSocial')
        ? { type: 'call-chat', action: 'ended', callId, channel: callChatChannel(callId), revision: state.revision } : null;
    }
    const actor = await this.participant(callId, session);
    if (frame.type === 'call-chat' && frame.action === 'members') {
      const seats = await this.seats(callId);
      const current = await this.participant(callId, session);
      return { ...frame, revision: current.state.revision, participants: this.peers(seats) };
    }
    if (frame.type !== 'chat' || frame.action !== 'message' || frame.channel !== callChatChannel(callId)) return null;
    const message = frame.message as { id?: unknown } | null;
    if (!message || typeof message.id !== 'string' || !this.opts.messages.getMessage) return null;
    const incarnation = actor.state.incarnation;
    const storageChannel = callChatStorageChannel(callId, incarnation);
    const stored = await this.opts.messages.getMessage(storageChannel, message.id);
    const member = actor.state.members[session.sub];
    if (!stored || !member || !this.visible(stored, member, incarnation)) return null;
    const sender = callContextSession(stored.metadata?.['_senderContext'] as Record<string, unknown> | undefined)
      ?? await resolveConnectedCallSession(this.opts.router, stored.clientId);
    if (!sender || sender.sub !== stored.userId) return null;
    await this.participant(callId, sender, true, incarnation);
    const rendered = await this.render(callId, stored);
    await this.participant(callId, sender, true, incarnation);
    const current = await this.participant(callId, session, false, incarnation);
    const latest = await this.opts.messages.getMessage(storageChannel, message.id);
    const latestMember = current.state.members[session.sub];
    if (!latest || !latestMember || !this.visible(latest, latestMember, incarnation)
      || privateHash(latest) !== privateHash(stored)) return null;
    return { ...frame, message: rendered };
  }
  private async broadcastMembers(callId: string) {
    const generation = this.control(callId).generation;
    const seats = await this.seats(callId); const participants = this.peers(seats);
    for (const seat of seats) {
      try {
        const current = await this.participant(callId, seat.session); this.fence(callId, generation);
        if (current.clientIds.includes(seat.clientId)) await this.opts.router.sendToClient(seat.clientId,
          { type: 'call-chat', action: 'members', callId, channel: callChatChannel(callId), revision: current.state.revision, participants });
      } catch (error) { if (!(error instanceof AppError) || error.status >= 500) throw error; }
    }
  }
  async finish(callId: string, participantClientIds: string[] = []) {
    const control = this.control(callId); control.ended = true; control.generation += 1;
    const state: CallChatState = await this.opts.state.finish(callId);
    for (const clientId of participantClientIds) {
      const session = await resolveConnectedCallSession(this.opts.router, clientId); if (!session) continue;
      try {
        const authority = await (this.opts.authority ?? currentCallAuthority)(session);
        if (await this.grant(session, authority, 'ViewSocial')) await this.opts.router.sendToClient(clientId,
          { type: 'call-chat', action: 'ended', callId, channel: callChatChannel(callId), revision: state.revision });
      } catch { /* Terminal metadata contains no message or page contents. */ }
    }
  }
  dispose() {
    this.disposed = true; if (this.maintenance) clearInterval(this.maintenance);
    this.controls.clear(); this.opts.state.dispose?.();
  }
}
let runtime: CallChatRuntime | null = null;
export function setCallChatRuntime(value: CallChatRuntime | null) { runtime = value; }
export function callChatRuntime(): CallChatRuntime {
  if (!runtime) throw new AppError(503, 'Huddle chat is unavailable'); return runtime;
}
