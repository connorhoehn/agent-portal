// Full-process contracts; shared fixture code uses real local transports.
import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import WebSocket from 'ws';
import { bases, db, durable, pause, until, request, login, connect, send, call, close, upgradeStatus, seedUser, execute } from './bff-cluster-fixture.mjs';

test('two full BFFs share protected huddle messages and canonical Work pages', async () => {
  const alice = await connect(await login(0, 'u-theo')), bob = await connect(await login(1, 'u-vera'));
  try {
    const callId = await call(alice, bob);
    const sent = await request(alice, `/api/calls/${callId}/chat/messages`, 'POST', { text: 'Native peer huddle', clientDeliveryId: randomUUID() });
    assert.equal(sent.status, 201);
    await until(() => bob.frames.some(frame => frame.message?.id === sent.body.message.id), 'actual peer message');
    const delivered = bob.frames.find(frame => frame.message?.id === sent.body.message.id).message;
    assert.equal(delivered.userId, alice.userId);
    assert.equal(delivered.metadata._senderContext, undefined, 'private sender proof stays server-side');
    const page = await request(alice, `/api/calls/${callId}/page`, 'PUT', { expectedRevision: 0, page: { kind: 'work-item', id: 'cluster-work' } });
    assert.equal(page.status, 200);
    await until(() => bob.frames.some(frame => frame.type === 'call-page' && frame.page?.id === 'cluster-work'), 'peer canonical page');
    assert.equal((await request(alice, `/api/calls/${callId}/page`, 'GET', undefined, bob.base)).body.page.id, 'cluster-work');
    assert.equal((await request(bob, `/api/calls/${callId}/page`, 'DELETE', { expectedRevision: page.body.revision })).status, 403, 'peer cannot take caller stop rights');
    assert.equal((await request(alice, `/api/calls/${callId}/page`, 'DELETE', { expectedRevision: page.body.revision }, bob.base)).status, 200, 'caller can stop via the peer BFF');
    await until(() => bob.frames.some(frame => frame.type === 'call-page' && frame.revision > page.body.revision && frame.page === null), 'peer clear');
    const remoteHistory = await request(alice, `/api/calls/${callId}/chat`, 'GET', undefined, bob.base);
    assert.equal(remoteHistory.status, 200);
    assert.ok(remoteHistory.body.messages.some(message => message.id === sent.body.message.id));
  } finally { close(alice, bob); }
});

test('both BFFs refuse a retired real directory epoch and retain protected history', async () => {
  const alice = await connect(await login(0, 'u-theo')), bob = await connect(await login(1, 'u-vera'));
  const original = (await db.query('SELECT session_epoch FROM app_users WHERE id=$1', [alice.userId])).rows[0].session_epoch;
  try {
    const callId = await call(alice, bob);
    const first = await request(alice, `/api/calls/${callId}/chat/messages`, 'POST', { text: 'Before directory retirement', clientDeliveryId: randomUUID() });
    assert.equal(first.status, 201);
    await db.query('UPDATE app_users SET session_epoch=session_epoch+1 WHERE id=$1', [alice.userId]);
    for (const base of bases) assert.equal((await request(alice, `/api/calls/${callId}/chat`, 'GET', undefined, base)).status, 401);
    const start = alice.frames.length;
    const sent = await request(bob, `/api/calls/${callId}/chat/messages`, 'POST', { text: 'After directory retirement', clientDeliveryId: randomUUID() });
    assert.equal(sent.status, 201);
    await pause(200);
    assert.equal(alice.frames.slice(start).some(frame => frame.message?.id === sent.body.message.id), false);
    const history = await request(bob, `/api/calls/${callId}/chat`);
    assert.equal(history.status, 200);
    assert.ok(history.body.messages.some(message => message.id === first.body.message.id), 'retirement preserves durable history');
    assert.equal(await upgradeStatus(alice), 401, 'retired JWT cannot upgrade on the other BFF');
  } finally { await db.query('UPDATE app_users SET session_epoch=$2 WHERE id=$1', [alice.userId, original]); close(alice, bob); }
});

test('forged caller and foreign lobby frames cannot cross the application boundary', async () => {
  const alice = await connect(await login(0, 'u-theo')), bob = await connect(await login(1, 'u-vera'));
  try {
    for (const [callerId, lobbyName] of [['u-vera', 'orgiq:initiative:cluster-project'], ['u-theo', 'assessment:private']]) {
      const callId = randomUUID(), start = alice.frames.length;
      send(alice, { service: 'call', action: 'invite', callerId, lobbyName, callId, targetUserIds: [bob.userId] });
      await until(() => alice.frames.slice(start).some(frame => frame.type === 'error'), 'source action refusal');
      await pause(100);
      assert.equal(bob.frames.some(frame => frame.data?.callId === callId), false);
    }
  } finally { close(alice, bob); }
});

test('a private channel created on one BFF is visible remotely and its remote leave revokes delivery', async () => {
  await seedUser('cluster-moderator', [['social', 'moderator'], ['orgiq', 'member']]);
  const owner = await connect(await login(0, 'cluster-moderator', 'social')), bob = await connect(await login(1, 'u-vera', 'social'));
  try {
    const created = await request(owner, '/api/social/channels', 'POST', { name: 'Peer ' + randomUUID().slice(0, 12), privacy: 'private' });
    assert.equal(created.status, 201);
    const { channel, slug } = created.body.channel;
    assert.equal((await request(bob, `/api/social/channels/${slug}`)).status, 404, 'private directory stays hidden');
    send(owner, { service: 'chat', action: 'join', channel });
    await until(() => owner.frames.some(frame => frame.action === 'joined' && frame.channel === channel), 'owner join');
    send(owner, { service: 'chat', action: 'addMembers', channel, userIds: [bob.userId], history: { mode: 'all' } });
    await until(async () => (await durable.members.getMember(channel, bob.userId))?.removedAt === null, 'durable member addition');
    assert.equal((await request(bob, `/api/social/channels/${slug}`)).status, 200, 'remote mirror refresh');
    send(bob, { service: 'chat', action: 'join', channel });
    await until(() => bob.frames.some(frame => frame.action === 'joined' && frame.channel === channel), 'peer private join');
    const left = await request(bob, `/api/social/channels/${slug}/leave`, 'POST', {}, owner.base);
    assert.equal(left.status, 200, 'membership is changed through the other full BFF');
    assert.equal((await request(bob, `/api/social/channels/${slug}`)).status, 404, 'completed removal is observed locally');
    const start = bob.frames.length;
    send(owner, { service: 'chat', action: 'send', channel, message: 'Private after leave', metadata: { clientDeliveryId: randomUUID() } });
    await until(async () => (await durable.listMessages(channel, 10)).some(message => message.message === 'Private after leave'), 'persisted source write');
    await pause(200);
    assert.equal(bob.frames.slice(start).some(frame => frame.action === 'message' && frame.channel === channel), false, 'last-mile member refusal');
  } finally { close(owner, bob); }
});

test('shared presence on the other BFF uses real identity and omits a revoked source', async () => {
  const alice = await connect(await login(0, 'u-theo')), bob = await connect(await login(1, 'u-vera'));
  const original = (await db.query('SELECT session_epoch FROM app_users WHERE id=$1', [alice.userId])).rows[0].session_epoch;
  const channel = 'orgiq:initiative:cluster-project';
  try {
    for (const peer of [alice, bob]) send(peer, { service: 'presence', action: 'set', status: 'online', channels: [channel], metadata: { userId: 'forged' } });
    await until(() => [alice, bob].every(peer => peer.frames.some(frame => frame.action === 'set' && frame.presence?.channels.includes(channel))), 'shared presence writes');
    async function roster() {
      const start = bob.frames.length; send(bob, { service: 'presence', action: 'get', channel });
      await until(() => bob.frames.slice(start).some(frame => frame.action === 'presence'), 'peer roster read');
      return bob.frames.slice(start).find(frame => frame.action === 'presence').data;
    }
    const before = await roster();
    assert.deepEqual(before.map(row => row.userId).sort(), ['u-theo', 'u-vera']);
    assert.equal(before.find(row => row.userId === 'u-theo').metadata.userId, 'u-theo');
    await db.query('UPDATE app_users SET session_epoch=session_epoch+1 WHERE id=$1', [alice.userId]);
    assert.deepEqual((await roster()).map(row => row.userId), ['u-vera']);
  } finally { await db.query('UPDATE app_users SET session_epoch=$2 WHERE id=$1', [alice.userId, original]); close(alice, bob); }
});

test('a missed-call notification reaches a peer BFF and replays from the shared inbox', async () => {
  const alice = await connect(await login(0, 'u-theo')), principal = await login(1, 'u-vera'), bob = await connect(principal);
  let returned;
  try {
    const callId = randomUUID(), lobbyName = 'orgiq:initiative:cluster-project';
    send(alice, { service: 'call', action: 'invite', callId, lobbyName, callerId: alice.userId, targetUserIds: [bob.userId] });
    await until(() => bob.frames.some(frame => frame.action === 'invite' && frame.data?.callId === callId), 'notification call invite');
    send(bob, { service: 'call', action: 'declined', callId, lobbyName, callerId: bob.userId, targetUserIds: [alice.userId] });
    await until(() => alice.frames.some(frame => frame.action === 'declined' && frame.data?.callId === callId), 'peer decline');
    send(alice, { service: 'call', action: 'cancelled', callId, lobbyName, callerId: alice.userId, targetUserIds: [bob.userId] });
    await until(() => bob.frames.some(frame => frame.type === 'notification:new' && frame.payload?.payload?.callId === callId), 'peer live inbox delivery');
    const record = bob.frames.find(frame => frame.type === 'notification:new' && frame.payload?.payload?.callId === callId).payload;
    assert.equal(record.payload.tenant, 'orgiq');
    close(bob);
    returned = await connect({ ...principal, base: bases[0] });
    await until(() => returned.frames.some(frame => frame.type === 'notification:bulk-update' && frame.payload.notifications.some(item => item.id === record.id)), 'unread replay on the other BFF');
  } finally { close(alice, bob); if (returned) close(returned); }
});

test('retiring the real masquerade operator blocks admission on both BFFs', async () => {
  await seedUser('cluster-operator', [['orgiq', 'admin']]);
  const operator = await login(0, 'cluster-operator');
  const original = (await db.query('SELECT session_epoch FROM app_users WHERE id=$1', ['cluster-operator'])).rows[0].session_epoch;
  try {
    assert.equal((await request(operator, '/api/session/masquerade', 'POST', { userId: 'u-theo' })).status, 200);
    const issued = await request(operator, '/api/session/realtime-token');
    assert.equal(issued.status, 200);
    const claims = JSON.parse(Buffer.from(issued.body.token.split('.')[1], 'base64url').toString());
    assert.equal(claims.sub, 'u-theo'); assert.equal(claims.act.sub, 'cluster-operator');
    const impersonation = { ...operator, token: issued.body.token };
    assert.equal(await upgradeStatus(impersonation, 1), 101, 'current operator provenance is admitted');
    await db.query('UPDATE app_users SET session_epoch=session_epoch+1 WHERE id=$1', ['cluster-operator']);
    for (const node of [0, 1]) assert.equal(await upgradeStatus(impersonation, node), 401, 'operator epoch is authoritative across both processes');
  } finally { await db.query('UPDATE app_users SET session_epoch=$2 WHERE id=$1', ['cluster-operator', original]); }
});

test('an abruptly lost BFF returns under a new owner and restores the same authenticated call seat', {
  skip: process.env.ORGIQ_BFF_CLUSTER_CRASH_ACCEPTANCE !== '1', timeout: 60000,
}, async () => {
  if (!process.env.ORGIQ_BFF_RUNTIME_ENV_FILE) throw new Error('Crash acceptance requires the private owned runtime profile');
  const alice = await connect(await login(0, 'u-theo')), principal = await login(1, 'u-vera'), bob = await connect(principal);
  let returned;
  try {
    const callId = await call(alice, bob), lobbyName = 'orgiq:initiative:cluster-project';
    const page = await request(alice, `/api/calls/${callId}/page`, 'PUT', { expectedRevision: 0, page: { kind: 'work-item', id: 'cluster-work' } });
    assert.equal(page.status, 200);
    const stored = await request(alice, `/api/calls/${callId}/chat/messages`, 'POST', { text: 'Before BFF crash', clientDeliveryId: randomUUID() });
    assert.equal(stored.status, 201);
    await until(() => bob.frames.some(frame => frame.message?.id === stored.body.message.id), 'pre-crash actual peer write');
    const pid = Number((await readFile('/tmp/orgiq-bff-cluster-b.pid', 'utf8')).trim());
    assert.ok(Number.isSafeInteger(pid) && pid > 1);
    const argv = (await execute('ps', ['-p', String(pid), '-o', 'args='])).stdout.trim();
    const cwd = (await execute('lsof', ['-a', '-p', String(pid), '-d', 'cwd', '-Fn'])).stdout;
    const listening = (await execute('lsof', ['-nP', '-iTCP:3064', '-sTCP:LISTEN', '-Fp'])).stdout;
    assert.equal(argv, 'node --import ./test-support/native-rds-preload.mjs --import tsx src/index.ts');
    assert.ok(cwd.includes('n' + fileURLToPath(new URL('../', import.meta.url)).replace(/\/$/, '')));
    assert.ok(listening.split('\n').includes('p' + pid));
    process.kill(pid, 'SIGKILL');
    await until(() => bob.ws.readyState === WebSocket.CLOSED, 'lost owner socket close');
    // Default production-sized owner/client leases are 30 seconds. Let them
    // expire naturally; the test neither reads nor edits private router keys.
    await pause(31000);
    const restarted = await execute('python3', [fileURLToPath(new URL('./bff-cluster-processes.py', import.meta.url)), 'b']);
    assert.ok(restarted.stdout.includes('Started owned BFF b'));
    await until(async () => { try { return (await fetch(bases[1] + '/api/session/me')).status === 200; } catch { return false; } }, 'replacement BFF admission');
    returned = await connect(principal);
    assert.notEqual(returned.id, bob.id, 'new connection generation');
    send(returned, { service: 'call', action: 'participant-state', callId, lobbyName,
      callerId: returned.userId, userId: returned.userId, status: 'in-call', targetUserIds: [alice.userId] });
    await until(async () => {
      const history = await request(returned, `/api/calls/${callId}/chat`);
      return history.status === 200 && history.body.participants?.length === 2;
    }, 'authenticated durable call seat recovery');
    const restoredPage = await request(returned, `/api/calls/${callId}/page`);
    assert.equal(restoredPage.status, 200); assert.equal(restoredPage.body.page.id, 'cluster-work');
    assert.equal(restoredPage.body.revision, page.body.revision);
    const sent = await request(alice, `/api/calls/${callId}/chat/messages`, 'POST', { text: 'After BFF replacement', clientDeliveryId: randomUUID() });
    assert.equal(sent.status, 201);
    await until(() => returned.frames.some(frame => frame.message?.id === sent.body.message.id), 'actual delivery to replacement owner');
    const history = await request(alice, `/api/calls/${callId}/chat`);
    assert.ok(history.body.messages.some(message => message.id === stored.body.message.id), 'crash preserves durable history');
    assert.ok(history.body.messages.some(message => message.id === sent.body.message.id));
  } finally { close(alice, bob); if (returned) close(returned); }
});
