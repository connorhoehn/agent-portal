// Full-process acceptance only: replace the RDS SDK transport while executing
// the provider's actual SQL against the dedicated local PostgreSQL database.
// No installed SDK files are changed. This is not Aurora/IAM acceptance.
import { Pool } from 'pg';
import { randomUUID } from 'node:crypto';
import { RDSDataClient } from '@aws-sdk/client-rds-data';

const locator = process.env.ORGIQ_NATIVE_RDS_URL;
if (!locator) throw new Error('Native RDS acceptance requires ORGIQ_NATIVE_RDS_URL');
const url = new URL(locator);
if (process.env.NODE_ENV === 'production' || !['postgres:', 'postgresql:'].includes(url.protocol)
  || !['localhost', '127.0.0.1', '[::1]', '::1'].includes(url.hostname)) {
  throw new Error('Native RDS acceptance is restricted to non-production loopback PostgreSQL');
}
const pool = new Pool({ connectionString: locator, max: 4, connectionTimeoutMillis: 2000, statement_timeout: 5000 });
const transactions = new Map();
function value(field) {
  if (!field || field.isNull) return null;
  for (const key of ['stringValue', 'longValue', 'doubleValue', 'booleanValue', 'blobValue']) {
    if (field[key] !== undefined) return field[key];
  }
  if (field.arrayValue) {
    for (const key of ['stringValues', 'longValues', 'doubleValues', 'booleanValues']) {
      if (field.arrayValue[key] !== undefined) return field.arrayValue[key];
    }
  }
  throw new Error('Unsupported native RDS parameter type');
}
function bind(sql, parameters = []) {
  const params = new Map(parameters.map(parameter => [parameter.name, value(parameter.value)]));
  const positions = new Map(), values = [];
  let result = '', i = 0, quote = null;
  while (i < sql.length) {
    const char = sql[i], next = sql[i + 1];
    if (quote) {
      result += char; i++;
      if (char === quote) {
        if (sql[i] === quote) { result += sql[i++]; } else quote = null;
      }
      continue;
    }
    if (char === "'" || char === '"') { quote = char; result += char; i++; continue; }
    if (char === '-' && next === '-') {
      const end = sql.indexOf('\n', i); const stop = end < 0 ? sql.length : end;
      result += sql.slice(i, stop); i = stop; continue;
    }
    if (char === '/' && next === '*') {
      const end = sql.indexOf('*/', i + 2); if (end < 0) throw new Error('Unclosed SQL comment');
      result += sql.slice(i, end + 2); i = end + 2; continue;
    }
    if (char === ':' && next !== ':' && sql[i - 1] !== ':') {
      const name = /^([a-zA-Z_][a-zA-Z0-9_]*)/.exec(sql.slice(i + 1))?.[1];
      if (name) {
        if (!params.has(name)) throw new Error(`Unbound native RDS parameter ${name}`);
        if (!positions.has(name)) { values.push(params.get(name)); positions.set(name, values.length); }
        result += `$${positions.get(name)}`; i += name.length + 1; continue;
      }
    }
    result += char; i++;
  }
  return { text: result, values };
}
function cell(data, oid) {
  if (data === null || data === undefined) return { isNull: true };
  if (typeof data === 'boolean') return { booleanValue: data };
  if (typeof data === 'number') return Number.isSafeInteger(data) ? { longValue: data } : { doubleValue: data };
  if (data instanceof Date) return { stringValue: data.toISOString() };
  if (Buffer.isBuffer(data)) return { blobValue: data };
  if (typeof data === 'object') return { stringValue: JSON.stringify(data) };
  if ([20, 21, 23, 700, 701, 1700].includes(oid)) {
    const number = Number(data);
    if (Number.isFinite(number) && (oid !== 20 || Number.isSafeInteger(number))) {
      return Number.isSafeInteger(number) ? { longValue: number } : { doubleValue: number };
    }
  }
  return { stringValue: String(data) };
}
RDSDataClient.prototype.send = async function(command) {
  const input = command.input;
  const kind = command.constructor.name;
  if (kind === 'BeginTransactionCommand') {
    const client = await pool.connect(); await client.query('BEGIN');
    const id = randomUUID(); transactions.set(id, client); return { transactionId: id };
  }
  if (kind === 'CommitTransactionCommand' || kind === 'RollbackTransactionCommand') {
    const client = transactions.get(input.transactionId);
    if (!client) throw new Error('Unknown native RDS transaction');
    try { await client.query(kind === 'CommitTransactionCommand' ? 'COMMIT' : 'ROLLBACK'); }
    finally { transactions.delete(input.transactionId); client.release(); }
    return { transactionStatus: 'Transaction Complete' };
  }
  if (typeof input.sql !== 'string') throw new Error(`Unsupported native RDS command ${kind}`);
  const connection = input.transactionId ? transactions.get(input.transactionId) : pool;
  if (!connection) throw new Error('Unknown native RDS transaction');
  const result = await connection.query({ ...bind(input.sql, input.parameters), rowMode: 'array' });
  if (Array.isArray(result)) throw new Error('Native RDS statement must have one result');
  return { records: result.rows.map(row => row.map((data, index) => cell(data, result.fields[index].dataTypeID))),
    numberOfRecordsUpdated: result.rowCount ?? 0,
    columnMetadata: result.fields.map(field => ({ name: field.name, label: field.name })) };
};
console.log('[native-rds-acceptance] provider SQL transport connected to dedicated loopback PostgreSQL');
