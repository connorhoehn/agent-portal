// Current call identity is shared by page pins and huddle chat. Token claims
// establish provenance; directory epochs/grants establish current authority.
import type { ActiveCallStateView, CallStateStore } from '@connorhoehnslalom/realtime-modules/call';
import type { RealtimeRouter } from '@connorhoehnslalom/realtime-modules/server';
import { AppError } from './async-handler.js';
import { currentDocumentSessionEpoch, documentSessionId } from './document-session.js';
import { getUser } from '../providers/identity.js';
import { DEMO_SUB, demoFallbackAllowed, type Grants, type Session } from './session.js';
import { isAllowed } from './authz.js';

export interface CallAuthority { displayName: string; grants: Grants }
export async function currentCallAuthority(session: Session): Promise<CallAuthority> {
  if (session.tenant !== 'orgiq') throw new AppError(403, 'This call requires an OrgIQ session');
  try {
    const isDemo = session.sub === DEMO_SUB && process.env['NODE_ENV'] !== 'production' && demoFallbackAllowed();
    if (isDemo) {
      if (await currentDocumentSessionEpoch(session.sub, session.tenant, documentSessionId(session)) === null) {
        throw new AppError(401, 'The session is no longer current. Sign in again.');
      }
      return { displayName: session.name ?? session.sub, grants: session.grants };
    }
    const [user, actor] = await Promise.all([
      getUser(session.sub, { authoritative: true }),
      session.act ? getUser(session.act.sub, { authoritative: true }) : Promise.resolve(null),
    ]);
    if (!user || user.epoch !== (session.epoch ?? 0) || !user.grants[session.tenant]?.includes(session.role)
      || (session.act && (!actor || actor.epoch !== (session.act.epoch ?? 0)
        || !Object.values(actor.grants).some(roles => roles.includes('admin'))))) {
      throw new AppError(401, 'The session is no longer current. Sign in again.');
    }
    return { displayName: user.displayName, grants: user.grants };
  } catch (error) {
    if (error instanceof AppError) throw error;
    throw new AppError(503, 'The identity store is unavailable');
  }
}

export function callContextSession(ctx: Record<string, unknown> | undefined): Session | null {
  if (!ctx || typeof ctx.userId !== 'string' || ctx.org !== 'orgiq' || typeof ctx.role !== 'string') return null;
  if (!Number.isSafeInteger(ctx.epoch) || Number(ctx.epoch) < 0) return null;
  const act = ctx.act as { sub?: unknown; epoch?: unknown } | undefined;
  if (act && (typeof act.sub !== 'string' || !Number.isSafeInteger(act.epoch) || Number(act.epoch) < 0)) return null;
  return {
    sub: ctx.userId, name: typeof ctx.displayName === 'string' ? ctx.displayName : undefined,
    tenant: 'orgiq', role: ctx.role as Session['role'], epoch: Number(ctx.epoch),
    grants: { orgiq: [ctx.role] }, iat: Number(ctx.sessionIat) || 0,
    ...(act ? { act: { sub: act.sub as string, epoch: Number(act.epoch), role: 'admin' as const,
      tenant: 'orgiq' as const, grants: {} } } : {}),
  };
}
export function callProvenance(session: Session): string {
  return JSON.stringify([session.sub, session.tenant, session.role, session.epoch ?? 0, session.act?.sub ?? null, session.act?.epoch ?? 0]);
}
export function connectedCallSession(router: RealtimeRouter, clientId: string): Session | null {
  return router.isClientLive?.(clientId) === true ? callContextSession(router.getClientData?.(clientId)?.userContext) : null;
}
/** REST-originated readers need the owning replica's current registration.
 * Keep the synchronous helper for immediate local disconnect invalidation. */
export async function resolveConnectedCallSession(router: RealtimeRouter, clientId: string): Promise<Session | null> {
  if (!router.resolveClientData) return connectedCallSession(router, clientId);
  try {
    const data = await router.resolveClientData(clientId);
    if (!data?.userContext || router.getClientData?.(clientId)?.userContext !== data.userContext) return null;
    return callContextSession(data.userContext);
  } catch { throw new AppError(503, 'The call connection directory is unavailable'); }
}

export interface CallAccessOptions {
  calls: CallStateStore;
  router: RealtimeRouter;
  lobbyAllowed: (auth: Record<string, unknown>, lobby: string) => boolean;
  authority?: typeof currentCallAuthority;
}
export async function activeCallParticipant(opts: CallAccessOptions, callId: string, session: Session): Promise<{
  call: ActiveCallStateView; authority: CallAuthority; clientIds: string[];
}> {
  const authority = await (opts.authority ?? currentCallAuthority)(session);
  const call = await opts.calls.getCall(callId);
  if (!call) throw new AppError(404, 'Call is no longer active');
  if (!call.lobbyName.startsWith('orgiq:')) throw new AppError(403, 'This call requires an OrgIQ lobby');
  const key = callProvenance(session);
  const connected = await Promise.all(call.participantClientIds.map(id => resolveConnectedCallSession(opts.router, id)));
  const clientIds = call.participantClientIds.filter((_, index) => connected[index] && callProvenance(connected[index]!) === key);
  if (!clientIds.length || !opts.lobbyAllowed({ userId: session.sub, org: session.tenant, role: session.role,
    tenants: Object.keys(authority.grants) }, call.lobbyName)) throw new AppError(403, 'Join this call before opening its conversation');
  return { call, authority, clientIds };
}

/** Social embedding evaluates the current grants without changing context. */
export async function currentCallChatGrant(session: Session, authority: CallAuthority, action: 'ViewSocial' | 'PostMessage'): Promise<boolean> {
  for (const role of authority.grants['social'] ?? []) {
    if (await isAllowed({ sub: session.sub, tenant: 'social', role }, action)) return true;
  }
  return false;
}
