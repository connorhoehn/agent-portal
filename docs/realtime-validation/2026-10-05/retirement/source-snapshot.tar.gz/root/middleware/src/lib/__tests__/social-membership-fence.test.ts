jest.mock('../../config.js', () => ({ config: { region: 'us-east-1', mock: { aurora: true } } }));
import type { ChatMember, ChatMembershipStore } from '@connorhoehnslalom/realtime-modules/chat';
import { MirroredMembershipStore } from '../social-chat.js';

it('a delayed durable hydrate cannot revive membership after a newer successful local removal', async () => {
  const row: ChatMember = { channel: 'social:ch:private', userId: 'alice', role: 'member', addedBy: 'bob',
    addedAt: '2026-10-03T00:00:00.000Z', historyFrom: null, removedAt: null };
  const rows = [structuredClone(row)]; let release!: () => void; let start!: () => void;
  const waiting = new Promise<void>(resolve => { release = resolve; }); const started = new Promise<void>(resolve => { start = resolve; });
  const persist: ChatMembershipStore = { listMembers: async () => { start(); await waiting; return [structuredClone(row)]; },
    getMember: async () => row, putMember: async () => undefined };
  const store = new MirroredMembershipStore(() => rows, persist);
  const proof = store.observeChanges(row.channel); const pending = store.hydrate(row.channel); await started;
  await store.putMember({ ...row, removedAt: '2026-10-03T01:00:00.000Z' }); expect(proof.changed()).toBe(true);
  release(); await pending; expect(store.isActiveMember(row.channel, 'alice')).toBe(false); proof.dispose();
});

it('failed durable membership writes do not invalidate an unchanged current proof', async () => {
  const row: ChatMember = { channel: 'social:dm:alice:bob', userId: 'alice', role: 'member', addedBy: 'bob',
    addedAt: '2026-10-03T00:00:00.000Z', historyFrom: null, removedAt: null };
  const persist: ChatMembershipStore = { listMembers: async () => [row], getMember: async () => row,
    putMember: async () => { throw new Error('Dynamo unavailable'); } };
  const store = new MirroredMembershipStore(() => [], persist); const proof = store.observeChanges(row.channel);
  try {
    await expect(store.putMember({ ...row, removedAt: 'now' })).rejects.toThrow('Dynamo unavailable');
    expect(proof.changed()).toBe(false);
  } finally { proof.dispose(); }
});

it('fresh channel reads observe a committed remote removal without an invalidation hint', async () => {
  const row: ChatMember = { channel: 'social:ch:private', userId: 'alice', role: 'member', addedBy: 'bob',
    addedAt: '2026-10-05T00:00:00.000Z', historyFrom: null, removedAt: null };
  const durable = [structuredClone(row)], mirror = [structuredClone(row)];
  const persist: ChatMembershipStore = { listMembers: async () => structuredClone(durable), getMember: async () => durable[0], putMember: async () => undefined };
  const store = new MirroredMembershipStore(() => mirror, persist);
  durable[0].removedAt = '2026-10-05T01:00:00.000Z';
  expect(store.isActiveMember(row.channel, 'alice')).toBe(true);
  expect((await store.listMembers(row.channel))[0].removedAt).toBe(durable[0].removedAt);
  expect(store.isActiveMember(row.channel, 'alice')).toBe(false);
});

it('a peer invalidation fences a delayed read without trusting a membership payload', async () => {
  const row: ChatMember = { channel: 'social:ch:private', userId: 'alice', role: 'member', addedBy: 'bob',
    addedAt: '2026-10-05T00:00:00.000Z', historyFrom: null, removedAt: null };
  let release!: () => void, entered!: () => void;
  const waiting = new Promise<void>(resolve => { release = resolve; }), started = new Promise<void>(resolve => { entered = resolve; });
  const persist: ChatMembershipStore = { listMembers: async () => { entered(); await waiting; return [row]; }, getMember: async () => row, putMember: async () => undefined };
  const store = new MirroredMembershipStore(() => [{ ...row, removedAt: '2026-10-05T01:00:00.000Z' }], persist);
  const proof = store.observeChanges(row.channel), pending = store.listMembers(row.channel);
  await started; store.invalidate(row.channel); release();
  await pending;
  expect(proof.changed()).toBe(true);
  expect(store.isActiveMember(row.channel, 'alice')).toBe(false);
  proof.dispose();
});
