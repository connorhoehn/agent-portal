// Bounded application state for call chat: join history floors and immutable
// delivery receipts. Messages themselves use the existing public ChatStore.
import type { ChatMessage } from '@connorhoehnslalom/realtime-modules/chat';
import { randomUUID } from 'node:crypto';
import { AppError } from './async-handler.js';
import type { CallPageRedis } from './call-pages.js';

export interface CallChatMember { historyFrom: string; sequenceFrom: number; active: boolean }
export interface CallChatState { incarnation: string; revision: number; sequence: number; ended: boolean; members: Record<string, CallChatMember> }
export interface CallChatDelivery { hash: string; message: ChatMessage; status: 'pending' | 'persisted' | 'cancelled' }
export interface CallChatStateStore {
  get(callId: string): Promise<CallChatState>;
  join(callId: string, userId: string, now: string, preserveHistory: boolean): Promise<CallChatState>;
  leave(callId: string, userId: string): Promise<CallChatState>;
  finish(callId: string): Promise<CallChatState>;
  reserve(callId: string, id: string, candidate: CallChatDelivery, incarnation: string): Promise<{ created: boolean; delivery: CallChatDelivery }>;
  complete(callId: string, id: string, hash: string, status: 'persisted' | 'cancelled', incarnation: string): Promise<void>;
  keepAlive(callId: string): Promise<void>;
  dispose?(): void;
}
const empty = (): CallChatState => ({ incarnation: '', revision: 0, sequence: 0, ended: false, members: {} });
const clone = <T>(value: T): T => structuredClone(value);
const MAX_MEMBERS = 512;
const TTL_SECONDS = 4 * 60 * 60;
const active = (state: CallChatState) => { if (state.ended) throw new AppError(404, 'Call conversation has ended'); };

export class MemoryCallChatStateStore implements CallChatStateStore {
  private readonly states = new Map<string, { state: CallChatState; until: number }>();
  private readonly deliveries = new Map<string, { callId: string; delivery: CallChatDelivery; until: number }>();
  private readonly sweep: ReturnType<typeof setInterval>;
  constructor(private readonly ttlSeconds = TTL_SECONDS, private readonly now = Date.now) {
    this.sweep = setInterval(() => this.prune(), 60_000); this.sweep.unref?.();
  }
  private prune() {
    for (const [key, row] of this.states) if (row.until <= this.now()) this.states.delete(key);
    for (const [key, row] of this.deliveries) if (row.until <= this.now()) this.deliveries.delete(key);
  }
  private read(callId: string) { this.prune(); return this.states.get(callId)?.state ?? empty(); }
  private save(callId: string, state: CallChatState) {
    this.states.set(callId, { state, until: this.now() + this.ttlSeconds * 1000 }); return clone(state);
  }
  async get(callId: string) {
    const row = this.states.get(callId);
    const value = this.read(callId);
    return row && this.states.has(callId) ? this.save(callId, value) : clone(value);
  }
  async join(callId: string, userId: string, now: string, preserveHistory: boolean) {
    const state = this.read(callId); active(state);
    // Membership TTL is shorter than durable message retention. A fresh floor
    // therefore creates a new private storage namespace, rather than adopting
    // archived messages or trusting an eventually consistent latest-row read.
    if (!state.incarnation) state.incarnation = randomUUID();
    const old = Object.hasOwn(state.members, userId) ? state.members[userId] : undefined;
    if (!old && Object.keys(state.members).length >= MAX_MEMBERS) throw new AppError(409, 'Call conversation membership limit reached');
    if (!old || !old.active || !preserveHistory) {
      state.members = { ...state.members, [userId]: { historyFrom: old && preserveHistory ? old.historyFrom : now,
        sequenceFrom: old && preserveHistory ? old.sequenceFrom : state.sequence, active: true } };
      state.revision += 1;
    }
    return this.save(callId, state);
  }
  async leave(callId: string, userId: string) {
    const state = this.read(callId); const member = Object.hasOwn(state.members, userId) ? state.members[userId] : undefined;
    if (member?.active) { member.active = false; state.revision += 1; }
    return this.save(callId, state);
  }
  async finish(callId: string) {
    const state = this.read(callId);
    if (!state.ended) { state.ended = true; state.revision += 1; state.members = {}; }
    return this.save(callId, state);
  }
  async reserve(callId: string, id: string, candidate: CallChatDelivery, incarnation: string) {
    const state = this.read(callId); active(state); const key = `${callId}\0${incarnation}\0${id}`;
    if (!this.states.has(callId)) throw new AppError(404, 'Call conversation has ended');
    if (!incarnation || state.incarnation !== incarnation) throw new AppError(409, 'Call conversation changed. Refresh before sending.');
    const existing = this.deliveries.get(key);
    if (existing) {
      existing.until = this.now() + this.ttlSeconds * 1000;
      return { created: false, delivery: clone(existing.delivery) };
    }
    const delivery = clone(candidate);
    const seq = ++state.sequence;
    delivery.message.metadata = { ...delivery.message.metadata, _callSequence: seq, _callIncarnation: incarnation };
    delivery.message.id = `huddle-${String(seq).padStart(20, '0')}-${incarnation}-${id}`;
    this.save(callId, state);
    this.deliveries.set(key, { callId, delivery, until: this.now() + this.ttlSeconds * 1000 });
    return { created: true, delivery: clone(delivery) };
  }
  async complete(callId: string, id: string, hash: string, status: 'persisted' | 'cancelled', incarnation: string) {
    const row = this.deliveries.get(`${callId}\0${incarnation}\0${id}`);
    if (!row || row.delivery.hash !== hash) throw new AppError(409, 'Message delivery changed');
    // A delayed success cannot revive a cancelled receipt.
    if (row.delivery.status === 'cancelled' && status === 'persisted') throw new AppError(409, 'Message delivery was cancelled');
    row.delivery.status = status; row.until = this.now() + this.ttlSeconds * 1000;
  }
  async keepAlive(callId: string) {
    const state = await this.get(callId); if (state.ended) return;
    for (const row of this.deliveries.values()) if (row.callId === callId) row.until = this.now() + this.ttlSeconds * 1000;
  }
  dispose() { clearInterval(this.sweep); }
}

const READ = `local s=redis.call('GET',KEYS[1]); if s then redis.call('EXPIRE',KEYS[1],ARGV[1]) end; return s`;
const UPDATE = `
local raw=redis.call('GET',KEYS[1])
local s={incarnation='',revision=0,sequence=0,ended=false,members={}}
if raw then s=cjson.decode(raw) end
local action=ARGV[1]; local uid=ARGV[2]
if action=='finish' then
  if not s.ended then s.ended=true; s.revision=s.revision+1; s.members={} end
elseif action=='join' then
  if s.ended then return {0,'ended'} end
  if not s.incarnation or s.incarnation=='' then s.incarnation=ARGV[7] end
  local old=s.members[uid]
  if not old then
    local count=0; for _ in pairs(s.members) do count=count+1 end
    if count>=tonumber(ARGV[6]) then return {0,'limit'} end
  end
  if not old or not old.active or ARGV[4]~='1' then
    local floor=ARGV[3]; if old and ARGV[4]=='1' then floor=old.historyFrom end
    local seq=s.sequence; if old and ARGV[4]=='1' then seq=old.sequenceFrom end
    s.members[uid]={historyFrom=floor,sequenceFrom=seq,active=true}; s.revision=s.revision+1
  end
elseif action=='leave' then
  local old=s.members[uid]; if old and old.active then old.active=false; s.revision=s.revision+1 end
end
local encoded=cjson.encode(s); redis.call('SET',KEYS[1],encoded,'EX',ARGV[5]); return {1,encoded}
`;
const RESERVE = `
local raw=redis.call('GET',KEYS[1]); if not raw then return {-1,''} end
local s=cjson.decode(raw); if s.ended then return {-1,''} end
if not s.incarnation or s.incarnation~=ARGV[4] then return {-2,''} end
local old=redis.call('GET',KEYS[2]); if old then redis.call('EXPIRE',KEYS[2],ARGV[2]); return {0,old} end
local d=cjson.decode(ARGV[1]); s.sequence=s.sequence+1; d.message.metadata._callSequence=s.sequence; d.message.metadata._callIncarnation=s.incarnation
d.message.id='huddle-'..string.format('%020d',s.sequence)..'-'..s.incarnation..'-'..ARGV[3]
local encoded=cjson.encode(d)
redis.call('SET',KEYS[1],cjson.encode(s),'EX',ARGV[2]); redis.call('SET',KEYS[2],encoded,'EX',ARGV[2])
redis.call('SADD',KEYS[3],KEYS[2]); redis.call('EXPIRE',KEYS[3],ARGV[2]); return {1,encoded}
`;
const KEEP_ALIVE = `
local raw=redis.call('GET',KEYS[1]); if not raw or cjson.decode(raw).ended then return 0 end
redis.call('EXPIRE',KEYS[1],ARGV[1]); redis.call('EXPIRE',KEYS[2],ARGV[1])
for _,key in ipairs(redis.call('SMEMBERS',KEYS[2])) do
  if redis.call('EXPIRE',key,ARGV[1])==0 then redis.call('SREM',KEYS[2],key) end
end
return 1
`;
const COMPLETE = `
local raw=redis.call('GET',KEYS[1]); if not raw then return 0 end
local d=cjson.decode(raw); if d.hash~=ARGV[1] or (d.status=='cancelled' and ARGV[2]=='persisted') then return 0 end
d.status=ARGV[2]; redis.call('SET',KEYS[1],cjson.encode(d),'EX',ARGV[3]); return 1
`;
export class RedisCallChatStateStore implements CallChatStateStore {
  constructor(private readonly redis: CallPageRedis, private readonly ttlSeconds = TTL_SECONDS) {}
  private key(callId: string) { return `orgiq:call-chat:${encodeURIComponent(callId)}`; }
  private receipt(callId: string, id: string, incarnation: string) { return `${this.key(callId)}:delivery:${incarnation}:${id}`; }
  private decode(raw: unknown): CallChatState {
    if (raw === null) return empty();
    const parsed = JSON.parse(String(raw)) as CallChatState;
    // Lua encodes an empty table as []; normalize that harmless representation.
    if (Array.isArray(parsed.members) && parsed.members.length === 0) parsed.members = {};
    return parsed;
  }
  async get(callId: string) { return this.decode(await this.redis.command('EVAL', READ, 1, this.key(callId), this.ttlSeconds)); }
  private async update(callId: string, action: string, userId = '', now = '', preserveHistory = false) {
    const [ok, raw] = await this.redis.command('EVAL', UPDATE, 1, this.key(callId), action, userId, now,
      preserveHistory ? '1' : '0', this.ttlSeconds, MAX_MEMBERS, randomUUID()) as [number, string];
    if (!Number(ok)) throw new AppError(raw === 'ended' ? 404 : 409, raw === 'ended' ? 'Call conversation has ended' : 'Call conversation membership limit reached');
    return this.decode(raw);
  }
  join(callId: string, userId: string, now: string, preserveHistory: boolean) { return this.update(callId, 'join', userId, now, preserveHistory); }
  leave(callId: string, userId: string) { return this.update(callId, 'leave', userId); }
  finish(callId: string) { return this.update(callId, 'finish'); }
  async reserve(callId: string, id: string, candidate: CallChatDelivery, incarnation: string) {
    const [created, raw] = await this.redis.command('EVAL', RESERVE, 3, this.key(callId), this.receipt(callId, id, incarnation), `${this.key(callId)}:deliveries`,
      JSON.stringify(candidate), this.ttlSeconds, id, incarnation) as [number, string];
    if (Number(created) === -2) throw new AppError(409, 'Call conversation changed. Refresh before sending.');
    if (Number(created) < 0) throw new AppError(404, 'Call conversation has ended');
    return { created: Number(created) === 1, delivery: JSON.parse(raw) as CallChatDelivery };
  }
  async complete(callId: string, id: string, hash: string, status: 'persisted' | 'cancelled', incarnation: string) {
    if (!Number(await this.redis.command('EVAL', COMPLETE, 1, this.receipt(callId, id, incarnation), hash, status, this.ttlSeconds))) {
      throw new AppError(409, 'Message delivery changed');
    }
  }
  async keepAlive(callId: string) { await this.redis.command('EVAL', KEEP_ALIVE, 2, this.key(callId), `${this.key(callId)}:deliveries`, this.ttlSeconds); }
}
