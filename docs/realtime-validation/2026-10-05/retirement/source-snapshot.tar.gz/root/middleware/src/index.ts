import { startAssessmentDispatcher } from './lib/assessment-dispatcher.js';
import express from 'express';
import { createServer } from 'node:http';
import { browserOrigin } from './lib/browser-origin.js';
import cookieParser from 'cookie-parser';
import { rejectUnsupportedUpgrades } from './lib/unsupported-upgrades.js';
import { attachDistillationRealtime, REALTIME_PATH } from './lib/distillation-realtime.js';
import { startRealtimeGateway, realtimeGatewayEnabled, realtimeGatewayStatus, REALTIME_GATEWAY_PATH } from './lib/realtime-gateway.js';
import { startCompactionConsumer, startCompactionScheduler, startReplicaSync } from './providers/distillation.js';
import { config } from './config.js';
import { errorHandler } from './lib/async-handler.js';
import { sessionMiddleware, setGrantsResolver } from './lib/session.js';
import { getUser as getIdentityUser } from './providers/identity.js';
import { agentsRouter } from './routes/agents.js';
import { savedSearchesRouter } from './routes/saved-searches.js';
import { graphRouter } from './routes/graph.js';
import { searchRouter } from './routes/search.js';
import { rosterRouter } from './routes/roster.js';
import { scoresRouter } from './routes/scores.js';
import { decisionsRouter } from './routes/decisions.js';
import { projectsRouter } from './routes/projects.js';
import { designsRouter } from './routes/designs.js';
import { libraryRouter } from './routes/library.js';
import { promotionsRouter } from './routes/promotions.js';
import { sessionBundleRouter } from './routes/session-bundle.js';
import { rediscoveryRouter } from './routes/rediscovery.js';
import { promptEvalsRouter } from './routes/prompt-evals.js';
import { distillationRouter } from './routes/distillation.js';
import { knowledgeBaseRouter } from './routes/knowledge-base.js';
import { assessmentRouter } from './routes/assessment.js';
import { socialEmbedRouter, socialRouter } from './routes/social.js';
import { dmPageReferencesRouter } from './routes/dm-page-references.js';
import { chatPinsRouter } from './routes/chat-pins.js';
import { callPagesRouter } from './routes/call-pages.js';
import { callChatRouter } from './routes/call-chat.js';
import { pipelinesRouter } from './routes/pipelines.js';
import { runsFacadeRouter } from './routes/runs.js';
import { ingestRouter } from './routes/ingest.js';
import { observabilityRouter } from './routes/observability.js';
import { approvalsRouter } from './routes/approvals.js';
import { harnessRouter } from './routes/harness.js';
import { labRouter } from './routes/lab.js';
import { promptVersionsRouter } from './routes/prompt-versions.js';
import { costRouter } from './routes/cost.js';
import { calibrationRouter } from './routes/calibration.js';
import { oncallRouter } from './routes/oncall.js';
import { memoryRouter } from './routes/memory.js';
import { guardrailsDetailRouter } from './routes/guardrails-detail.js';
import { trafficRouter } from './routes/traffic.js';
import { invocationsRouter } from './routes/invocations.js';
import { topologyRouter } from './routes/topology.js';
import { toolCallsRouter } from './routes/tool-calls.js';
import { testFixturesRouter } from './routes/test-fixtures.js';
import { capabilitiesRouter } from './routes/capabilities.js';
import { sessionsRouter } from './routes/sessions.js';
import { sessionRouter } from './routes/session.js';
import { authRouter } from './routes/auth.js';
import { identityRouter } from './routes/identity.js';
import { canaryRouter } from './routes/canary.js';
import { canaryLibraryRouter } from './routes/canary-library.js';
import { evaluationsRouter } from './routes/evaluations.js';
import { workRouter } from './routes/work.js';
import { startJobDispatcher } from './lib/job-dispatcher.js';
import { startMockBotRunner } from './lib/mock-bot-runner.js';
import { runAllSweeps } from './providers/org-sweeps.js';
import { checkAwsCredentials } from './lib/aws-creds-probe.js';
import { checkDatastore } from './lib/datastore-probe.js';
import { promptHistoryRouter } from './routes/prompt-history.js';
import { workItemsRouter } from './routes/work-items.js';
import { workDocumentsRouter } from './routes/work-documents.js';
import { kbAdminRouter } from './routes/kb-admin.js';
import { gatewayProxyRouter } from './routes/gateway-proxy.js';
import { devboxRouter } from './routes/devbox.js';
import { localComputeRouter } from './routes/local-compute.js';
import { dropRouter } from './routes/drop.js';
import { agentDetailRouter } from './routes/agent-detail.js';
import { connectionsRouter } from './routes/connections.js';
import { agentProjectsRouter } from './routes/agent-projects.js';
import { sdlcRouter } from './routes/sdlc.js';
import { environmentsRouter } from './routes/environments.js';
import { budgetsRouter } from './routes/budgets.js';
import { sprintsRouter } from './routes/sprints.js';
import { grantsRouter } from './routes/grants.js';
import { botsRouter } from './routes/bots.js';
import { mockControlRouter } from './routes/mock-control.js';
import { requireAction, requireTenant, readForRolesElseAction, requireSession } from './lib/authz.js';
import { HARNESS_RUNNER_SERVICE_AUTH, serviceAuthOr } from './lib/service-auth.js';
import { initScheduler } from './lib/ingest-scheduler.js';
import { initBotScheduler } from './lib/bot-scheduler.js';
import { initFleetPersistence } from './providers/devbox-fleet-store.js';
import { initComputeRegistry } from './work-graph/compute-registry-runtime.js';
import { initCrawlTargets } from './lib/crawl-targets.js';
import { ensureSchema, seedPoliciesIfMissing } from './lib/policy-seeds.js';
import { startTracePoller } from './lib/cw-trace-ingest.js';
import { startCanaryDecisionsPoller } from './lib/canary-decisions-poller.js';
import { startPrWatchPoller } from './lib/pr-watch-poller.js';
import { startRetentionSweep } from './lib/retention-sweep.js';
import { startLocalController } from './lib/canary-local-controller.js';
import { startComputeWorkGraphProducer } from './work-graph/compute-emitter.js';
import { internalWorkGraphComputeRouter } from './routes/internal-work-graph-compute.js';
import { internalDocumentGrantsRouter } from './routes/internal-document-grants.js';
import { internalDevboxRouter } from './routes/internal-devbox.js';
import { assessmentCanvasRouter } from './routes/assessment-canvas.js';
import { assessmentDocumentWorkflowsRouter } from './routes/assessment-document-workflows.js';
import { assessmentDocumentSourceRouter } from './routes/assessment-document-source.js';
import { assessmentDocumentProposalsRouter } from './routes/assessment-document-proposals.js';

import { trustedProxyHops } from './lib/trusted-proxy.js';

const app = express();

// ECS declares its enforced ALB hop; direct/local servers ignore forwarding
// headers by default so callers cannot choose their own rate-limit bucket.
app.set('trust proxy', trustedProxyHops());

app.use(browserOrigin);
app.use(express.json());
app.use(cookieParser());
// HMAC-only source-owned attachments for platform/gateway collaboration
// sessions. Mount before browser/session routes so it never inherits a user
// session as an alternate authorization path.
app.use('/internal/work-graph/compute-capabilities', internalWorkGraphComputeRouter);
app.use('/internal/document-grants', internalDocumentGrantsRouter);
// Computer-lab surface for platform-api's chat agent loop — see
// routes/internal-devbox.ts for why this must live here, before any
// session/cookie middleware, exactly like its siblings above.
app.use('/internal/devbox', internalDevboxRouter);
setGrantsResolver(async (id) => {
  const u = await getIdentityUser(id);
  return u ? { displayName: u.displayName, grants: u.grants, epoch: u.epoch } : null;
});
app.use(sessionMiddleware());

// Observability read floor: orgiq tenant + ViewObservability. Declared here
// (not beside its first API mount) so the harness/prompt-versions mounts above
// the /api/observability block can share it.
const viewObs = [requireTenant('orgiq'), requireAction('ViewObservability')];

function healthHandler(_req: express.Request, res: express.Response): void {
  const realtime = realtimeGatewayStatus();
  if (realtime.ready === false) {
    // The ALB checks this path. A fenced peer router cannot accept traffic,
    // even when the database and its Redis command connection still work.
    res.status(503).json({ status: 'degraded', service: 'orgiq-middleware', mocks: config.mock, region: config.region, realtime });
    return;
  }
  // Fire-and-report: don't block health on STS when mocks are on.
  const wantsAws = !Object.values(config.mock).every(Boolean);
  void Promise.all([
    wantsAws ? checkAwsCredentials() : Promise.resolve({ ok: true } as const),
    // Valid credentials say nothing about the database existing. Without this
    // the status line reported "ok" against a torn-down cluster while every
    // Aurora-backed route 500'd.
    checkDatastore(),
  ]).then(([creds, datastore]) => {
    const currentRealtime = realtimeGatewayStatus();
    res.status(currentRealtime.ready === false ? 503 : 200).json({
      status: creds.ok && datastore.ok && currentRealtime.ready !== false ? 'ok' : 'degraded',
      service: 'orgiq-middleware',
      mocks: config.mock,
      region: config.region,
      awsCredentials: creds,
      datastore,
      // lib/realtime-gateway.ts: whether /ws is served, and where call state lives.
      realtime: currentRealtime,
    });
  });
}
app.get('/health', healthHandler);
app.get('/api/health', healthHandler);

// Dev-only mock control plane (/api/__mock/*). Mounted at the root so it can
// stamp X-Mock-Scenario on every response; 404s every route, and stamps
// nothing, unless the mock providers are on and NODE_ENV !== 'production'.
app.use(mockControlRouter);

app.use('/api/session', sessionRouter);
app.use('/api/assessment/knowledge', assessmentCanvasRouter);
app.use('/api/assessment/knowledge', assessmentDocumentWorkflowsRouter);
app.use('/api/assessment/knowledge', assessmentDocumentSourceRouter);
app.use('/api/assessment/knowledge', assessmentDocumentProposalsRouter);
// Enterprise SSO (Cognito OIDC). Inert unless COGNITO_* are configured.
app.use('/api/auth', authRouter);
app.use('/api/identity', identityRouter);
// Per-agent detail, mounted first so /:agentId there is not swallowed by
// the fleet router's own routes.
app.use('/api/agent-detail', requireTenant('orgiq'), requireSession('ViewAgents'), agentDetailRouter);
app.use('/api/agents', requireSession('ViewAgents'), agentsRouter);
// Decisions + Projects mounted BEFORE graphRouter so their specific paths
// resolve without going through the gated graph router.
// Org-graph surfaces are orgiq-tenant data: sessions parked in another tenant
// are rejected here (the cross-tenant admin role passes any tenant guard).
app.use('/api/search', searchRouter);
app.use('/api/graph/decisions', requireTenant('orgiq'), decisionsRouter);
app.use('/api/graph/projects', requireTenant('orgiq'), projectsRouter);
// Design reviews — the ADR threads that gate initiative designs. Session
// floor: readable by every signed-in orgiq role, writes gated per-route.
app.use('/api/designs', requireTenant('orgiq'), requireSession('ViewDesigns'), designsRouter);
// The asset library — prompts, evaluators, skills and insights in one
// catalog. Read-open to the tenant; authoring/deploy stay gated elsewhere.
app.use('/api/library', requireTenant('orgiq'), requireSession('ViewLibrary'), libraryRouter);
// The promotion ladder's inbox: session observations clustered into patterns,
// and the candidates a human turns into insights, runbooks and skills.
app.use('/api/promotions', requireTenant('orgiq'), requireSession('ViewPromotions'), promotionsRouter);
// What every Claude Code devbox session is configured with — hooks, bundled
// skills, settings. A release target in its own right: the SessionStart hook
// runs on every session, so publishing one is the widest-blast-radius action
// in the product.
app.use('/api/session-bundle', requireTenant('orgiq'), requireSession('ViewSessionConfig'), sessionBundleRouter);
// Look before you spend: prior experience matched on the PROBLEM's shape
// rather than on the repo it was learned in, so knowledge from another project
// is reachable. Open to any signed-in session — gating this would defeat it at
// exactly the moment it matters.
app.use('/api/rediscovery', requireTenant('orgiq'), requireSession('ViewRediscovery'), rediscoveryRouter);
// Per-asset eval sets — the thing that produces the pass rate decideDeploy
// gates on. Until this existed the gate judged a number nothing computed.
app.use('/api/library/evals', requireTenant('orgiq'), requireSession('ViewLibrary'), promptEvalsRouter);
// The distillation pipeline's operational log + corpus health. Read-open: how
// the org's shared memory is doing is everyone's business.
app.use('/api/distillation', requireTenant('orgiq'), requireSession('ViewDistillation'), distillationRouter);
// Work-items: mounted at /api/graph so its sub-paths (/work, /projects/:id/work,
// /people/:id/work, /work-items) resolve before the gated graphRouter. Reads
// are tenant-open; the router gates its POST/PATCH per-route on
// DispatchAgentRun so board writes need the marketplace authority, not
// merely a seat in the tenant.
app.use('/api/saved-searches', savedSearchesRouter);
app.use('/api/graph', requireTenant('orgiq'), workDocumentsRouter);
app.use('/api/graph', requireTenant('orgiq'), workItemsRouter);
// The org roster + relationship graph is the org-chart surface: tenant-scoped
// AND gated on ViewOrgChart (every orgiq role holds it; a grantless anonymous
// production session does not — closing the roster leak).
app.use('/api/graph', requireTenant('orgiq'), requireAction('ViewOrgChart'), graphRouter);
// The eligible-people pick-list for the sprint steward + grant grantee selectors
// (audit RM-5). Not org-chart-privileged: any signed-in orgiq member may read it
// (requireSession floor), since that is exactly the set the sprint/grant APIs
// will accept — the org roster surfaces above need ViewOrgChart, this does not.
app.use('/api/roster', requireTenant('orgiq'), requireSession('Roster'), rosterRouter);
// Ranked people-intelligence (leaderboard, cohorts, radar, contributions) is
// leadership data: ViewLeaderboard, held only by org-leader / hr-admin / admin.
// Tenant guard alone previously let any orgiq member — and any anonymous
// caller — read it.
app.use('/api/scores', requireTenant('orgiq'), requireAction('ViewLeaderboard'), scoresRouter);
// The knowledge base belongs to the orgiq tenant; scope it to that tenant.
app.use('/api/knowledge-base', requireTenant('orgiq'), knowledgeBaseRouter);
// KB Registry admin — CRUD + async provisioning for multi-KB support.
// Tenant-scoped to orgiq first (its DELETE/provision routes are destructive,
// and admin bypasses the tenant guard). Then: reading the registry
// is operational visibility (org-leader + hr-admin, like Health), while
// create/adopt/provision/sync/delete still require ManageKB (hr-admin). Mounted
// before the gated observability router so the portal wizard can reach it.
app.use('/api/admin/kb-registry', requireTenant('orgiq'), readForRolesElseAction(['org-leader', 'hr-admin'], 'ManageKB'), kbAdminRouter);
// Public document drop — deliberately ungated. The token in the URL is the
// whole authority, which is why the router exposes no bucket, prefix or id
// and every limit is enforced server-side per link.
app.use('/api/drop', dropRouter);
// Assessment — tenant-guarded, but NOT at the mount: assessmentRouter applies
// requireTenant('assessment') itself so it can exempt the agent-facing
// POST /runs/:runId/complete callback (sessionless, self-gated by a service
// secret) the same way harnessRouter exempts /trace. Mounting requireTenant
// here would 401 that callback before the router ever saw the request.
app.use('/api/assessment', assessmentRouter);
// The third and fourth tenants (docs/social-tenant-design.md §4, §5). Neither
// has a machine callback, so the tenant gate sits at the mount: a session
// parked in any other tenant is refused before a handler runs.
// The cross-tenant half first (design E5, §4.6): context bindings and opening
// a DM are gated on the caller's GRANTS (social + the context's tenant), so an
// orgiq page can show its bound channel. Every other /api/social path falls
// through to the tenant-gated router below.
app.use('/api/social', socialEmbedRouter);
app.use('/api/social', dmPageReferencesRouter);
app.use('/api/chat', chatPinsRouter);
app.use('/api/calls', callPagesRouter);
app.use('/api/calls', callChatRouter);
app.use('/api/social', requireTenant('social'), socialRouter);
app.use('/api/pipelines', requireTenant('pipelines'), pipelinesRouter);
// The orgiq read of the pipelines run projection — only runs whose
// context.tenant is 'orgiq' (docs/pipelines-tenant-goal.md §"The vertical
// slice"). The bot detail page reads its runs here, never /api/pipelines/*.
app.use('/api/runs', requireTenant('orgiq'), runsFacadeRouter);
// Ingest — reading jobs/storage/crawl status is operational visibility that the
// Knowledge page surfaces to org-leaders; starting crawls, editing schedules and
// other mutations still require ManageIngest (hr-admin).
app.use('/api/ingest', requireTenant('orgiq'), readForRolesElseAction(['org-leader', 'hr-admin'], 'ManageIngest'), ingestRouter);
// Connected sources — credentials for Confluence/Jira/GitHub. Gated as an
// ingestion decision, because that is what connecting a source is.
app.use('/api/connections', requireAction('ManageIngest'), connectionsRouter);
// Repositories that agents work on. Distinct from /api/graph/projects, which
// is the org graph's own notion of a project.
// Codebases — linking a repo and dispatching a governed agent run against it is
// the same authority as the SDLC/devbox surfaces, so mutations still carry that
// gate. Reads are gated per-route inside the router: org-leader/hr-admin can
// see the codebase list feeding the Authorize drawer (same tier as bots.ts'
// marketReadGate) without holding ManageDevbox. The mount is just the floor —
// tenant scope + a real session.
app.use('/api/agent-projects', requireTenant('orgiq'), requireSession('ViewAgentProjects'), agentProjectsRouter);
// AI SDLC governance — change requests, reviews, gates, policies. Gated as a
// devbox-management action.
app.use('/api/sdlc', requireAction('ManageDevbox'), sdlcRouter);
// Environments — where each initiative's code runs. Mount is the floor only
// (tenant scope + a real session): reading the estate is open to every orgiq
// role, editing it needs ManageEnvironments, and reaching a specific
// environment is a per-environment Cedar check inside the router. See
// routes/environments.ts.
app.use('/api/environments', requireTenant('orgiq'), requireSession('ViewEnvironments'), environmentsRouter);
// Budgets — initiative spend allocations. Gated per-route (reads open to
// org-leader, writes require ManageBudgets).
app.use('/api/budgets', requireTenant('orgiq'), budgetsRouter);
// Sprints — the SME's own cadence (their work, their envelope, their dates).
// Any signed-in orgiq session may read `scope=mine`; the org-wide `scope=all`
// carries the same money the ledger gates and is checked inside the router.
app.use('/api/sprints', requireTenant('orgiq'), requireSession('ViewSprints'), sprintsRouter);
// Grants — the write side of sprint envelopes (budget_grants). orgiq-tenant;
// reads open to org-leader/hr-admin, writes require ManageBudgets (the release
// manager's action), gated per-route inside the router. See routes/grants.ts.
app.use('/api/grants', requireTenant('orgiq'), grantsRouter);
// Bots — durable mission-configured agents. Gated per-route inside the
// router: reads are operational visibility (org-leader + hr-admin, like the
// KB registry), bot mutations carry ManageDevbox (they dispatch the same
// governed runs the SDLC surface reviews), and the marketplace's
// dispatch-work carries the seeded DispatchAgentRun action so org-leaders
// can authorize work without holding the devbox keys.
app.use('/api/bots', requireTenant('orgiq'), botsRouter);
// Approvals are mounted BEFORE the gated observability router so that the
// agent-facing POST /approvals/request endpoint doesn't require ViewObservability
// (the agent's identity is captured as `agentId` in the request body instead).
// Decision posting is Cedar-gated inside the router itself.
app.use('/api/observability/approvals', approvalsRouter);
// Harness routes — mounted ungated so the test runner (infra/scripts/harness.py)
// can POST results without a session cookie. Same rationale as approvals.
app.use('/api/observability/harness', harnessRouter);
// The lab loop: computer-lab agents filing signals, recording experiences and
// opening human consults. Agent-facing routes are sessionless (per-route
// optional service auth INSIDE the router — no blanket session mount here,
// same rule as approvals/harness above).
app.use('/api/lab', labRouter);
// Prompt-versions registry — populated at run start by the harness runner.
// NOT ungated (the old comment here said so and was wrong): tenant + Cedar,
// with the harness runner's machine identity as the alternative to a session.
// `serviceAuthOr` never opens on an unset secret, so with HARNESS_RUNNER_SECRET
// unconfigured this is byte-for-byte the `viewObs` mount it was.
app.use(
  '/api/observability/prompt-versions',
  serviceAuthOr(HARNESS_RUNNER_SERVICE_AUTH, ...viewObs),
  promptVersionsRouter,
);
// Every observability aggregate below carries the ViewObservability gate AND a
// tenant scope. ViewObservability is an ALL-HANDS read within orgiq (member and
// sme hold it too, deliberately — a member labels answer quality), so the gate
// is really the tenant scope: an assessment-tenant session holding
// ViewObservability must not read orgiq agent telemetry. Admin bypasses the
// tenant guard. Note the telemetry is not partitioned by tenant, which is why
// the tenant scope matters. Mutations that would otherwise ride this read tier
// (invocation replay, calibration CRUD/runs, memory writes) are gated higher
// on ManageCanary. (In dev the cookie-less demo session is orgiq and holds
// every grant, so these render without login; in production an out-of-tenant
// or anonymous session is denied.)
// Cost aggregation routes — read-only aggregates over invocation_traces cost
// columns.
app.use('/api/observability/cost', viewObs, costRouter);
// Sprint 4 (M10) — judge calibration. Curated (prompt, response, human_score)
// tuples + periodic judge re-runs to measure judge drift.
app.use('/api/observability/calibration', viewObs, calibrationRouter);
// Sprint 3 (M9) — on-call / incident response. Composes drift + cost +
// errors + HITL + deploys into one timeline. (The old "works past session
// expiry at 3am" rationale is covered by demo mode in dev; prod operators
// hold a session.)
app.use('/api/observability/oncall', viewObs, oncallRouter);
// Sprint 4 (M11) — AgentCore Memory ops observability.
app.use('/api/observability/memory', viewObs, memoryRouter);
// Sprint 4 (M12) — guardrail rule-level interventions.
app.use('/api/observability/guardrails-detail', viewObs, guardrailsDetailRouter);
// Sprint 4 (M13) — traffic shape: RPS, hour-of-week heatmap, top users.
app.use('/api/observability/traffic', viewObs, trafficRouter);
// Test fixtures — E2E-only reset utilities. NODE_ENV=production locks them
// internally, so they stay ungated for the sessionless E2E runner.
app.use('/api/observability/test-fixtures', requireSession('TestFixtures'), testFixturesRouter);
// Sprint 2 — invocation search + per-invocation drill-down (M3/M5 triage).
app.use('/api/observability/invocations', viewObs, invocationsRouter);
// A2A topology — derived from parent_invocation_id linkage in invocation_traces.
// An observability read like invocations.
app.use('/api/topology', viewObs, topologyRouter);
// Sprint 2 — per-tool latency aggregates + error tail (M4).
app.use('/api/observability/tools', viewObs, toolCallsRouter);
// Canary — A/B prompt experiment surface. Reads need ViewObservability;
// mutation endpoints (PUT /weight, POST /halt) are additionally Cedar-gated
// via `ManageCanary` inside the router.
app.use('/api/observability/canary', viewObs, canaryRouter);
app.use('/api/observability/canary', viewObs, canaryLibraryRouter);
// Prompt history + experiment log — version timeline + outcome cards for /iq/history.
app.use('/api/iq/prompts', viewObs, promptHistoryRouter);
// Evaluations — LLM-as-judge config + recent scores. The config is SSM-backed
// and read by fireJudge() on every canary invocation, so the /iq/evaluations
// page actually governs judging (enable, model, rubric weights, sampling).
app.use('/api/observability/evaluations', viewObs, evaluationsRouter);
app.use('/api/observability', viewObs, observabilityRouter);
app.use('/api/capabilities', requireTenant('orgiq'), requireSession('ViewCapabilities'), capabilitiesRouter);
app.use('/api/sessions', requireTenant('orgiq'), requireSession('ViewSessions'), sessionsRouter);
// Devbox — Claude Code in an AgentCore Runtime microVM. Operator surface for
// a future portal page (no UI ships yet). Cedar-gated: the ManageDevbox
// action must be allowed for the caller's role (open mode when no policy
// store is configured, matching every other requireAction guard).
// Reads for every role that directs agent work; writes still need
// ManageDevbox (readForRolesElseAction fast-paths GET only, so POST /task,
// /command and DELETE stay gated). This closes a contradiction: devbox-visibility.ts
// already lists org-leader in FLEET_WIDE_ROLES — it had decided what a leader
// should SEE on the fleet — while this mount refused them the router outright,
// making that visibility branch dead code and the nav item a door onto a wall.
// A program-owner is deliberately NOT fleet-wide: they fall through to the
// scoped path and see the computers on initiatives they run.
app.use(
  '/api/devbox',
  readForRolesElseAction(['org-leader', 'hr-admin', 'program-owner'], 'ManageDevbox'),
  devboxRouter,
);
// Local compute — developers' own machines announcing presence (and later,
// claiming work). Mounted UNGATED: the machine routes authenticate with a
// node token (no session — a blanket session mount would 401 every laptop's
// presence writes, the same trap as approvals/harness), and the browser
// routes carry their own requireSession/ConnectLocalCompute gates per-route.
app.use('/api/local-compute', localComputeRouter);
// Work — the agentic loop: queue → devbox workers → review, scheduled sweeps
// that produce findings, and agent-proposed graph writes gated on approval.
// Reads are open so the overview renders for any role; mutations are gated
// per-route with ManageDevbox.
app.use('/api/work', requireTenant('orgiq'), requireSession('ViewWork'), workRouter);
// Retired generic gateway bridge: the BFF has no channel membership contract.
app.use('/api/gateway', requireTenant('orgiq'), requireSession('ViewGateway'), gatewayProxyRouter);

app.use(errorHandler);

initScheduler();
initCrawlTargets();

// Restore the devbox fleet before anything sweeps it.
//
// The registry is in-memory, so without this a restart dropped every box while
// the AgentCore sessions kept running — and `devbox-reaper` only reaps what
// `listBoxes()` returns, which left forgotten sessions outside both the idle
// timeout and the lifetime ceiling with nothing able to find them again (no
// AgentCore API enumerates live runtime sessions). Hydrating here also puts
// the boxes back on the Computers page instead of showing an empty fleet while
// the microVMs are still up.
//
// Fire-and-forget, and deliberately not awaited: `routes/devbox.ts` starts the
// reaper at import time, but its first sweep is a full interval away, so the
// load lands first in practice — and an Aurora that is slow, mocked, or
// missing the table must not delay the listen() below or fail the boot.
// The compute registry adopts shared registrations and publishes this
// replica's fleet, so it runs after the fleet's own hydration settles.
void initFleetPersistence().catch(() => 0).then(() => initComputeRegistry());
// Cloud boxes/jobs and paired local-machine sessions now emit only through the
// authenticated platform ingestion boundary. The producer stays inert unless
// its server-owned org/credential configuration is complete.
startComputeWorkGraphProducer();
// Cron bots + the bot-run reconciler. Aurora-backed, so it awaits nothing at
// boot — a missing bots table logs and stands down.
void initBotScheduler();

// Start the CW Logs Insights trace poller. Decouples agent telemetry from
// HTTP reachability — deployed AgentCore runtimes can't necessarily reach
// `http://middleware:3001`, but their stdout is always captured into
// /aws/bedrock-agentcore/runtimes/<runtime>-DEFAULT. The poller scans those
// log groups every 30s and feeds matching ORGIQ_TRACE:<json> lines through
// the same processTrace() pipeline the HTTP endpoint uses. Idempotent at
// the DB layer (ON CONFLICT DO NOTHING on invocation_id). Set
// OBS_TRACE_POLLER_DISABLED=1 to skip in offline/test environments.
startTracePoller();

// Tails observability.canary_decisions and bridges new rows into canaryBroker
// so the portal's Decision History panel updates when the SFN controller
// writes audit rows. No-ops in mock mode or without Aurora.
startCanaryDecisionsPoller();
// PR-watch bot triggers + marketplace merge detection (lib/pr-watch-poller.ts).
startPrWatchPoller();
// Retention sweep — deletes terminal agentic rows past RETENTION_DAYS so the
// jobs/runs/findings tables don't grow without bound (lib/retention-sweep.ts).
startRetentionSweep();
// Local mock controller fills the Controller node in dev when SFN isn't deployed.
startLocalController();

// Agentic loop background workers.
// The dispatcher hands queued jobs to idle devbox boxes; the sweep scheduler
// makes the system notice things on its own instead of only when asked.
// SWEEP_INTERVAL_MIN=0 disables scheduled sweeps (they remain runnable
// on demand from the Work surface).
startJobDispatcher();
startAssessmentDispatcher();
// Offline only: gives the Computer Lab's tail pane and activity list something
// real to show without a deployed runtime. No-op unless MOCK_AGENTCORE.
startMockBotRunner();
const sweepIntervalMin = Number(process.env['SWEEP_INTERVAL_MIN'] ?? 360);
if (sweepIntervalMin > 0) {
  console.log(`[sweeps] scheduling org sweeps every ${sweepIntervalMin} min`);
  const runSweeps = () => {
    void runAllSweeps()
      .then(({ results, released }) => {
        const summary = results.map((r) => `${r.sweep}: ${r.found} found, ${r.created} new, ${r.resolved} resolved`).join(' | ');
        if (summary) console.log(`[sweeps] ${summary}`);
        if (released > 0) console.log(`[sweeps] released ${released} finding(s) whose worker never delivered`);
      })
      .catch((err: unknown) => console.warn('[sweeps] run failed:', (err as Error).message));
  };
  setInterval(runSweeps, sweepIntervalMin * 60_000);
  // Run once shortly after boot so a fresh environment has findings without
  // waiting out the first interval.
  setTimeout(runSweeps, 15_000);
}

// Seed AVP if it's empty. Idempotent — safe on every boot.
// ensureSchema must complete before seeding policies (schema gates validation).
ensureSchema()
  .then(() => seedPoliciesIfMissing())
  .catch(err => console.error('[seed] failed:', err));

const server = createServer(app);

// This BFF serves SSE plus two realtime-modules WebSocket paths:
// REALTIME_PATH pushes the distillation channels (orgiq:distill:levels / orgiq:distill:jobs
// / orgiq:distill:review) to a signed-in orgiq session (cookie auth), and — when
// REALTIME_GATEWAY is on (default outside production) — REALTIME_GATEWAY_PATH
// (/ws) is the chat/presence/calls gateway, authenticated by the realtime
// token over `Sec-WebSocket-Protocol` (lib/realtime-gateway.ts). Every other
// upgrade is still refused before a socket is accepted.
const distillationHandle = attachDistillationRealtime(server);
const gatewayOn = realtimeGatewayEnabled();
const gatewayHandle = gatewayOn ? await startRealtimeGateway(server) : null;
if (!gatewayHandle) console.log('[realtime-gateway] off (REALTIME_GATEWAY) — /ws upgrades are refused');
rejectUnsupportedUpgrades(server, { allowPaths: gatewayOn ? [REALTIME_PATH, REALTIME_GATEWAY_PATH] : [REALTIME_PATH] });
server.listen(config.port, '0.0.0.0', () => {
  const mockedDomains = Object.entries(config.mock).filter(([, v]) => v).map(([k]) => k);
  const mockSuffix = mockedDomains.length > 0 ? `mock=${mockedDomains.join(',')}` : 'mocks=off';
  console.log(`orgiq-middleware listening on :${config.port} (${mockSuffix})`);
});
let closing = false;
const shutdown = async () => {
  if (closing) return; closing = true;
  const deadline = setTimeout(() => process.exit(1), 10000); deadline.unref();
  try {
    await gatewayHandle?.dispose(); await distillationHandle.detach();
    await new Promise<void>(resolve => server.close(() => resolve()));
    process.exit(0);
  } catch (error) { console.error('[shutdown] gateway cleanup failed', error); process.exit(1); }
};
process.once('SIGTERM', () => { void shutdown(); });
process.once('SIGINT', () => { void shutdown(); });

// Distillation's background work: the compaction consumer (claims passes off
// distill-compact-l1|l2 — message-queue, or in process under MOCK_QUEUE), the
// optional cadence scheduler (DISTILL_COMPACT_INTERVAL_MIN), and the L2
// replica's anti-entropy sweep.
startCompactionConsumer();
startCompactionScheduler();
startReplicaSync();
