// realtime-modules/src/call/types.ts
//
// Wire shapes + construction-time tunables for the lifted CallService.
//
// SCOPE — this module is hangout/call **invite signaling** only. It is
// not WebRTC, not SDP exchange, not ICE/TURN, not SFU media-plane
// signaling. The frontend's useVideoCall talks to platform-api for the
// actual media negotiation; this service simply fans out 5 lifecycle
// events (invite/accepted/declined/cancelled/ended) between users over
// the existing WS connection.
//
// Lift scope (Wave 2 catch-up):
//   - WS handleAction for the 5-action protocol.
//   - Targeted user routing via MessageRouterContract.getClientsByUserId,
//     plus broadcast fallback when no targets are supplied.
//
// Left behind in gateway:
//   - enforceChannelPermission authz interceptor — replaced by the
//     `authorize` hook below (defaults to allow-all).
//   - ErrorCodes / createErrorResponse — inlined to a minimal shape
//     matching the gateway-original error frame.
//   - The prom shadow counter wiring (src/observability/metrics).
//     Consumers expose a `recordCallAction` callback via CallConfig.

/** Verbs allowed on the call WS surface. */
export type CallAction =
    | 'invite'
    | 'accepted'
    | 'declined'
    | 'cancelled'
    | 'ended'
    /** In-call broadcast: peer publishes displayName + screen-sharing flag.
     *  Receivers merge into their remoteParticipantState map so the grid
     *  tile renders real names instead of opaque participantIds. */
    | 'participant-state'
    /** In-call broadcast: presence-style status (in-call, on-hold).
     *  Receivers can dim sidebars, suppress invites, etc. */
    | 'user-status'
    /** F3 (2026-08-21) — client → server query: "is there an active call
     *  in this lobby?" Server replies to the SENDER ONLY with an
     *  `active-call` envelope (never broadcast). Lets a freshly connected
     *  client discover an in-progress group call it was never invited to
     *  (or reconnect-discover one it left) without any HTTP roundtrip. */
    | 'status'
    /** F3 — server → client reply to `status`. data: { lobbyName,
     *  active, callId?, callerId?, callerName?, startedAt?,
     *  participantCount?, participantUserIds? }. */
    | 'active-call'
    /** UX audit 2026-08-24 — client → server: "stop offering ME this
     *  call". Durable dismissal of a resume/discovery surface: removes
     *  the sender's userId → callId index entry (and the invite-replay
     *  registry entry) so a dismissed stale call can never resurrect a
     *  ResumeCallDialog in a fresh session. Scoped to the SENDER's
     *  indexes only — other participants' state is untouched, and the
     *  call itself is only fully reaped when it has no live
     *  participants left. data: { callId }. */
    | 'forget'
    /** Server → client ack for `forget`. data: { callId, forgotten: true }. */
    | 'forgotten'
    /** Document calls (2026-09-24) — client → server: "send me this call's
     *  meta". data: { callId }. Replies `call-meta` to the asker only. */
    | 'meta'
    /** Document calls — client → server, any participant: replace the
     *  review-document list. data: { callId, documentIds, documentTitles? }.
     *  Broadcasts `call-meta` to the call. */
    | 'set-documents'
    /** Document calls — client → server: start (documentId) or stop (null)
     *  presenting. Only the current presenter or the host may replace a
     *  presenter. Broadcasts `call-meta`. */
    | 'present'
    /** Document calls — client → server, host only: rename the call.
     *  data: { callId, title }. Broadcasts `call-meta`. */
    | 'set-title'
    /** Document calls — server → client: the full DocumentCallMeta, sent
     *  after `meta` and after every change. Server-only. */
    | 'call-meta'
    /** Document calls — server → client, to the inviter's clients: one
     *  target's ring timed out. data: { callId, userId }. Server-only. */
    | 'invite-expired'
    /** Document calls, host moderation (2026-09-24) — client → server, host
     *  only: ask one participant to mute. data: { callId, userId }. The
     *  target's clients receive the same action with { callId, userId, by }
     *  and mute themselves; their participant-state tells everyone else. */
    | 'mute-participant'
    /** Host only: remove one person from the call. data: { callId, userId }.
     *  Their clients receive the same action and leave; everyone else gets
     *  `user-status: left` (reason 'removed') and `call-meta`. They can come
     *  back only through a new invite. */
    | 'remove-participant'
    /** Host only: hand the host role to another participant.
     *  data: { callId, userId }. Everyone gets `call-meta` with the new
     *  hostUserId. */
    | 'transfer-host';

/** Vocabulary of the `status` field on `user-status`. `reconnecting` is
 *  sent for document calls while a dropped participant is inside the
 *  rejoin grace; `left` follows if they do not come back. */
export type CallUserStatus = 'in-call' | 'left' | 'on-hold' | 'reconnecting';

// ---------------------------------------------------------------------------
// Document calls (2026-09-24) — see realtime-examples
// docs/design/document-calls/SPEC.md §4–5.
// ---------------------------------------------------------------------------

/** Ring state of one invited person. `notified` = they had no connected
 *  client, so they got a notification (and the invite link) instead. */
/** `removed` = the host removed them; only a new invite lets them back in. */
export type DocumentCallInviteState = 'ringing' | 'accepted' | 'declined' | 'missed' | 'notified' | 'removed';

/** One invited person, keyed by userId in DocumentCallMeta.invites. */
export interface DocumentCallInvite {
    /** Epoch ms of the (latest) ring. Per-target expiry runs off this. */
    at: number;
    state: DocumentCallInviteState;
    /** userId of whoever sent the invite; `invite-expired` goes to them. */
    by?: string;
}

/** Who is presenting which document. */
export interface DocumentCallPresenting {
    documentId: string;
    userId: string;
    since: number;
}

/**
 * Live, shared meta of a document call. Redis hash `call:meta:<callId>`
 * (TTL 4 h) behind RedisDocumentCallMetaStore; no owner replica — every
 * replica reads and writes the same hash, and every broadcast carries what
 * was read back after the write.
 */
export interface DocumentCallMeta {
    callId: string;
    /** Host document (also the LVS lobby name). */
    documentId: string;
    title: string;
    /** Review list, host document first. */
    documentIds: string[];
    /** Optional id → title map the client sent with the list, so a joiner can
     *  label rows before its own document list has loaded. */
    documentTitles?: Record<string, string>;
    hostUserId: string;
    media: 'video' | 'audio';
    startedAt: number;
    presenting: DocumentCallPresenting | null;
    invites: Record<string, DocumentCallInvite>;
    /** clientId → userId of every connection that has been in the call.
     *  Lets any replica name a participant whose socket lives (or died) on
     *  another replica. */
    clients?: Record<string, string>;
}

/** Mutable scalar fields of DocumentCallMeta. */
export type DocumentCallMetaPatch = Partial<Pick<DocumentCallMeta,
    'title' | 'documentIds' | 'documentTitles' | 'hostUserId' | 'media'>>;

/**
 * Storage for DocumentCallMeta. The in-memory implementation serves one
 * replica and tests; the Redis one is shared by every replica.
 */
export interface DocumentCallMetaStore {
    get(callId: string): Promise<DocumentCallMeta | null>;
    /** Create or overwrite the whole record (invites and clients included). */
    set(meta: DocumentCallMeta): Promise<void>;
    /** Merge scalar fields; returns the record read back, or null if absent. */
    patch(callId: string, patch: DocumentCallMetaPatch): Promise<DocumentCallMeta | null>;
    delete(callId: string): Promise<void>;
    /** Write the presenter, then read it back. The read-back is the value to
     *  broadcast: with two replicas racing, both converge on the last write. */
    setPresenting(callId: string, presenting: DocumentCallPresenting | null): Promise<DocumentCallPresenting | null>;
    /** Set (or with null remove) one person's invite. Per-person field, so two
     *  replicas marking different people never overwrite each other. */
    markInvite(callId: string, userId: string, invite: DocumentCallInvite | null): Promise<void>;
    /** Remember which user a connection belongs to (null removes it). */
    markClient(callId: string, clientId: string, userId: string | null): Promise<void>;
    /** Every call with a meta record — the sweep leader walks this. */
    listCallIds(): Promise<string[]>;
}

/** What `onOfflineInvite` receives: the invite as the caller sent it. */
export interface DocumentCallOfflineInvite {
    callId: string;
    documentId: string;
    title: string;
    callerId: string;
    callerName?: string;
    message?: string;
    documentIds: string[];
    media: 'video' | 'audio';
}

/**
 * Wire-form payload supplied by the FE alongside a call action. All
 * fields are optional at this layer — `invite` enforces callId+lobbyName
 * specifically; other actions are pass-through.
 */
export interface CallInvite {
    /** Stable per-call identifier (FE-generated UUID). Required on invite. */
    callId?: string;
    /** Human-readable lobby name shown in recipient UI. Required on invite. */
    lobbyName?: string;
    /** Preferred multi-target list. Empty/missing → broadcast. */
    targetUserIds?: string[];
    /** Originating user's id; FE supplies it for the self-filter on recipients. */
    callerId?: string;
    /** Free-form pass-through (callerName, avatarUrl, ringtone, …). */
    [k: string]: unknown;
}

/**
 * In-call broadcast payload for `participant-state` and `user-status` verbs.
 * Distinct from CallInvite because the field set is different and
 * load-bearing fields (participantId, callId, callerId, lobbyName) are NOT
 * actually optional at the room-bridge call site — passing them via
 * CallInvite + `as any` casts was masking missing-field bugs (see room
 * occupancy index corruption in HangoutOverlay.tsx late-join rebroadcast).
 *
 * FE-emitted fields are still permitted via the index signature for forward-
 * compat with new badges (e.g. handRaised) without a wire-protocol bump.
 */
export interface ParticipantStateBroadcast {
    /** SFU participant id — required for room bridge dedup and tile mapping. */
    participantId?: string;
    /** Stable per-call identifier. */
    callId?: string;
    /** Originating user's id. */
    callerId?: string;
    /** Lobby scoping key (e.g. `room:<slug>` or `global-hangout`). */
    lobbyName?: string;
    /** Human-readable name for the grid tile. */
    displayName?: string;
    /** True when the peer's screen-share producer is live. */
    screenSharing?: boolean;
    /** True when the peer's camera is enabled. Undefined treated as true (legacy). */
    cameraOn?: boolean;
    /** True when the peer's mic is unmuted. Undefined treated as true (legacy). */
    audioOn?: boolean;
    /** For `user-status` verb: see CallUserStatus ('reconnecting' is new). */
    status?: string;
    /** Legacy displayName source. */
    callerName?: string;
    /** Forward-compat for additional badges. */
    [k: string]: unknown;
}

/** Type guard for participant-state / user-status payloads. */
export function isParticipantStateBroadcast(p: unknown): p is ParticipantStateBroadcast {
    return typeof p === 'object' && p !== null;
}

/**
 * Outbound envelope written to each recipient's WS. Shape is byte-faithful
 * to the gateway original so the FE banner code keeps working unchanged.
 */
export interface CallEvent {
    type: 'call';
    action: CallAction | string;
    data: CallInvite | ParticipantStateBroadcast;
    /** ISO-8601 timestamp; generated at envelope-build time. */
    timestamp: string;
}

/**
 * Logger contract. Matches the project's pino-like surface. Pass a
 * NoopLogger in tests or wherever logs are unwanted.
 */
export interface CallLogger {
    debug(msg: string, meta?: unknown): void;
    info(msg: string, meta?: unknown): void;
    warn(msg: string, meta?: unknown): void;
    error(msg: string, error?: unknown): void;
}

/**
 * One match from `getClientsByUserId`. clientId is what CallService
 * actually routes to; userId is kept for logging/debug parity with the
 * gateway original. `nodeId` identifies the owning replica — local clients
 * carry this node's id, remote clients carry the peer node's id. Callers
 * generally don't need to branch on nodeId: `messageRouter.sendToClient`
 * routes via the per-node direct-message Redis pub/sub channel
 * transparently.
 */
export interface UserClientMatch {
    clientId: string;
    userId: string;
    nodeId?: string;
}

/**
 * The MessageRouter slice CallService needs (the M3 seam). Kept narrow
 * on purpose — these three verbs are the entire surface area.
 *
 *   - `getClientsByUserId(userIds, excludeClientId)` resolves authenticated
 *     userIds → clientId matches across the entire cluster (Redis-backed).
 *     Async: reads `websocket:user:<userId>:clients` hash + merges with the
 *     local in-memory scan.
 *   - `sendToClient(clientId, message)` writes to one socket. May return
 *     false on closed sockets, and may throw (sync or async) when the
 *     publish path errors; CallService uses Promise.allSettled so a
 *     single failure does not short-circuit the rest. Routes cross-node
 *     automatically when the clientId is owned by a peer replica.
 *   - `broadcastToAll(message, excludeClientId)` fans out to every
 *     connected client (sender excluded).
 */
export interface CallMessageRouter {
    /** A permanently fenced replica must preserve shared state for recovery
     * by a current owner instead of treating retirement as a user hang-up. */
    isReady?(): boolean;
    /** Stable connection context; when available, fences awaited authority
     * against a reused client ID with a different actor. */
    getClientData?(clientId: string): { userContext?: import('../server-ws/types').WsAuthContext } | null;
    getClientsByUserId?(
        userIds: string[],
        excludeClientId: string,
    ): UserClientMatch[] | Promise<UserClientMatch[]>;
    sendToClient(clientId: string, message: unknown): boolean | Promise<boolean | void> | void;
    broadcastToAll(message: unknown, excludeClientId: string): Promise<void> | void;
    /**
     * P5.2 — narrow accessor for the authed userId of a local client.
     * Used by `accepted` fan-out to route to the accepter's sibling
     * tabs (so they stop ringing). Returns null when the client isn't
     * known locally OR has no userContext.userId. Optional so existing
     * test implementations stay valid.
     */
    getUserIdForClient?(clientId: string): string | null;

    /**
     * Liveness probe — sync check that a clientId is locally connected
     * AND the underlying WebSocket is in OPEN readyState. Returns:
     *   - `true`  — local, open socket; safe to send
     *   - `false` — local socket exists but is closed/closing; ghost
     *   - `null`  — clientId is NOT local (could be on a peer node, or
     *               a stale Redis index entry from a crashed process);
     *               caller cannot determine liveness synchronously
     *
     * CallService uses this to skip ghost local sessions before fan-out
     * so we don't bump the failure counter on sockets we already know
     * are dead. Optional — implementations without it fall back to
     * trusting the index + sendToClient's silent-false return.
     */
    isClientLive?(clientId: string): boolean | null;
}

/**
 * Optional construction-time tunables. All hooks default to no-op /
 * allow-all so the service is usable without any wiring.
 */
export interface CallConfig {
    /**
     * Authorization hook. Called once per handleAction invocation BEFORE
     * any routing happens. Return false to deny (the service emits an
     * error frame and the action is dropped). Async decisions are awaited;
     * throws/rejections deny before any state mutation. Default: allow all.
     *
     * Replaces gateway's enforceChannelPermission interceptor — call
     * routing is direct user-to-user so there's no channel to gate, but
     * consumers may still want RBAC (e.g. block guest-mode initiations).
     */
    authorize?: (clientId: string, action: CallAction, data: CallInvite) => boolean | Promise<boolean>;

    /**
     * Cross-user policy gate for `invite` actions ONLY. Called AFTER
     * `authorize` passes the callerId-spoof check. Receives the resolved
     * callerId (authenticated) plus the resolved targetUserIds (empty
     * array for broadcasts). Return false (or a Promise that resolves
     * false) to deny — the service emits an error frame and the action
     * is dropped without fan-out.
     *
     * Production wires this to a platform-api endpoint that returns
     * mutual-follow / org-membership / not-blocked. Dev/Tilt leaves it
     * undefined so any user can call any user.
     *
     * For broadcasts (empty targetUserIds), the hook is passed an empty
     * array — consumers can deny broadcast entirely by checking
     * `targetUserIds.length === 0`.
     */
    canCall?: (
        callerId: string,
        targetUserIds: string[],
    ) => boolean | Promise<boolean>;

    /**
     * Optional metrics sink. Called for every successfully-dispatched
     * action with the targetKind discriminator. Consumers wire this to
     * their prom registry / CloudWatch collector / whatever.
     */
    recordCallAction?: (action: CallAction, targetKind: 'targeted' | 'broadcast') => void;

    /**
     * Whether an `invite` with no `targetUserIds` may go out. An untargeted
     * invite is broadcast to every connected client — on a multi-tenant host,
     * every tenant's. When false it is refused: the sender gets
     * `{ type: 'error', service: 'call', code: 'untargeted-invite', action,
     * callId, lobbyName, message }` and nothing is registered or sent.
     * Room walk-ins (`room:` / `<tenant>:room:` lobbies) and document-call
     * invites are never refused. Default here: true (the legacy behaviour);
     * `calls()` under attachRealtime defaults it to false.
     */
    allowUntargetedInvites?: boolean;

    /**
     * Optional persistence hook for the call→session binding. Called on
     * `invite` (with caller's data) and `accepted` (with accepter's
     * data). The recording-completed webhook later uses this to map
     * channelArn → callId so the recording can be associated with the
     * correct call participants. No-op when undefined.
     */
    persistCallBinding?: (binding: {
        callId: string;
        callerId: string;
        lobbyName: string;
        clientId: string;
        action: 'invite' | 'accepted';
    }) => Promise<void> | void;

    /**
     * Fired once when a call reaches its terminal state and is forgotten.
     *
     * This exists so a call can leave a trace somewhere other than the call
     * itself — the gateway posts it into the conversation the call happened
     * in, the way `onDocumentCreated` does for documents. Before it, a call
     * in a channel left NO record in the thread: you could not tell from the
     * conversation that a call had happened or who was in it.
     *
     * Only fires for calls that were ACCEPTED. An invite nobody picked up is
     * a missed call, which is a different event with different wording, and
     * recording it as "a call happened" would be false.
     *
     * `participantClientIds` are CONNECTIONS, not people — the same person on
     * two tabs appears twice, and a clientId is not a userId. Resolving them
     * is the consumer's job because only the consumer has the router.
     *
     * Best-effort: a throwing consumer is logged and swallowed. A call must
     * still tear down when the thing that records it is broken.
     */
    onCallEnded?: (summary: {
        callId: string;
        lobbyName: string;
        callerId: string;
        /** Display name captured at invite time, when the caller sent one. */
        callerName?: string;
        /** Epoch ms of the first accept (the invite time on a call restored without one). */
        startedAt?: number;
        endedAt: number;
        /** Absent when `startedAt` is, rather than reported as zero. */
        durationMs?: number;
        participantClientIds: string[];
    }) => Promise<void> | void;

    /**
     * Fired once when a call BECOMES a call: the first `accepted` on a DM or
     * group invite, or the first member into a room. The counterpart of
     * `onCallEnded` — a conversation can show a live card the moment there is
     * something to join, and `onCallEnded` then turns that card into the
     * record. `participantClientIds` are connections, as on `onCallEnded`.
     * Best-effort: a throwing consumer is logged and swallowed.
     */
    onCallStarted?: (summary: {
        callId: string;
        lobbyName: string;
        callerId: string;
        callerName?: string;
        /** Epoch ms of the accept (or the room's first join). */
        startedAt: number;
        participantClientIds: string[];
    }) => Promise<void> | void;

    /**
     * Fired once for an invite that never became a call: the caller hung up
     * before anyone answered (`cancelled`), a target said no (`declined`), or
     * the ring ran out (`no-answer`). Never fired for an accepted call — that
     * is `onCallEnded`'s. Document calls mark their targets missed per
     * person instead and do not fire this.
     */
    onCallMissed?: (summary: {
        callId: string;
        lobbyName: string;
        callerId: string;
        callerName?: string;
        invitedAt?: number;
        endedAt: number;
        reason: 'cancelled' | 'declined' | 'no-answer';
    }) => Promise<void> | void;
}

/**
 * Sync leadership check for the invite-sweep timer.  When wired and
 * returns `false`, the sweeper tick is skipped (a peer node owns the
 * sentinel and will run it instead).  When unwired (undefined) or
 * returns `true`, the sweeper runs locally — matching N=1 / pre-PR-W2.4
 * behaviour byte-for-byte.
 *
 * Optional callback so existing unit tests that build CallService
 * without a sweeper-leader continue to pass; the gateway wires this from
 * createSweeperLeader(SWEEPER_SENTINELS.CALL_INVITE) at server boot.
 */
export type CallSweeperIsLeader = () => boolean;

/**
 * Options bag for the lifted CallService constructor. Replaces the
 * gateway original's positional `(messageRouter, logger, metricsCollector)`
 * so additional dependencies can be added without breaking call sites.
 */
export interface CallServiceOptions {
    messageRouter: CallMessageRouter;
    logger: CallLogger;
    config?: CallConfig;
    /**
     * F2 (2026-08-22) — rejoin grace. When a disconnect would leave a
     * call with <=1 participants, the call is NOT torn down immediately:
     * survivors get `user-status: left` (with `rejoinGraceMs` in the
     * data) and the synthetic `ended` + forgetCall fire only if nobody
     * re-registers into the call within this window. This is what makes
     * a page refresh survivable in a 1:1 call — the refreshed side
     * comes back to a resume dialog / discovery banner instead of a
     * dead lobby. 0 disables (legacy immediate teardown). Default 30s.
     */
    rejoinGraceMs?: number;
    /**
     * Optional CallStateStore implementation. When provided, CallService
     * delegates per-call state to it (Redis-backed for multi-replica
     * durability). When undefined, falls back to per-process in-memory
     * Maps (today's behavior, fine for single-node deployments).
     */
    stateStore?: import('./CallStateStore').CallStateStore;
    /**
     * Optional cross-node pub/sub adapter for P1 multi-replica safety.
     * When provided, CallService publishes a `call:client-departed`
     * event on disconnect, and other nodes receive it + fire synthetic
     * `ended` to peers they own. Without this, a multi-replica gateway
     * leaks call state across the partition boundary.
     *
     * Implementation note: the gateway wires this from the existing
     * RedisPubSubManager so it shares the connection pool with channel-
     * message routing. Single-node deployments leave it undefined.
     */
    crossNodePubSub?: CallCrossNodePubSub;
    /**
     * PR-W2.4 — sync leadership check for the per-tick invite sweeper.
     * When provided and returns false, the tick is skipped + a
     * `cleanup_skipped_total{sweeper="call_invite",reason="not_leader"}`
     * metric is incremented.  When omitted, the sweeper runs every tick
     * (pre-PR / N=1 behaviour).
     */
    sweeperIsLeader?: CallSweeperIsLeader;
    /**
     * PR-W2.4 — optional metric hook called whenever a sweeper tick is
     * skipped because `sweeperIsLeader()` returned false.  Gateway wires
     * this to `recordCleanupSkipped('call_invite', 'not_leader')`.
     * Tests can pass a jest spy to assert skip counts.
     */
    onSweepSkipped?: (reason: 'not_leader') => void;
    /**
     * Optional tracing seam (v0.18.0 extraction). handleAction wraps each
     * dispatch in `withSpan('call.<action>', attrs, fn)` when provided.
     * The gateway wires distributed-core's `withSpan`; when omitted the
     * handler runs unwrapped — this library deliberately does not depend
     * on distributed-core, so tracing is the consumer's to supply.
     */
    withSpan?: CallWithSpan;
    /**
     * Document calls (2026-09-24) — live call meta (title, review documents,
     * presenter, per-person invites). Without it the four document-call
     * actions answer with an error frame and `kind:'document-review'`
     * invites behave like any other invite.
     */
    metaStore?: DocumentCallMetaStore;
    /**
     * Document calls — a target of a `kind:'document-review'` invite has no
     * connected client (or the caller asked not to ring). The gateway leaves
     * them a notification. Best-effort: a throw is logged and swallowed.
     */
    onOfflineInvite?: (targetUserId: string, invite: DocumentCallOfflineInvite) => Promise<void> | void;
    /**
     * Cluster-wide liveness of a clientId, used by the sweep leader to prune
     * roster entries whose socket died with its replica (the node's heartbeat
     * is gone). Return false only when the client is provably dead.
     */
    isClientAlive?: (clientId: string) => boolean | Promise<boolean>;
}

/** Shape of the injectable tracing wrapper (matches distributed-core's withSpan). */
export type CallWithSpan = <T>(
    name: string,
    attrs: Record<string, string | number | boolean>,
    fn: (span: { setAttribute: (k: string, v: string | number | boolean) => void }) => T | Promise<T>,
    opts?: { tracerName?: string },
) => Promise<T>;

/**
 * Narrow contract for the cross-node pub/sub coupling. Lets CallService
 * stay decoupled from Redis specifics — tests + single-node deployments
 * can pass null/undefined and the in-memory disconnect path still works.
 */
export interface CallCrossNodePubSub {
    /** Publish a cross-node call event. Topic is internal to CallService. */
    publish(topic: string, payload: string): Promise<void> | void;
    /** Subscribe to a cross-node call event. Returns unsubscribe fn. */
    subscribe(topic: string, handler: (payload: string) => void): () => void;
}

/** Minimal error envelope; mirrors the gateway createErrorResponse shape. */
export interface CallErrorFrame {
    type: 'error';
    service: 'call';
    message: string;
    /** Machine-readable reason, when the refusal has one
     *  (`'untargeted-invite'`). */
    code?: string;
    /** The refused frame's verb / call / lobby, when known. */
    action?: string;
    callId?: string;
    lobbyName?: string;
    timestamp: string;
}

/**
 * Per-call signaling state used by the in-process active-invite registry.
 * Replay-on-connect needs enough of the original invite payload to
 * reconstruct the toast envelope when a freshly-connected client picks
 * up an invite that fired before they were online.
 */
export interface ActiveCallState {
    callerId: string;
    lobbyName: string;
    targetUserIds: string[];
    participantClientIds: Set<string>;
    /**
     * Everyone who was EVER in this call, never pruned.
     *
     * `participantClientIds` is who is in the call right now, so it drains as
     * people hang up — by the time the last person leaves it is empty, and a
     * record built from it names one person out of however many were there.
     * This is the roster a record needs.
     */
    everParticipated?: Set<string>;
    /**
     * People (authenticated user ids, never a payload's claim) who took a
     * seat in this call — the caller on `invite`, each callee on `accepted`.
     * A seat outlives the socket it was taken on: this is who may take it
     * back from a fresh socket after a drop (`participant-state` rejoin).
     * Someone only rung, never seated, is not in it.
     */
    seatedUserIds?: Set<string>;
    invitedAt?: number;
    inviteExpiresAt?: number;
    /** Epoch ms of the first `accepted` — when the call became a call. */
    acceptedAt?: number;
    /** A target said no. Read when the caller then hangs up, so the record says "declined", not "cancelled". */
    declined?: boolean;
    originalCallerName?: string;
    originalLobbyName?: string;
    originalTargetUserIds?: string[];
}

/** Verbs accepted by `handleAction`. Exposed for consumer dispatch tables. */
export const ALLOWED_CALL_ACTIONS: ReadonlySet<CallAction> = new Set<CallAction>([
    'invite',
    'accepted',
    'declined',
    'cancelled',
    'ended',
    'participant-state',
    'user-status',
    // F3 — client→server query verb. `active-call` (the reply) is
    // deliberately NOT accepted here: it's server→client only.
    'status',
    // UX audit 2026-08-24 — durable per-user dismissal of a resumable
    // call. `forgotten` (the ack) is server→client only, like
    // `active-call`.
    'forget',
    // Document calls (2026-09-24). `call-meta` and `invite-expired` are
    // server → client only and deliberately absent.
    'meta',
    'set-documents',
    'present',
    'set-title',
    // Host moderation (2026-09-24).
    'mute-participant',
    'remove-participant',
    'transfer-host',
]);
