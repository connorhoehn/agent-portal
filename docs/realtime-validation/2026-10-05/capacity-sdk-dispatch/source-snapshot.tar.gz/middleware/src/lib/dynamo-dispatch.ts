// Hold work before invoking the SDK, rather than accumulating authority reads
// inside its HTTP-agent queue. This is a dispatch queue, never a result cache.
import { AsyncLocalStorage } from 'node:async_hooks';
import type { DynamoCommandClient } from '@connorhoehnslalom/realtime-modules/server/stores/dynamo';

type Permit = { active: boolean };
export class DynamoDispatchQueue implements DynamoCommandClient {
  private active = 0;
  private readonly waiting = new Map<symbol, () => void>();
  private readonly scope = new AsyncLocalStorage<Permit>();
  constructor(private readonly client: DynamoCommandClient, private readonly concurrency: number,
    private readonly maxWaiting = 4096, private readonly maxWaitMs = 5000) {
    if (!Number.isSafeInteger(concurrency) || concurrency < 1 || concurrency > 256
      || !Number.isSafeInteger(maxWaiting) || maxWaiting < 1
      || !Number.isSafeInteger(maxWaitMs) || maxWaitMs < 1) throw new Error('Invalid DynamoDB dispatch bounds');
  }

  send(command: any): Promise<any> {
    // A membership partition read sends its pages sequentially under one
    // permit. Released scopes inherited by detached callbacks cannot borrow.
    if (this.scope.getStore()?.active) return this.client.send(command);
    return this.dispatchMembershipRead(() => this.client.send(command));
  }

  /** Only sequential store reads run within this scope. The caller removes
   * its queued authority entry here, immediately before the SDK is invoked. */
  dispatchMembershipRead<T>(work: () => Promise<T>): Promise<T> {
    if (this.scope.getStore()?.active) return work();
    if (this.active >= this.concurrency && this.waiting.size >= this.maxWaiting) return Promise.reject(new Error('DynamoDB dispatch queue is full'));
    return new Promise<T>((resolve, reject) => {
      const key = Symbol();
      let timer: ReturnType<typeof setTimeout> | undefined;
      const start = () => {
        if (timer) clearTimeout(timer);
        this.waiting.delete(key);
        this.active++;
        const permit = { active: true };
        void this.scope.run(permit, async () => {
          try { resolve(await work()); }
          catch (error) { reject(error); }
          finally {
            permit.active = false;
            this.active--;
            this.waiting.values().next().value?.();
          }
        });
      };
      if (this.active < this.concurrency) start(); else {
        this.waiting.set(key, start);
        timer = setTimeout(() => {
          this.waiting.delete(key);
          reject(new Error('DynamoDB dispatch wait timed out'));
        }, this.maxWaitMs);
        timer.unref?.();
      }
    });
  }
}
