# Current capacity work — 2026-10-05

This is an in-progress record, not capacity or cloud acceptance. Keep the full
goal: Work/People huddle persistence and permissions, OrgIQ corpus document
links, and cloud video/chat/realtime for 100 simultaneous calls. The deployment
single-gateway guard remains in place. Default AWS identity is invalid; no
cloud changes or ECR pushes were attempted.

The sealed [retirement record](cluster-retirement-acceptance.md) retains the
0.104.0 library pin, 2,023 library tests, three Redis faults, eight BFF contracts
and nine fresh browser cases. Its source snapshot preserves that exact stage.
Its consumers were pinned to `68581f7023b9948b7f16cc094d723dc332683039`.
The admission stage pinned 0.105.0 at `be54e682d50d750ede04bdae5f47302039826626`; see
[admission acceptance](cluster-admission-acceptance.md) for that sealed evidence.
Both consumers now pin 0.106.0 at `c5c967ee18fb2fa6dabe126e2dcdd023a4a64dac`;
its focused inbox/producer acceptance is being recorded below.

Subsequent application changes combine identity epoch/grants in a single SQL
snapshot and batch only queued authority reads. Membership queries share only
before dispatch. A test reproduced an unhinted remote-removal race in sharing
already-started queries; that prototype was rejected. No settled positive
authority answers are cached. The revised gate passed 269 tests (2 skipped),
eight full BFF contracts and three actual Redis failure contracts.

The SDK pool experiment with 128 sockets did not meet latency targets; default
concurrency remains 50. `SOCIAL_CHAT_MAX_SOCKETS` accepts explicit 1–256 values.
SDK connection/reply deadlines are configured. An actual DynamoDB Local pause
proved a bounded history read failed as generic 500; it now returns retryable
503, preserves accepted seats/page/history and recovers after unpause. The
native fault passes and 27 focused call-chat regressions pass. These latest
changes have typecheck/build evidence; broader final gates remain pending.

The old driver forced all idle users to send simultaneously at startup.
`--chat-startup spread` follows the planned 30-second background cadence and
preserves paired-sender coverage; `burst` retains the old synchronized workload
and its failing evidence. The driver now waits for actual chat join receipts
and reports admission timing. All 100 calls and 1,000 sockets succeed in both
native steady shapes without collisions, denied actions, unexpected ends or
latency/health failures. The unrestricted Node 25 source processes exceed the
unchanged 700 MiB memory target, so that run remains unaccepted.

Initial compiled Node 22 image, built locally without pushing:
`sha256:478a732b3ee21b9e997e2411f782bc86766b42b8198e80499511292c30c8dd35`.
The two compiled BFFs have one CPU and 1,024 MiB each, expose 3065/3066, use a
separate router namespace and separate synthetic identities, and execute actual
provider SQL through a read-only mount of the test SDK adapter. Authentication
remains a non-production native fixture, not Cognito/Aurora/IAM proof.

Host SSH forwarding crashed with `poll: Invalid argument` near 1,000 forwarded
connections. Colima and Docker remained alive in the VM. The first two BFFs
also exposed an unhandled idle PostgreSQL pool error in the test adapter; an
error listener now lets it reconnect without seed fallback. No VM or daemon
restart was performed. The task-owned forwarding process was replaced with
control/fixture forwarding only. WebSocket load now runs inside the inspected
Docker network, as the existing soak setup requires.

Use `DOCKER_HOST=unix:///tmp/orgiq-capacity-docker.sock` for current Docker
commands. The task control forwarder PID is recorded in
`/tmp/orgiq-capacity-forwarder.pid` (last started 72922); it forwards only the
Docker Unix socket and 15483/16483/18063. The normal Colima host Docker socket
and unrelated host forwards are not repaired or restarted. Private runtime
and environment files under `/tmp` remain mode 600 and excluded from evidence.

The current internal pilot passed call/chat/delivery/memory gates in both
shapes, but the first shape failed health p99 because its first health sample
waited for a cold AWS diagnostics probe (144.1/135.1 ms at 0.5 s). This failure
is retained. It is not accepted as a complete pilot. Compiled working-set
memory is roughly 136–143 MiB in that pilot.

Initial independent containers, subsequently replaced:

- `orgiq-bff-capacity-a`: `0788fc82d22e6760297a71040c4449e2638161949acc189cf77ce1af1f15d5bc`
- `orgiq-bff-capacity-b`: `1006e9708e6b622447b042f1a872bdb854b07985e7cc59e08fb410d7b54fd6b0`
- Network: `orgiq-bff-capacity-network`; results: `orgiq-bff-capacity-results`.

The initial internal matrix on 0.104.0 is complete and unaccepted. Its exact
compiled source and all results are preserved in `capacity-health/manifest.json`.
Some steady/ring/churn shapes passed every target; other health/ring targets
failed. Soak chat p95 was 7,939.4 ms and synchronized burst chat p95 was
5,552.1 ms. Ten competing-tab races exposed five duplicate accepted seats.

The 0.105.0 atomic seat claim fixes that race. Its rebuilt constrained collision
profile passes every target: 1,000 connections, 100 calls, ten of ten unique
winners, no duplicate caller answers/cross-deliveries/unexpected ends, health
p99 35.1/43.8 ms and memory peaks 198.1/209.0 MiB. Current image is
`sha256:86d3dd3c30818d7850274eae771e3d13df42df8c54287d9bb52e271030dfea8d`.
That collision-stage runtime used `8020203ac5a727622069c179e16918382e16cfffa1207f3d0433c82ea7b80734`
and `4b165d10d00a8c547fc5ebbc134e6be5075bcf0a4637c6beb309a18b2c02cb25`;
these have subsequently been replaced.

The separate cookie `/realtime` path now owns a leased Redis namespace and
checks current directory authority at upgrade/subscription/delivery. Actual
REST job fanout reaches both cookie and JWT peers and ceases after retirement.
Directory coalescing shares only queued reads, not already-started snapshots.
Health diagnostics refresh independently and distinguish pending/stale results.
Current gates: 2,030 library tests, 287 application tests (1 skipped), ten full
BFF contracts, three Redis faults, one durable-store fault, 1,318 portal tests,
nine fresh local browser cases, typechecks/builds and the packed/compiled API.

The full 0.105.0 matrix finished and is unaccepted. Results and metrics are
preserved in `capacity-current/manifest.json`. Both ring-storm and churn shapes
passed, as did steady group four. Steady group two failed health p99 at
53.7 ms. Soak restored all 100 calls and 1,000 sockets through three genuine
credential renewal waves, but chat p95 was 8,038.2 ms and health p99 was
77.7/95.5 ms. Synchronized burst failed invite/accept/chat and health targets.
Do not treat session 64228 or its old container IDs as running.

Count/timing-only profiling found approximately 48,000 DynamoDB queries per
node, with the HTTP socket pool capped at the unchanged default 50. A full
200-item unread reply repeated authority checks for every record. Reply-only
policy/resource batching reduced measured queries to about 17,500 per node;
the identical burst still failed latency targets. Before/after results and
exact compiled source are preserved in `capacity-inbox-before/manifest.json`
and `capacity-inbox-after/manifest.json`. These stages do not include the
subsequent peer subscription API or cold-peer guard fix.

The new public readable-subscription probe checks current local or leased
peer connections, fresh channel authority, connection generations and receipt
ownership. Notification producers use it to avoid unread alerts while another
node hosts the reader. Actual DM and private-channel checks verify message
delivery without a live or stored unread alert, then verify alerts after the
reader unsubscribes. A 200-record native inbox test also found a cold-peer guard
ordering bug: the synchronous mirror was consulted before a fresh resource
read. The guard now runs after hydration, with fresh directory rights and all
pending membership fences at the send boundary. The native replay/removal
case passes and preserves all 200 stored records.

Library 0.106.0 at `c5c967ee18fb2fa6dabe126e2dcdd023a4a64dac` is pushed on
`feat/redis-realtime-router`. Its full 2,034-test gate (9 skipped), build/export
and actual packed TypeScript/runtime checks pass. Both consumer typechecks and
builds pass. The latest authority gate passes 52 tests; the broader application
gate passes 292 tests (1 skipped), all 12 native BFF contracts pass, all 1,318
portal tests pass, and nine fresh local browser cases pass in 46.3 seconds.
Browsers use local routing and stub media receipts. The initial browser launch
ran before BFF readiness and lacked the explicit fixture WebSocket endpoint;
those setup failures are retained, and the corrected fresh gate passes.

The focused [inbox/producer record](cluster-inbox-acceptance.md) captures the
0.106.0 change, source snapshot, library/application/portal gates and the
current compiled artifact. This does not accept overall capacity or cloud.

Latest compiled image:
`sha256:9493e0964c2bc1a72f89315c4d84cf96e1fce91cc32b15d54a7b22ec0dc96ac2`.
Current BFFs: `fc08f7923405f8ddca99d6e798d1404aa0b1b8502a180bb8cbb4bbf6e1876a80`
and `46fce6c4576d749bfc7a30e87018bf14ffc58ca111663a0737cc46bcd2c43245`.
The unchanged synchronized burst establishes every call/socket and all 800
paired senders deliver, with no collision/denial/disconnect errors and no new
unread alerts for the peer readers. Invite p95 is 1,930.3 ms, accept p95
984.0 ms and chat p95 4,712.6 ms; health p99 is 36.6/103.1 ms. Memory peaks
are 223.7/224.8 MiB. Latency and peer health remain unaccepted.

The current control bridge resolves `host.docker.internal` to the macOS host,
so store traffic still traverses published fixture ports. A read-only route
comparison is testing direct Docker-network transport. Only the inspected
DynamoDB fixture was additionally connected to the owned capacity network;
its existing loopback ports and native source fixtures remain available.
No application load on the direct store route has been accepted.
