# message-queue

Current version: **v0.2.3**

```
"@connorhoehnslalom/message-queue": "github:connorhoehnslalom/message-queue#v0.2.3"
```

SQS-compliant message queue system with Node.js/TypeScript. Supports standard and FIFO queues, dead-letter queues, and consumer groups.

## Features

- **Queue Types**: Standard (at-least-once) and FIFO (exactly-once) queues
- **Visibility Timeouts**: Prevent duplicate processing with configurable timeouts
- **Dead-Letter Queues**: Automatic routing of poison messages after max receive count
- **Delay Queues**: Per-queue default delay and per-message override (0-900 seconds)
- **Message Deduplication**: Content-based or explicit deduplication IDs for FIFO queues
- **Consumer Groups**: Coordinated consumption with partition assignment strategies (range, round-robin)
- **Batch Operations**: Send multiple messages in a single request
- **Message Attributes**: User-defined metadata with string, number, and binary types
- **HTTP API**: RESTful API for all queue operations
- **CLI**: Command-line interface for queue management, message operations, and admin tasks
- **Metrics**: Prometheus-compatible metrics endpoint
- **Comprehensive Tests**: Unit and integration tests with 80%+ coverage

## Architecture

```
┌─────────────────┐      ┌──────────────────┐      ┌─────────────────┐
│   HTTP Client   │─────▶│   Express API    │─────▶│  QueueService   │
│   or CLI        │      │   /api/v1/...    │      │                 │
└─────────────────┘      └──────────────────┘      └────────┬────────┘
                                                             │
                                  ┌──────────────────────────┼────────────────────┐
                                  │                          │                    │
                         ┌────────▼─────────┐    ┌───────────▼──────────┐   ┌───▼───────────┐
                         │  QueueInstance   │    │  ConsumerGroupMgr    │   │    Metrics    │
                         │  (per queue)     │    │  (partition assign)  │   │   Collector   │
                         └────────┬─────────┘    └──────────────────────┘   └───────────────┘
                                  │
                         ┌────────▼─────────┐
                         │ distributed-core │
                         │  BatchedQueue    │
                         └──────────────────┘
```

## Quick Start

### Installation

```bash
npm install
```

### Start the Server

```bash
npm run dev  # Development mode with hot reload
# or
npm run build && npm start  # Production mode
```

Server runs on `http://localhost:3000` by default.

### Optional Backends (solo / standalone dev)

Out of the box, message-queue runs single-node with in-memory storage —
no DynamoDB, no event-catalog, no Redis required. For a fully detached
solo-dev boot:

```bash
# Disable event-catalog schema validation (otherwise the publish path
# will try to hit http://localhost:3010 to look up event schemas):
export SCHEMA_VALIDATION_ENABLED=false

# (Default storage is already in-memory. To opt-in to the DDB-backed
# durable floor, set MESSAGE_QUEUE_STORE=ddb plus DYNAMODB_ENDPOINT.)

npm install --omit=dev && npm start
```

Pretty (colorized) logs are off by default so the prod-style
`npm install --omit=dev` install doesn't need `pino-pretty`. To enable
pretty logs locally: `LOG_PRETTY=true npm run dev`.

Durable acknowledgements commit the stored body deletion before releasing the
local lease. Store failures return an error, so clients can retry the same
receipt while it remains active. A valid receipt recovered after a restart can
remove the pending body, unless it has already been leased again.

This remains a **single-active-process** queue. Restart hydration can redeliver
before an earlier visibility timeout expires; consumers must be idempotent.
Delays, FIFO deduplication and consumer-group shadow queues are not established
as restart-durable. Do not enable overlapping replicas or infer those guarantees
from the existence of DDB adapter classes.

The reproducible MQ/MNS container acceptance profile lives in
[realtime-examples middleware-foundation](https://github.com/connorhoehn/realtime-examples/tree/main/examples/middleware-foundation).
It exercises actual HTTP publish/receive/ack across abrupt process and store
replacement, including acknowledgement after MQ restarts.

`MESSAGE_QUEUE_STORE` accepts `memory`, `ddb`, `ddb-v2`, `dynamodb`, or `dynamo`
(case-insensitive). Unset or blank retains the memory default; an unknown value
fails startup instead of silently disabling persistence. A DynamoDB endpoint
alone does not select durable storage. On AWS, select `ddb`, provision
`MESSAGE_QUEUE_TABLE` (default `mq-messages`, string keys `pk` and `sk`) and grant
the task role access; leave the local endpoint override unset.

### Readiness and shutdown

`GET /health` remains process liveness with `{ "status": "healthy" }`.
`GET /ready` checks the configured DDB message table with a bounded
DescribeTable request and returns 503 during storage outages or shutdown.
Memory mode has no durable dependency probe. This checks table availability,
not every write permission, downstream schema service, or Redis fanout path.
Use `/ready` for traffic admission and `/health` for liveness.

SIGTERM/SIGINT stop API admission and WebSockets, drain HTTP, shut down queue
runtimes, and close storage clients through service-runtime's bounded lifecycle
manager. Allow at least 30 seconds before forced termination. Hook failures are
logged; a normal process exit alone is not proof that all hooks succeeded.
This does not add multi-process queue ownership or a zero-downtime rollout.

### Create a Queue

```bash
# Using CLI
npx tsx src/cli/index.ts queues create my-queue

# Using curl
curl -X POST http://localhost:3000/api/v1/queues \
  -H "Content-Type: application/json" \
  -d '{"queue_name": "my-queue", "configuration": {}}'
```

### Send a Message

```bash
# Using CLI
npx tsx src/cli/index.ts messages send my-queue "Hello, World!"

# Using curl
curl -X POST http://localhost:3000/api/v1/queues/my-queue/messages \
  -H "Content-Type: application/json" \
  -d '{"message_body": "Hello, World!"}'
```

### Receive Messages

```bash
# Using CLI
npx tsx src/cli/index.ts messages receive my-queue

# Using curl
curl http://localhost:3000/api/v1/queues/my-queue/messages?maxMessages=10
```

### Delete a Message

```bash
# Using CLI
npx tsx src/cli/index.ts messages delete my-queue <receipt-handle>

# Using curl
curl -X DELETE http://localhost:3000/api/v1/queues/my-queue/messages/<receipt-handle>
```

## Configuration

Environment variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `3000` | HTTP server port |
| `HOST` | `0.0.0.0` | HTTP server host |
| `LOG_LEVEL` | `info` | Logging level (debug, info, warn, error) |
| `CORS_ORIGINS` | `*` | Comma-separated list of allowed CORS origins |
| `MAX_MESSAGE_SIZE` | `262144` | Maximum message size in bytes (256 KB) |
| `DEFAULT_VISIBILITY_TIMEOUT` | `30` | Default visibility timeout in seconds |
| `DEFAULT_RETENTION_PERIOD` | `345600` | Default retention period in seconds (4 days) |
| `METRICS_ENABLED` | `true` | Enable Prometheus metrics endpoint |

## CLI Commands

### Queue Operations

```bash
# List all queues
npx tsx src/cli/index.ts queues list [--prefix <prefix>]

# Create a queue
npx tsx src/cli/index.ts queues create <name> [--fifo] [--visibility-timeout <seconds>]

# Delete a queue
npx tsx src/cli/index.ts queues delete <name>

# Describe a queue
npx tsx src/cli/index.ts queues describe <name>
```

### Message Operations

```bash
# Send a message
npx tsx src/cli/index.ts messages send <queue> <body> [--delay <seconds>] [--group-id <id>]

# Receive messages
npx tsx src/cli/index.ts messages receive <queue> [--max-messages <count>]

# Delete a message
npx tsx src/cli/index.ts messages delete <queue> <receipt-handle>

# Purge all messages
npx tsx src/cli/index.ts messages purge <queue>
```

### Consumer Group Operations

```bash
# Join a consumer group
npx tsx src/cli/index.ts consumer-groups join <group-id> <consumer-id> [--strategy <range|round-robin>]

# Leave a consumer group
npx tsx src/cli/index.ts consumer-groups leave <group-id> <consumer-id>

# Describe a consumer group
npx tsx src/cli/index.ts consumer-groups describe <group-id>

# View offsets
npx tsx src/cli/index.ts consumer-groups offsets <group-id>

# Commit an offset
npx tsx src/cli/index.ts consumer-groups commit <group-id> <partition> <offset>
```

### Dead-Letter Queue Operations

```bash
# List DLQ queues
npx tsx src/cli/index.ts dlq list

# Inspect DLQ messages
npx tsx src/cli/index.ts dlq inspect <queue> [--limit <count>]

# Redrive messages from DLQ
npx tsx src/cli/index.ts dlq redrive <dlq> --to <target-queue> [--max-messages <count>]
```

### Admin Operations

```bash
# View service statistics
npx tsx src/cli/index.ts admin stats
```

## API Reference

### Queue Management

- `POST /api/v1/queues` - Create a queue
- `GET /api/v1/queues` - List queues (supports `?prefix=` filter)
- `DELETE /api/v1/queues/:name` - Delete a queue
- `GET /api/v1/queues/:name/attributes` - Get queue attributes
- `PATCH /api/v1/queues/:name/attributes` - Update queue attributes
- `POST /api/v1/queues/:name/purge` - Purge all messages

### Message Operations

- `POST /api/v1/queues/:name/messages` - Send a message
- `POST /api/v1/queues/:name/messages/batch` - Send multiple messages
- `GET /api/v1/queues/:name/messages` - Receive messages
- `DELETE /api/v1/queues/:name/messages/:receiptHandle` - Delete a message
- `PATCH /api/v1/queues/:name/messages/:receiptHandle` - Change visibility timeout
- `POST /api/v1/queues/:name/redrive` - Redrive messages from DLQ

### Consumer Groups

- `POST /api/v1/consumer-groups/:groupId/join` - Join a consumer group
- `POST /api/v1/consumer-groups/:groupId/leave` - Leave a consumer group
- `POST /api/v1/consumer-groups/:groupId/heartbeat` - Send heartbeat
- `POST /api/v1/consumer-groups/:groupId/offsets` - Commit offset
- `GET /api/v1/consumer-groups/:groupId/offsets` - Fetch offsets
- `GET /api/v1/consumer-groups/:groupId` - Get group info

### Monitoring

- `GET /health` - Health check
- `GET /ready` - Readiness check
- `GET /metrics` - Prometheus metrics

## Development

### Run Tests

```bash
npm test                # Run all tests
npm run test:watch      # Watch mode
```

### Linting and Formatting

```bash
npm run lint            # Check code style
npm run lint:fix        # Auto-fix issues
npm run format          # Format code with Prettier
npm run format:check    # Check formatting
```

### Project Structure

```
src/
├── api/                # HTTP API routes and middleware
│   ├── errorHandler.ts # Centralized error handling
│   ├── metrics.ts      # Prometheus metrics collector
│   ├── routes.ts       # API route definitions
│   └── validation.ts   # Request validation
├── cli/                # CLI commands
│   ├── commands/       # Command implementations
│   └── index.ts        # CLI entry point
├── server/             # Express server setup
│   ├── app.ts          # Express app factory
│   └── index.ts        # Server entry point
├── services/           # Core business logic
│   ├── QueueService.ts         # Queue orchestrator
│   ├── QueueInstance.ts        # Per-queue state management
│   └── ConsumerGroupManager.ts # Consumer group coordination
├── types/              # TypeScript type definitions
└── config.ts           # Configuration management

test/
├── integration/        # Integration tests
└── __tests__/          # Unit tests
```

## FIFO Queues

FIFO queues guarantee exactly-once delivery and strict ordering within message groups.

### Requirements

- Queue name must end with `.fifo`
- `message_group_id` is required for all messages
- `message_deduplication_id` required (unless content-based deduplication is enabled)

### Example

```bash
# Create FIFO queue
curl -X POST http://localhost:3000/api/v1/queues \
  -H "Content-Type: application/json" \
  -d '{
    "queue_name": "orders.fifo",
    "configuration": {
      "fifo_queue": true,
      "content_based_deduplication": true
    }
  }'

# Send FIFO message
curl -X POST http://localhost:3000/api/v1/queues/orders.fifo/messages \
  -H "Content-Type: application/json" \
  -d '{
    "message_body": "Order #12345",
    "message_group_id": "customer-123"
  }'
```

## Dead-Letter Queues

Messages that exceed `max_receive_count` are automatically moved to the configured DLQ.

### Example

```bash
# Create DLQ
curl -X POST http://localhost:3000/api/v1/queues \
  -H "Content-Type: application/json" \
  -d '{"queue_name": "my-dlq", "configuration": {}}'

# Create main queue with DLQ policy
curl -X POST http://localhost:3000/api/v1/queues \
  -H "Content-Type: application/json" \
  -d '{
    "queue_name": "my-queue",
    "configuration": {
      "redrive_policy": {
        "dead_letter_target_arn": "arn:message-queue:queue:my-dlq",
        "max_receive_count": 3
      }
    }
  }'
```

## Dependencies

- **distributed-core**: Core distributed system primitives (BatchedQueue, parseEnvNumber, env gates)
- **Express**: HTTP server framework
- **commander**: CLI framework
- **pino**: Structured logging
- **uuid**: Message ID generation

## Testing

The project includes comprehensive test coverage:

- **Unit Tests**: 70+ tests covering core services
- **Integration Tests**: 35+ tests for HTTP API and consumer groups
- **Coverage**: 80%+ across all modules

## License

MIT

## Contributing

Contributions welcome! Please ensure tests pass and code follows project style guidelines.

## Author

Connor Hoehn

---

**Generated with [Claude Code](https://claude.com/claude-code)**

### Backend service authentication

MQ now fails startup in `NODE_ENV=production` unless both
`MQ_SERVICE_AUTH_SECRET` and comma-separated `MQ_SERVICE_AUTH_ALLOWED_SERVICES`
are configured. Partial configuration also fails closed outside production.
Only `/health` and `/ready` remain unsigned. Every other HTTP surface, including
metrics, queue discovery, receipt deletion and ACL administration, requires
`X-Service-Auth`; WebSocket upgrades use the same gate. The optional legacy
`AUTH_ENABLED` ACL mode disables WS because its queue checks are HTTP-only.

Sign each request using service-runtime 0.4.0 `createServiceRequestHeaders`
(audience `message-queue`), binding method, path/query and exact UTF-8 body.
Event-catalog 0.7.0 accepts this hook as `messageQueue.requestHeaders` or
`DurableTransport.requestHeaders`. Its registry service reads the same
`MQ_SERVICE_AUTH_SECRET` for outbound calls. The MQ CLI reads that variable
and `SERVICE_ID` (default `mq-cli`, which must be in the receiver allowlist).
Legacy body-only signatures are intentionally rejected. Do not put secrets in
browser clients; the bundled admin UI needs an authenticated backend proxy.

This is a trusted-backend boundary: an allowed caller can operate all queues.
It does not make the legacy in-memory queue ACL map a durable per-user policy.
Holders of the shared secret can assert any allowlisted identity. Scope the
secret to this receiver, inject it from a secret store, use private/TLS
transport, and keep business/user authorization in the calling API. Signatures
expire after 60 seconds, but may be replayed unchanged within that window;
message consumers and mutating callers still need idempotency. HTTP redirects
are refused by signed clients. Production queue ownership/fencing and durable
ACL policy remain separate limitations.

## HTTP client and shared types

Node consumers import `HttpMessageQueue` and `MessageQueueError` from
`@connorhoehnslalom/message-queue/client`. Browser/type-only consumers use
`@connorhoehnslalom/message-queue/types`; that entrypoint has no Node, SDK or
server imports. The client imports only the service-runtime signing boundary
and Node crypto. It never creates a queue service or starts background timers
on import. Import and require resolve the same client and error classes.

```ts
import { HttpMessageQueue } from '@connorhoehnslalom/message-queue/client';

const queue = new HttpMessageQueue({ baseUrl: 'http://127.0.0.1:3000',
  serviceId: 'worker', secret: process.env.SERVICE_AUTH_SECRET });
await queue.ensureQueue({ name: 'jobs', fifo: false, visibilityTimeoutSeconds: 60 });
const [message] = await queue.receive('jobs', { waitSeconds: 10, max: 1 });
if (message) {
  // Commit an idempotent business result before acknowledging.
  await queue.ack('jobs', message.receipt_handle);
}
```

`ensure(name, configuration)` exposes the full queue configuration; conflicts
throw by default. `{ allowConflict: true }` returns the conflict for explicit
operator inspection, without accepting or changing that configuration.
`send` accepts FIFO group/dedup IDs, delay and catalog schema metadata.
`extend` returns `success` and an optional replacement receipt; use that receipt
for later renewals and ACK. False means the broker explicitly rejected a stale
receipt. Other failures throw, including unknown queues and validation errors.

`ready()` checks the dependency-aware root `/ready` endpoint. `attributes(queue)`
returns raw broker attributes, or `null` only for an absent queue; `inspect(queue)`
normalizes those attributes into the client inspection contract.

Each operation accepts `signal` and `timeoutMs`. The default 10-second request
deadline includes headers, signing and the response body; receive adds the
requested long-poll wait unless given an explicit deadline. The client does not
retry mutations automatically. `MessageQueueError` exposes `status`, `code` and
optional `retryAfterMs`, without echoing request/response bodies. A timeout after
send or ACK can leave an uncertain outcome: use stable deduplication IDs and
idempotent result writes. Redirects are rejected to protect signed headers.

The CommonJS-compatible client artifact is a compatibility boundary for existing
consumers. The queue server remains ESM; no repository-wide module migration is
part of this release. Run `npm run build` before client Jest tests, which consume
built artifacts. Git installs build missing artifacts via `prepare`.

## Runtime profiles (experimental delivery store)

`MESSAGE_QUEUE_PROFILE` selects `local-ephemeral`, `durable-single`, or
`durable-replicated`; `MESSAGE_QUEUE_REPLICAS` declares the intended process
count. Development defaults to local ephemeral with one process. Production
must select a profile and satisfy durable delivery requirements before stores or
listeners open. A replica count must agree with the selected profile.

The current memory and legacy DDB paths support only local ephemeral operation.
DDB preserves bodies but has not passed restart-safe delivery acceptance. Both
durable profiles are deliberately rejected until the transactional store and its
complete FIFO/redrive/subscription failure tests pass. Version 0.4.0 includes the
experimental store, but does not enable production durability guarantees. The
[delivery-state design](docs/delivery-state-v2.md) defines the repair and migration
boundary. Never relabel an adapter just because its database is persistent.

The experimental `ddb-v2` path now serves the standard queue HTTP lifecycle from
transactional storage. Set `MESSAGE_QUEUE_STORE=ddb-v2` and explicitly supply
`MESSAGE_QUEUE_DELIVERY_TABLE` for a pre-provisioned table with string `pk`/`sk`
keys. Local verification also supplies `DYNAMODB_ENDPOINT`. This path does not
create a table, hydrate legacy data or accept production/durable profiles yet.
It supports FIFO groups, five-minute producer deduplication and atomic automatic
dead-letter transfer. Create the DLQ first with the same FIFO mode; configure its
broker ARN in `redrive_policy`. Queue- or message-group-scoped deduplication uses
an explicit ID or the body hash when content-based deduplication is enabled.
Dead-letter provenance is broker metadata and does not consume the producer's
message-size allowance. Durable subscriptions, operator redrive/replay, quotas,
enforced schemas and per-group throughput settings remain explicitly unsupported.
Its table readiness, separate-process claim/restart behavior and
shutdown are covered in `test/integration/ddb-delivery-http.test.ts`; the broader
C5, migration and scale acceptance remain open. Existing consumer pins are unchanged.
