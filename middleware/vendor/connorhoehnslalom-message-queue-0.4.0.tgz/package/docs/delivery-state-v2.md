# Transactional delivery state (C3–C5)

Status: C3/C4 local policy acceptance, 2026-10-26. The released 0.3.0 client does
not repair queue storage. `src/storage/delivery/DdbDeliveryStore.ts` now implements
the standard and FIFO competing-consumer lifecycle in a separate v2 namespace. It is
available through QueueService and the server using explicit `ddb-v2` selection.
The C0 characterization still describes the legacy `ddb` path; runtime preflight continues to reject
durable profiles. The full implementation and acceptance below remain required.

## Verified store checkpoint

`test/integration/ddb-delivery-store.test.ts` exercises real transactions using
independent clients and a UUID-owned DynamoDB Local table. It covers concurrent
ensure/enqueue/claim, replacement-client visibility and receive count, receipt
rotation, stale ACK/renewal, ACK-versus-renewal races, accepted delay, pagination,
queue-generation fencing, logical retention, failed writes, uncertain responses,
append retention after ACK, and cancellation before mutation. An opted-in run
fails when the local endpoint is unavailable; it never passes a no-op body.

Run with `MQ_DDB_INTEGRATION=1 DYNAMODB_ENDPOINT=http://127.0.0.1:8000 npm test --
--runInBand test/integration/ddb-delivery-store.test.ts`. The test accepts only
loopback HTTP endpoints and deletes only its own table. Build and changed-file
lint are also required. This suite proves store semantics; the separate process
suite below supplies the HTTP and lifecycle evidence. Neither establishes scale.

`test/integration/ddb-delivery-http.test.ts` launches the compiled server in two
independent child processes and uses the public signed HTTP client. Ten cases
cover cross-process discovery and renewal/ACK, SIGKILL/replacement visibility and
receive counts, competing claims, persisted delay, generation fencing, a real
storage-proxy outage, cancelled polls and bounded shutdown without hook errors.
FIFO order/dedup and automatic DLQ movement are also exercised after SIGKILL and
replacement. The store suite now has 31 cases, including competing FIFO sends,
both directions of the last-head enqueue/ACK race, dedup response recovery after
ACK/restart, retention progression, failed/uncertain DLQ transactions, target
replacement, policy cycles and generation checks, and maximum-size provenance.
The fixture creates/deletes its own UUID table, owns every child it stops, and
never resets or restarts the shared application. Run it alongside the store test
with the same explicit local opt-in, after `npm run build`.

The HTTP suite also runs on Node 20.0.0. It exposed an early-Node keep-alive drain
problem in service-runtime; the queue now pins v0.5.1, whose isolated regression
failed before the fix and passes afterward. The shared helper closes sockets
when they become idle during drain, preserves accepted response bodies, reports
hook failure as exit code 1, and leaves no shutdown-budget timer behind when a
custom completion callback returns. Its owner suite passes 360 tests and its
lifecycle suite passes nine tests on Node 20.0.0.

The current store rejects operator redrive/replay, enforced schemas, quotas and
per-message-group throughput settings explicitly. Subscriptions, physical cleanup
of retired generation partitions, migration tooling and C5 are not implemented. Durable WebSocket
subscriptions and legacy-only administration fail explicitly rather than using
in-memory state. `openDeliveryStore` owns the SDK connection, validates the table
key schema, probes readiness and closes on failure/shutdown. The table must be
explicitly provisioned and named by `MESSAGE_QUEUE_DELIVERY_TABLE`; this path
never creates tables or hydrates legacy records. `openQueueRuntime` rolls back
earlier stores when a later startup step fails. Stop-admission cancels parked
receives before HTTP drain while accepted writes/ACKs can finish.
Only append bodies and receipt indexes carry delayed GC timestamps; delivery
records require explicit cleanup. The constructor accepts an existing document
client and table and never provisions infrastructure. Claim discovery is bounded
and returns an advisory cursor; the QueueService adapter resumes it and wraps
after the end. Its cursor cache is bounded and disposable. Queue listings and
approximate counts read paginated storage with an operation deadline; inspection
is currently proportional to retained delivery rows, not a constant-time scale
claim. If the deadline expires the request fails rather than fabricating counts.

## Ownership

Introduce a message-queue-owned delivery store. It authorizes enqueue, claim,
renewal, acknowledgement and dead-letter transfer. QueueInstance can cache
discovery results, but an in-memory queue, FIFO lock or receipt map cannot
authorize a durable transition. Retain the memory implementation for the local
ephemeral profile.

Use a distinct `v2` key namespace and queue generations. Do not hydrate old
message bodies into new delivery state automatically: that would discard their
visibility, group and delay semantics again. No old/new writer overlap is a
supported migration mode.

## Records and conditional transitions

- A queue pointer stores the normalized configuration, schema version, active
  generation and next ordered sequence. Every mutation conditions on its active
  generation. Deleting/recreating a name must not revive an old receipt or worker.
- An immutable append record stores the accepted body, metadata, enqueue sequence
  and logical retention deadline. This record supports future group subscriptions
  after the default competing-consumer delivery has been acknowledged.
- Each delivery scope has separate ordered delivery records: eligibility time,
  retention deadline, receive count, current receipt and lease deadline. Default
  delivery is one scope. A subscription generation is another scope.
- Receipt records index the current delivery identity and scope. They are lookup
  aids; the delivery record's current receipt is the authority.
- FIFO groups have durable head/tail state and linked delivery order. Enqueue,
  claim and removal update/check that state transactionally. A later eligible
  message must not bypass an earlier delayed or leased head.

Enqueue atomically advances ordering, retains the append record and creates the
default delivery. FIFO deduplication reservation belongs in this transaction,
not in a preceding successful-looking write. A failed enqueue cannot reserve a
dedup ID without retaining its message.

Claim atomically compares the observed delivery generation/attempt and eligibility,
increments the receive count, sets a new receipt/deadline and inserts its receipt
index. FIFO claim also checks the group head. Competing claim refusal returns no
delivery; a persistence error is an operation failure, never a memory fallback.

ACK deletes the delivery and receipt only when that receipt is still current,
unexpired and in the active queue/subscription generation. Renewal uses the same
conditions and atomically replaces the receipt index when rotating the receipt.
Neither operation trusts a process-local owner map. A stale receipt cannot change
the next attempt even when the old worker reconnects to another queue process.

Dead-letter movement commits destination retention before releasing the source
in one transaction. Destination enqueue, source removal, FIFO progression and
transfer identity must agree atomically. A target outage retains the source.
Self-targeting/cyclic policy validation and uncertain-response retries require
explicit tests; successful transfer cannot depend on an in-memory diagnostic.

## Subscriptions

The following subscription operations are planned work, not implemented guarantees.

Keep subscription lifetime separate from live workers. A subscription stores its
generation, earliest/latest starting position and materialization cursor. A
bounded transaction copies a page of append records into that scope and advances
its cursor together. Cursor/generation conditions prevent replay of an already
acknowledged copy after a retried expansion. No fire-and-forget fan-out.

Last-member departure removes membership only. Explicit unsubscribe fences the
generation; re-subscription gets a new one. Old offset commits, ACKs and worker
heartbeats must fail against the new generation. The legacy ephemeral consumer
group API remains a deliberate compatibility mode, not an implicit durable
subscription.

## Implemented FIFO and dead-letter transactions

The v2 delivery authority keeps queue generations, immutable append history,
receipt predicates and the existing server adapter. `records.ts` owns internal
record/key definitions; `fifo.ts` builds group transitions used in the same
transactions as body acceptance and removal. No QueueInstance lock or local
scheduling map authorizes durable FIFO delivery.

For each delivery scope and FIFO message group, store head/tail sequence numbers
and a next-sequence link on each delivery. Enqueue must atomically advance the
queue sequence, retain the body/delivery, reserve deduplication, advance the group
tail, and link the previous tail. Compare the observed tail and require its link
to be unset. Claim condition-checks that this delivery is the group's head; a
delayed or leased head therefore blocks only its own group. ACK/expiry advance
the head using the stored next link, or remove an empty group only if head and
tail still match. If enqueue wins a race with last-item removal, retry removal
from fresh links rather than orphaning the new tail. Expired non-head deliveries
remain logically ineligible until they can be unlinked from the head; never TTL
delete them independently.

Deduplication records retain the original accepted response for the dedup window,
including after ACK and restart. The reservation and retained message are one
transaction. A concurrent duplicate reads the committed record and returns the
original response; a failed first write cannot consume the ID. Content-based
deduplication hashes the body, and explicit queue-versus-message-group scope must
match the declared queue configuration.

On receive-count exhaustion, compose destination enqueue and source release in
one transaction, including both queues' generation predicates, FIFO progression
and a stable transfer identity. An unavailable/missing destination must leave the
source retained. Reject self-targets and policy cycles; when creating policy
links, condition-check the generations read while walking the target chain so a
concurrent delete/recreate cannot invalidate validation. Avoid touching the same
DDB item twice in a transaction when composing the builders. Test uncertain
responses, competing transfers and destination FIFO contention against real DDB,
then extend the existing separate-process fixture instead of building a new stack.

These transaction boundaries now pass the store and process cases above. The
five-minute dedup record stores the accepted response even after ACK. Automatic
DLQ movement has its own source-generation/scope/sequence identity and bypasses
producer dedup reservations; a producer cannot suppress poison retention. Source
removal, destination enqueue, both FIFO heads and the transfer record commit
together. Provenance retains source message/queue, attempts, event/schema metadata
and original timestamp/dedup identity. Required target type is the source's FIFO
mode; target chains are bounded to 32 destinations and validated transactionally.
An absent/incompatible target returns `DeadLetterUnavailable` and retains the
source until normal retention or successful retry. Logical retention is checked
again after reading/preparing the destination. This is automatic policy movement,
not implementation of the legacy operator replay/redrive endpoints.

Body plus serialized user attributes consume the configured producer size
allowance. Broker system attributes do not. A real boundary test reproduced an
accepted body becoming too large only because DLQ provenance was added, then
passed after this distinction. Standard delivery remains at-least-once; business
idempotency is still a consumer responsibility.

## DynamoDB constraints and bounds

Use `TransactWriteItems` for these transitions, not `BatchWriteItem`. Put each
item's predicate on its own update/delete; a transaction cannot both condition-
check and update the same item. Keep transactions below both the 100-item and
4 MB limits, including duplicated payload bytes during expansion. Retry
conditional contention separately from unavailable storage. A stable transaction
token helps uncertain retries, but its ten-minute window is not a permanent
business idempotency guarantee. [AWS transaction semantics](https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/transaction-apis.html).

Candidate discovery must paginate even when a filtered page returns no eligible
messages. Query limits apply before filtering; an empty page is not an empty
queue when `LastEvaluatedKey` exists. Use bounded pages and cancellation rather
than hydrating the entire retained log. [AWS query semantics](https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/Query.KeyConditionExpressions.html).

Logical retention controls delivery. Physical TTL is cleanup, not a lease clock.
Do not TTL-delete delivery/list nodes whose disappearance would strand a FIFO
head or break an offset transition. Unlink them transactionally first. Append
bodies and expired receipt indexes can use delayed physical cleanup; no reader
may expose a logically expired message merely because its bytes remain.

An ordered per-queue sequence is a contention point. This design does not claim
unbounded per-queue throughput. Measure that limit separately after correctness;
keep the store interface independent of physical partitioning so sharding does
not require application/client changes. Leases also require an explicit bounded
clock-skew assumption; receipt fencing remains necessary even with synchronized
clocks.

## Acceptance and migration

First prove the store directly against a UUID-owned DynamoDB Local table using
two independent clients. Then run separate queue processes over HTTP. Required
cases include restart visibility, accepted delay, simultaneous claim, stale ACK
and renewal, durable receive count, write/response failure, FIFO head blocking,
dedup after ACK/restart, retention, atomic DLQ and subscription generation races.
Close/delete only the clients/tables those tests create.

Keep durable/replicated capability declarations unavailable until their complete
store and process tests pass. A database endpoint or successful body write is
insufficient evidence. Host readiness must also probe required storage and stop
admission during drain or ownership loss.

Migration needs a dry-run inventory, intake pause, live-attempt drain or explicit
transfer, generation-scoped import, count verification and retained legacy data.
Rollback after v2 writes requires a tested reverse transfer; changing the package
pin alone is not rollback. No shared stack migration or cloud deployment is
authorized by the local characterization harness.
