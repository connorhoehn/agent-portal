# Observability

The service exposes a Prometheus text endpoint at `GET /metrics`. Counters and
gauges are unlabeled unless documented otherwise below.

## Labeled counters

### `mq_dlq_routed_total{queue,reason}`

Messages routed to a dead-letter queue, broken out by source queue and
the reason the routing fired. Incremented from
`src/services/QueueInstance.ts` whenever a message is forwarded to the
DLQ.

Reasons emitted today:

| reason | meaning |
| --- | --- |
| `max_receive_count_exceeded` | The lease's `ApproximateReceiveCount` exceeded the queue's `redrive_policy.max_receive_count` and the message was forwarded to its configured DLQ. |

When you add a new DLQ routing path, pass a stable `reason` snake-case
string to `metricsCollector.incrementDlqRouted(queueName, reason)` so
dashboards can keep an enum-style breakdown.

Example alert: a sudden spike in
`rate(mq_dlq_routed_total{reason="max_receive_count_exceeded"}[5m])` on
a single queue typically indicates a poisoned message or a broken
downstream consumer for that queue.

### `mq_consumer_group_rebalance_total{group}`

Consumer-group rebalances, broken out by group id. Incremented by
`src/services/ConsumerGroupManager.ts` on every join and leave (the
underlying distributed-core coordinator rebalances on each membership
change).

A high `rate(mq_consumer_group_rebalance_total{group="..."}[5m])` for a
single group usually means consumers in that group are flapping —
either their heartbeats are timing out or the consumers are
crash-looping.

## Other metric naming notes

- Existing global counters (`messages_sent_total`, `messages_received_total`,
  `messages_deleted_total`, etc.) are intentionally unlabeled today.
  Per-queue / per-group breakouts are added on a case-by-case basis as
  labeled counters with the `mq_` prefix to avoid colliding with the
  unlabeled forms.
- Counter names that ship labels live in `src/api/metrics.ts`. Each new
  labeled metric needs a corresponding `# HELP` / `# TYPE` block in
  `MetricsCollector.toPrometheus()` and an entry in this document.
