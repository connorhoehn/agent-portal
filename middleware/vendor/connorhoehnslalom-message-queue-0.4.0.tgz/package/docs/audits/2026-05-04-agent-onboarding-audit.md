# Agent Onboarding Audit: message-queue
**Date**: 2026-05-04  
**Agent**: message-queue  
**Audit Type**: Kickoff / Constitution Refresh

## Executive Summary

This is a **greenfield project** — only bootstrap commits exist. No `.planning/` directory, no implementation code, no tests. The README provides a clear mission: build an SQS-compliant message queue in Rust with a React admin UI, using the distributed-core library, supporting multi-node operation.

## Findings

### 1. Planning Documentation
**Status**: Not present.

- No `.planning/` directory exists.
- No `STATE.md`, `ROADMAP.md`, `MILESTONES.md`, or handoff docs.
- No `RETROSPECTIVE.md`, `PROJECT.md`, or `REQUIREMENTS.md`.

### 2. Repository Structure
**Status**: Skeleton only.

```
.
├── .agent/CONSTITUTION.md  (placeholder, awaiting this audit)
├── .claude/settings.json   (agent-hub MCP permissions configured)
├── .gitignore
├── README.md               (mission statement + operator context)
├── docs/                   (empty)
├── src/.gitkeep            (no implementation)
└── test/.gitkeep           (no tests)
```

### 3. Git History
**Status**: 3 commits, all bootstrap.

```
2930cd1 chore: add Claude Code settings with agent-hub MCP permissions
e596a1d agent: add CONSTITUTION.md (north star for self-driven work)
7b2fe6f chore: bootstrap message-queue repo
```

No feature development, no migration history, no bug-fix trajectory.

### 4. README Analysis
**Mission** (from README line 3-5):
> In-process and standalone message queue with standard semantics: send, receive, delete, visibility timeout, dead-letter queues, and FIFO ordering. Enables decoupled async communication between sibling projects. Ships as an npm package with an HTTP server mode.

**Operator Context** (from README line 5-6):
> Build this in rust and have goals to make this SQS compliant. and it should use the distributed core project and have an admin page built in react to allow for visibility. It should work across multiple nodes and be able

(Note: text cuts off mid-sentence; likely truncated during commit.)

### 5. Dependencies & Contracts
**Status**: No dependencies declared yet.

- No `Cargo.toml` (Rust project manifest).
- No `package.json` (npm packaging + React admin UI build).
- README mentions "distributed-core project" as a dependency, but no actual integration exists.

### 6. Test Suite Baseline
**Status**: No tests to run.

`test/` contains only `.gitkeep`. No test framework configured.

### 7. Cross-Repo Contracts
**Status**: To be established.

- **Consumer surface**: This project will **provide** an npm package + HTTP API consumed by sibling projects.
- **Producer dependency**: This project will **consume** the `distributed-core` library (assumed to be another agent-hub-managed repo, but not verified).

## Proposed Current Phase

**Phase 1: Foundation — Rust + Core Integration**

**Phase north-star**:  
Rust-based message queue library with SQS-compliant semantics (send, receive, delete, visibility timeout, DLQ, FIFO) integrated with `distributed-core` for multi-node coordination. Core library stable; no UI or HTTP server yet.

**Exit criteria**:
- Rust project configured (`Cargo.toml`, linting, test framework).
- Core primitives implemented: Queue, Message, VisibilityTimeout.
- Integration with `distributed-core` for distributed state.
- Unit tests green (≥80% coverage on core paths).
- No npm packaging, no HTTP server, no React admin yet — those are Phase 2.

**Duration estimate**: 15-25 self-driven tasks (given 150-200 LOC cap per task, targeting ~3-4k LOC for core library).

## Proposed Self-Driven Backlog (Ranked)

All items scoped to ≤150 LOC per task. Larger items broken into subtasks.

### P1 — Critical path, unblock everything else

1. **Bootstrap Rust project structure**  
   **LOC**: ~40  
   **Pick this if**: No `Cargo.toml` exists.  
   **Deliverable**: `Cargo.toml` with workspace config, basic linting (clippy), test framework (cargo test), `.gitignore` for Rust artifacts.

2. **Define core message types + in-memory queue stub**  
   **LOC**: ~120  
   **Pick this if**: No `src/queue.rs` or `src/message.rs` exists.  
   **Deliverable**: `Queue`, `Message`, `MessageId` types; in-memory HashMap-backed queue; send/receive/delete operations (no visibility timeout yet); unit tests for happy path.

3. **Integrate distributed-core for cross-node state**  
   **LOC**: ~180 (split into 2 tasks if needed)  
   **Pick this if**: Queue is in-memory only; no distributed-core dep in `Cargo.toml`.  
   **Deliverable**: Depend on `distributed-core`; use its state-sync primitives for queue metadata; multi-node send/receive works in tests.

### P2 — Core semantics, enable SQS compliance

4. **Implement visibility timeout**  
   **LOC**: ~100  
   **Pick this if**: Messages can be received but not "locked" for processing.  
   **Deliverable**: `receive_message` sets visibility timeout; message invisible to other consumers until timeout expires or message deleted; tests for timeout expiry.

5. **Implement dead-letter queue (DLQ)**  
   **LOC**: ~90  
   **Pick this if**: No retry/DLQ logic exists.  
   **Deliverable**: `max_receive_count` attribute; messages exceeding count move to configured DLQ; tests for DLQ routing.

6. **Implement FIFO ordering**  
   **LOC**: ~140  
   **Pick this if**: Queue delivers messages in arbitrary order.  
   **Deliverable**: FIFO queue variant; respects message group IDs; deduplication IDs; tests for ordering guarantees.

### P3 — Operator visibility, hardening

7. **Add structured logging (tracing crate)**  
   **LOC**: ~60  
   **Pick this if**: No logging exists; hard to debug in multi-node scenarios.  
   **Deliverable**: `tracing` crate integrated; `info!`/`debug!` calls on send/receive/delete/timeout events; log level configurable via env.

8. **Add metrics (prometheus or similar)**  
   **LOC**: ~80  
   **Pick this if**: No observability for queue depth, throughput, DLQ rate.  
   **Deliverable**: Metrics for messages sent/received/deleted, queue depth, DLQ moves, visibility timeout expirations; `/metrics` endpoint stub (HTTP server in Phase 2 will expose it).

9. **Property-based tests for queue invariants**  
   **LOC**: ~120  
   **Pick this if**: Only unit tests exist; no fuzzing or property checks.  
   **Deliverable**: `proptest` or `quickcheck` tests for: no message duplication, FIFO ordering holds under concurrent load, visibility timeout always expires correctly.

10. **Benchmarks for send/receive throughput**  
    **LOC**: ~70  
    **Pick this if**: No performance baseline exists.  
    **Deliverable**: `criterion` benchmarks for send/receive ops; baseline recorded in `docs/benchmarks/`.

## Out of Scope for Phase 1

- **HTTP server**: Phase 2.
- **React admin UI**: Phase 2.
- **npm packaging**: Phase 2.
- **Cloud deployments**: Never (per hard rules).
- **SQS protocol compatibility layer**: Phase 3 (after core semantics stable).

## Recommendations

1. **Update constitution** with the proposed Current Phase + ranked backlog above.
2. **Create `.planning/` directory** and seed it with `STATE.md` (current phase), `ROADMAP.md` (Phase 2/3 outline), and `REQUIREMENTS.md` (extracted from README).
3. **File follow-up task** to fix README truncation (line 6 cuts off mid-sentence).
4. **Clarify distributed-core dependency**: Is it a sibling agent-hub repo? If yes, establish handoff protocol. If no (external crate), document the crate name + version strategy.

## Test Suite Baseline

**Status**: No tests to run (skeleton repo).  
**Follow-up**: Task #1 (Bootstrap Rust project) includes test framework setup. Next audit after 5 self-driven tasks should verify green test suite.

## Blockers

None at this time. This is a greenfield project; no legacy debt, no conflicting conventions.

---

**Audit completed**: 2026-05-04 12:40 UTC  
**Next steps**: Handoff to `orchestrator` with proposed constitution updates.
