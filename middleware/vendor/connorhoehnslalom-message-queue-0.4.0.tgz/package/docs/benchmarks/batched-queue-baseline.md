# InMemoryBatchedQueue baseline

Single-node baseline for `InMemoryBatchedQueue` from `distributed-core/messaging-queue`.
Each row is ~100,000 messages total. Future PRs
can diff against this to catch regressions.

**Date:** 2026-05-17
**Platform:** darwin arm64
**CPU:** Apple M3 Max (16 cores)
**Memory:** 48 GB
**Node:** v25.9.0
**distributed-core:** pinned in package.json

## Send (`enqueueBatch`)

| Batch size | Ops/sec (enqueueBatch calls) | Messages/sec | Iterations | Elapsed (s) |
| ---: | ---: | ---: | ---: | ---: |
| 1 | 2,894,858 | 2,894,858 | 100,000 | 0.03 |
| 10 | 600,790 | 6,007,900 | 10,000 | 0.02 |
| 100 | 87,301 | 8,730,193 | 1,000 | 0.01 |
| 1000 | 10,303 | 10,303,877 | 100 | 0.01 |

## Receive (`leaseBatch` + `completeBatch`)

| Batch size | Ops/sec (leaseBatch+completeBatch calls) | Messages/sec | Iterations | Elapsed (s) |
| ---: | ---: | ---: | ---: | ---: |
| 1 | 52,596 | 52,596 | 100,000 | 1.90 |
| 10 | 7,393 | 73,932 | 10,000 | 1.35 |
| 100 | 1,492 | 149,242 | 1,000 | 0.67 |
| 1000 | 148 | 148,380 | 100 | 0.67 |

## How to reproduce

```bash
npx tsx scripts/benchmark-batched-queue.ts
```

Throughput is hardware-dependent; record the machine specs above when
regenerating. The script tunes iterations to keep total work near
~100,000 messages so smaller batch sizes pay
their per-call overhead in full.
