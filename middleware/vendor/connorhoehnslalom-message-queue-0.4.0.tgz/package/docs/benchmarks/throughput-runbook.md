# Throughput benchmark runbook

End-to-end throughput harness that validates the **Phase 3 exit
criterion**: *10k msg/sec sustained for 1 hour with zero loss.*

The harness exercises the public `QueueService` API
(`sendMessageBatch` -> `receiveMessage` -> `deleteMessage`) so it
measures everything a real producer/consumer pair pays for, not just
the raw `BatchedQueue` primitives. For the lower-level baseline see
`docs/benchmarks/batched-queue-baseline.md`.

File: `test/benchmarks/throughput.bench.ts`

## Running

The benchmark is **skipped by default** so regular `npm test` runs stay
fast. Set `BENCH_RUN=true` to actually execute it. The Jest config's
default `testMatch` excludes `*.bench.ts`, so you must pass an explicit
`--testMatch` override (or the file path with a custom matcher).

### 5-second smoke (CI gate)

Validates the harness wiring at modest load. Should complete in ~15s
including consumer drain.

```bash
BENCH_RUN=true \
BENCH_DURATION_SEC=5 \
BENCH_TARGET_TPS=1000 \
NODE_OPTIONS='--experimental-vm-modules --max-old-space-size=1536' \
npx jest \
  --workerIdleMemoryLimit=512MB \
  --maxWorkers=1 \
  --testMatch '**/throughput.bench.ts'
```

### 1-hour full run (release gate)

Validates the Phase 3 exit criterion. Pin to a quiet host; cluster
runs should target a 3-node `docker compose -f docker-compose.cluster.yml`
topology before flipping the M2 milestone.

```bash
BENCH_RUN=true \
BENCH_DURATION_SEC=3600 \
BENCH_TARGET_TPS=10000 \
BENCH_BATCH_SIZE=10 \
BENCH_CONSUMER_COUNT=8 \
BENCH_CONSUMER_DRAIN_MS=30000 \
BENCH_REPORT_JSON=./bench-1h.json \
NODE_OPTIONS='--experimental-vm-modules --max-old-space-size=4096' \
npx jest \
  --workerIdleMemoryLimit=2048MB \
  --maxWorkers=1 \
  --testMatch '**/throughput.bench.ts'
```

## Environment variables

| Var                       | Default     | Notes |
| ------------------------- | ----------- | ----- |
| `BENCH_RUN`               | (unset)     | Must be `"true"` or the suite is skipped. |
| `BENCH_DURATION_SEC`      | `5`         | Producer runtime in seconds. Consumer keeps draining after. |
| `BENCH_TARGET_TPS`        | `10000`     | Open-loop target sends per second. |
| `BENCH_BATCH_SIZE`        | `10`        | Messages per `sendMessageBatch` call. |
| `BENCH_BACKEND`           | `memory`    | `memory` runs against `InMemoryMessageStore`. `ddb` is reserved for a future durable-backed wiring and currently throws. |
| `BENCH_CONSUMER_COUNT`    | `4`         | Number of parallel receive loops. |
| `BENCH_CONSUMER_DRAIN_MS` | `10000`     | Quiet-window after producer finishes before consumers exit (guards against momentary empty polls). |
| `BENCH_REPORT_JSON`       | (unset)     | If set, the JSON report is also written to this file path. |

## Assertion

The single hard assertion is **`loss === 0`** (sent - received). Throughput
numbers are reported for diagnostics but never asserted. The harness
should pass at any reasonable TPS given enough headroom; if the
machine can't keep up with `BENCH_TARGET_TPS`, the achieved-TPS field
tells you, but the test only fails if messages were dropped.

## Report shape

```jsonc
{
  "config": {
    "durationSec": 5,
    "targetTps": 1000,
    "batchSize": 10,
    "backend": "memory",
    "consumerCount": 4,
    "consumerDrainMs": 10000
  },
  "result": {
    "sent": 5010,
    "received": 5010,
    "loss": 0,
    "elapsedSec": 15.005,
    "achievedSendTps": 1002,         // sent / durationSec
    "achievedReceiveTps": 334,       // received / elapsedSec (drain included)
    "sendLatencyMs":   { "count": 501,  "p50": 0.067, "p99": 0.135, "mean": 0.072, "max": 1.157 },
    "receiveLatencyMs":{ "count": 501,  "p50": 0.046, "p99": 0.112, "mean": 0.050, "max": 0.541 },
    "endToEndLatencyMs":{ "count": 5010, "p50": 2,    "p99": 6,    "mean": 2.149, "max": 6 }
  }
}
```

Fields:

- `sent` / `received` / `loss` — message counts. `loss` is the
  zero-loss assertion target.
- `elapsedSec` — wall-clock from producer start through consumer drain
  exit; this is why `achievedReceiveTps` runs lower than send TPS
  (the receive denominator includes the drain window).
- `achievedSendTps` — `sent / durationSec` (the producer budget).
- `sendLatencyMs` — per-`sendMessageBatch` call latency in ms.
- `receiveLatencyMs` — per-`receiveMessage` call latency in ms (only
  non-empty receives are sampled).
- `endToEndLatencyMs` — message-level latency from the producer
  timestamp embedded in the body to the consumer's receive time, in
  ms. This is the headline number for downstream SLOs.

## Smoke baseline

Recorded 2026-05-18 on darwin arm64 (Apple M3 Max, Node v25.9.0):

| Metric          | Value |
| --------------- | ----- |
| Duration        | 5s producer + 10s drain |
| Target TPS      | 1000 |
| Achieved send TPS | 1002 |
| Sent / Received | 5010 / 5010 |
| Loss            | 0 |
| Send p50 / p99  | 0.07 / 0.14 ms |
| Receive p50/p99 | 0.05 / 0.11 ms |
| End-to-end p50/p99 | 2 / 6 ms |

The 5-second smoke is **harness validation only** — it doesn't prove
the 10k/sec exit criterion. Run the 1-hour variant on the target
deployment topology before flipping Phase 3 exit.
