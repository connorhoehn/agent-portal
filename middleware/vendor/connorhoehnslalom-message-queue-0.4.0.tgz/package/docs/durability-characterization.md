# C0 durability characterization

Run against an already running local DynamoDB service:

```sh
LOG_LEVEL=fatal npx tsx scripts/characterize-durability.ts
```

`MQ_CHARACTERIZATION_ENDPOINT` defaults to `http://127.0.0.1:8000` and accepts
loopback HTTP addresses only. The script creates and deletes its own UUID-named
table; it never resets a shared table. It uses local credentials and includes a
positive durable-send/ACK control. Infrastructure errors fail the run without
claiming a reproduced delivery defect.

Exit 2 means at least one defect reproduced, 0 means all measured guarantees
held, and another failure means incomplete execution. Preserve the JSON report;
these observations are a baseline for the chassis repair, not passing production
acceptance. All four observation flags should be false after repair.

This first slice measures premature redelivery after restart, missing persistence
for an accepted delayed message, competing independent store clients and ignored
durable-claim refusal. It does not yet cover separate processes/HTTP, stale ACK,
FIFO, consumer-group backlog, event-catalog poison handling or application job
attempts. Those remain in the cross-project chassis plan.
