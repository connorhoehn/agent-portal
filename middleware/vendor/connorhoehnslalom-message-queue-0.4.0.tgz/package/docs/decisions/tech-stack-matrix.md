# Technology Stack Decision Matrix

**Version**: 0.1.0  
**Status**: Draft - Awaiting Operator Decision  
**Last Updated**: 2026-05-04  
**Context**: Rust toolchain unavailable, need to choose implementation language

## Decision Context

The original plan specified Rust as the implementation language. However, the Rust toolchain is not installed on the development system, and operator chose to defer Rust implementation (blocker #28, option C). This document provides a structured decision framework for selecting an alternative technology stack.

## Evaluation Criteria

| Criterion | Weight | Description |
|-----------|--------|-------------|
| **Performance** | High | Throughput (msgs/sec), latency (p50/p99), memory efficiency |
| **Ecosystem Maturity** | High | Libraries for distributed systems, HTTP, serialization, testing |
| **Team Expertise** | High | Learning curve, existing knowledge, hiring pool |
| **Deployment Simplicity** | Medium | Binary size, dependencies, containerization, cloud-native tooling |
| **Library Availability** | High | Redis clients, HTTP frameworks, observability (tracing/metrics) |
| **Integration with React** | Medium | HTTP API for admin UI, WebSocket support, ease of deployment together |
| **Multi-Node Support** | High | Maturity of distributed coordination libraries |

## Language Options Analysis

---

### Option 1: Rust

**Overview**: Systems programming language with memory safety and zero-cost abstractions.

**Pros**:
- **Performance**: Best-in-class for throughput and latency (sub-millisecond p99)
- **Memory safety**: No GC pauses, prevents memory leaks and data races
- **Binary deployment**: Single static binary, no runtime dependencies
- **Growing ecosystem**: Tokio (async runtime), serde (serialization), redis-rs, axum/actix-web (HTTP)

**Cons**:
- **Toolchain unavailable**: Blocks immediate development (blocker #28)
- **Learning curve**: Steep, especially for ownership/lifetimes (2-6 months to productivity)
- **Slower iteration**: Compilation times longer than interpreted languages
- **Limited distributed libraries**: Fewer mature options for Raft, gossip, etc. vs. Go

**Evaluation**:

| Criterion | Score (1-5) | Notes |
|-----------|-------------|-------|
| Performance | 5 | Best-in-class |
| Ecosystem Maturity | 3 | Growing, but gaps in distributed systems |
| Team Expertise | 1 | Steep learning curve, toolchain unavailable |
| Deployment Simplicity | 5 | Single static binary |
| Library Availability | 3 | Redis, HTTP good; distributed tooling sparse |
| React Integration | 4 | HTTP API straightforward, WebSocket via tokio-tungstenite |
| Multi-Node Support | 2 | Few mature consensus/replication libraries |
| **Total (weighted)** | **2.9** | Blocked by toolchain + learning curve |

**Recommendation**: **Defer** until toolchain is available and team has Rust expertise.

---

### Option 2: Go

**Overview**: Statically-typed language designed for concurrency and cloud infrastructure.

**Pros**:
- **Excellent concurrency**: Goroutines and channels make multi-threading simple
- **Rich distributed ecosystem**: etcd, Consul, NATS, Raft implementations (e.g., hashicorp/raft)
- **Fast compilation**: Sub-second builds for moderate projects
- **Strong HTTP support**: net/http stdlib, gin/echo frameworks, gRPC native
- **Cloud-native tooling**: Kubernetes operators, Docker, observability (OpenTelemetry)
- **Moderate learning curve**: 1-2 weeks to productivity for experienced developers

**Cons**:
- **GC pauses**: Minor latency spikes (typically <1ms, but can be 10-50ms under load)
- **Verbose error handling**: Manual `if err != nil` checks
- **No generics** (until Go 1.18+): Some code duplication for type-safe collections

**Evaluation**:

| Criterion | Score (1-5) | Notes |
|-----------|-------------|-------|
| Performance | 4 | Good throughput, occasional GC pauses |
| Ecosystem Maturity | 5 | Excellent distributed systems libraries |
| Team Expertise | 4 | Moderate learning curve, popular in backend |
| Deployment Simplicity | 5 | Single static binary |
| Library Availability | 5 | Redis (go-redis), HTTP (stdlib/gin), Raft (hashicorp) |
| React Integration | 5 | HTTP/WebSocket trivial, CORS built-in |
| Multi-Node Support | 5 | Mature Raft, gossip (memberlist), etcd client |
| **Total (weighted)** | **4.7** | Strong all-around choice |

**Recommendation**: **Strong candidate** — best balance of performance, ecosystem, and team productivity.

---

### Option 3: Node.js (TypeScript)

**Overview**: JavaScript runtime with event-driven, non-blocking I/O.

**Pros**:
- **React integration**: Same language for frontend + backend, shared types via TypeScript
- **Rich npm ecosystem**: Millions of packages, mature HTTP (Express, Fastify), Redis (ioredis)
- **Fast iteration**: No compilation step (or fast TS compilation), hot reload
- **WebSocket native**: Built-in for admin UI real-time updates
- **Team familiarity**: JavaScript widely known, lower hiring barrier

**Cons**:
- **Single-threaded**: Must use worker threads or clustering for multi-core utilization
- **GC pressure**: V8 GC can cause latency spikes under high load
- **Dependency management**: node_modules can be large, supply-chain security concerns
- **Type safety**: TypeScript helps, but still weaker than Rust/Go
- **Performance ceiling**: 10-50k msgs/sec per node (vs. 100k+ for Go/Rust)

**Evaluation**:

| Criterion | Score (1-5) | Notes |
|-----------|-------------|-------|
| Performance | 3 | Good for I/O, limited by single-threaded event loop |
| Ecosystem Maturity | 4 | Rich npm ecosystem, some distributed libs (e.g., redis-cluster) |
| Team Expertise | 5 | JavaScript ubiquitous, TypeScript adoption high |
| Deployment Simplicity | 3 | node_modules large, Docker multi-stage helps |
| Library Availability | 4 | ioredis, express/fastify, bull (queue lib), prom-client |
| React Integration | 5 | Perfect — same language, shared types |
| Multi-Node Support | 3 | Redis clustering good, limited Raft/gossip options |
| **Total (weighted)** | **3.9** | Best for React integration, acceptable performance |

**Recommendation**: **Good fit** if React admin UI is a priority and throughput < 50k msgs/sec per node is acceptable.

---

### Option 4: Python

**Overview**: High-level interpreted language with rich data ecosystem.

**Pros**:
- **Simple syntax**: Fastest time-to-prototype, minimal boilerplate
- **Rich ecosystem**: Redis (redis-py), HTTP (FastAPI, Flask), async support (asyncio)
- **Observability**: Excellent OpenTelemetry support, mature logging libraries

**Cons**:
- **Performance**: Slowest of the four options (10-20k msgs/sec per node)
- **GIL limitation**: Single-threaded CPU-bound performance bottleneck
- **Deployment complexity**: Must package Python runtime + dependencies (Docker recommended)
- **Type safety**: Optional typing (mypy) weaker than TypeScript, Go, Rust

**Evaluation**:

| Criterion | Score (1-5) | Notes |
|-----------|-------------|-------|
| Performance | 2 | Limited by GIL, acceptable for low-throughput use cases |
| Ecosystem Maturity | 4 | Good web frameworks, limited distributed systems libs |
| Team Expertise | 4 | Widely known, fast prototyping |
| Deployment Simplicity | 2 | Requires packaging runtime, dependency conflicts common |
| Library Availability | 4 | redis-py, FastAPI, good async support |
| React Integration | 4 | HTTP API straightforward, WebSocket via FastAPI |
| Multi-Node Support | 2 | Limited mature options (consul-py, etcd3 client basic) |
| **Total (weighted)** | **3.1** | Best for prototyping, not production-scale |

**Recommendation**: **Defer** — performance and deployment complexity outweigh prototyping speed.

---

## Decision Matrix Summary

| Language | Performance | Ecosystem | Team | Deployment | Libraries | React | Multi-Node | **Total** |
|----------|-------------|-----------|------|------------|-----------|-------|------------|-----------|
| **Go** | 4 | 5 | 4 | 5 | 5 | 5 | 5 | **4.7** |
| **Node.js** | 3 | 4 | 5 | 3 | 4 | 5 | 3 | **3.9** |
| **Python** | 2 | 4 | 4 | 2 | 4 | 4 | 2 | **3.1** |
| **Rust** | 5 | 3 | 1 | 5 | 3 | 4 | 2 | **2.9** |

(Scores: 1 = poor, 3 = acceptable, 5 = excellent)

---

## Runtime and Deployment Options

### Standalone Binary (Go, Rust)

**Pros**: Single file deployment, no runtime dependencies, fast startup  
**Cons**: Must recompile for updates (mitigated by CI/CD)  
**Use case**: Kubernetes pods, AWS Lambda (custom runtime), on-premises

### Containerized (All languages)

**Pros**: Reproducible builds, isolated dependencies, orchestration-friendly  
**Cons**: Image size (Node.js/Python larger than Go/Rust), registry management  
**Use case**: Docker Compose, Kubernetes, ECS

### Embedded Library (Go, Rust, Node.js)

**Pros**: Can be imported by other applications, in-process queue  
**Cons**: Version conflicts, less isolation  
**Use case**: Monolith integration, testing, local development

---

## Recommendation

### Primary Recommendation: **Go**

**Rationale**:
1. **Best all-around score** (4.7/5): Strong performance, mature ecosystem, reasonable learning curve
2. **Multi-node strength**: Excellent distributed systems libraries (Raft, etcd client, Redis Cluster)
3. **Deployment simplicity**: Single static binary, Docker-friendly, Kubernetes-native
4. **Team productivity**: Moderate learning curve (1-2 weeks to productivity)
5. **Future-proof**: Widely adopted for cloud infrastructure (Docker, Kubernetes, Terraform all in Go)

**Implementation path**:
- Phase 1: Core queue in Go (send, receive, delete, visibility timeout)
- Phase 2: Multi-node via Redis (per architecture doc)
- Phase 3: HTTP API (stdlib net/http or gin framework)
- Phase 4: React admin UI (separate frontend, consumes HTTP API)

---

### Alternative Recommendation: **Node.js (TypeScript)**

**Rationale**:
1. **React integration**: Same language for frontend + backend simplifies development
2. **Team familiarity**: JavaScript ubiquitous, lowers hiring barrier
3. **Acceptable performance**: 10-50k msgs/sec sufficient for most use cases
4. **Rich ecosystem**: npm provides mature HTTP, Redis, WebSocket libraries

**When to choose Node.js over Go**:
- React admin UI is the primary deliverable (vs. queue library)
- Team has strong JavaScript expertise but limited systems programming experience
- Throughput requirements < 50k msgs/sec per node

**Implementation path**:
- Phase 1: Core queue in TypeScript (classes for Queue, Message, visibility logic)
- Phase 2: Multi-node via Redis (ioredis client)
- Phase 3: HTTP API (Fastify or Express)
- Phase 4: React admin UI (shared types via TypeScript, monorepo with Nx or Turborepo)

---

## Addressing the Rust Blocker

The original plan specified Rust. Here's how to pivot:

**Option A: Install Rust and proceed with original plan**
- **Pro**: Honors original intent, best long-term performance
- **Con**: Requires operator approval to install toolchain, steep learning curve blocks short-term progress
- **Timeline**: 1-2 weeks to set up + 2-6 months to Rust proficiency

**Option B: Implement in Go now, rewrite in Rust later**
- **Pro**: Unblocks development immediately, Go is easy to learn, Rust remains future option
- **Con**: Rewrite cost if Rust becomes priority
- **Timeline**: 2-4 weeks to Go MVP, rewrite TBD

**Option C: Implement in Node.js, optimize critical paths in Rust modules**
- **Pro**: Leverages JavaScript familiarity, can use Rust via N-API for hot paths (e.g., message serialization)
- **Con**: Mixed-language complexity, limited Rust toolchain still a blocker for modules
- **Timeline**: 3-5 weeks to Node.js MVP, Rust modules TBD

**Recommended approach**: **Option B (Go now, Rust later if needed)**
- Go provides 80% of Rust's performance with 20% of the learning curve
- If performance becomes a bottleneck, profile and optimize hot paths (or rewrite in Rust)
- Avoids blocking development on toolchain installation and team ramp-up

---

## Next Steps

1. **Operator decision required**: Choose Go or Node.js based on team expertise and React admin UI priority
2. **If Go chosen**:
   - Install Go toolchain (`brew install go` or download from golang.org)
   - Initialize Go module: `go mod init github.com/connorhoehnslalom/message-queue`
   - Bootstrap project structure (similar to Cargo.toml equivalent)
3. **If Node.js chosen**:
   - Initialize npm project: `npm init -y`
   - Add TypeScript: `npm install -D typescript @types/node`
   - Configure tsconfig.json for strict mode
4. **Create follow-up implementation tasks** for chosen stack

---

## References

- [Go vs Rust for distributed systems](https://kristoff.it/blog/why-go-and-not-rust/)
- [Node.js performance limits](https://nodejs.org/en/docs/guides/dont-block-the-event-loop/)
- [Redis client comparison](https://redis.io/docs/clients/)
- [Message queue benchmarks](https://bravenewgeek.com/benchmarking-message-queue-latency/)
