# Multi-Node Coordination Architecture

**Version**: 0.1.0  
**Status**: Historical reference (post-Raft retirement)  
**Last Updated**: 2026-05-04

> **Status (2026-05-28): Historical reference.** The Raft-based multi-node surface this spec
> analyzes was retired in commit `96de34b` (`.planning/STATE.md` Phase 2). The service is
> currently single-node-only; `distributed-core` supplies in-memory queue primitives only.
> This spec is preserved as the design analysis to revisit if/when multi-node coordination
> is restarted (see `.planning/ROADMAP.md` Phase 3 for hypothetical durability paths via
> `managed-nosql-store`). Recommendations in this doc are NOT a live roadmap — for current
> architecture, read `STATE.md` and `ROADMAP.md` first.

## Overview

This document analyzes requirements and architecture options for enabling the message queue to operate across multiple nodes. The goal: messages enqueued on one node become visible to consumers on any node, with no single point of failure.

## Requirements

### Functional Requirements

1. **Cross-node visibility**: Message sent to node A must be receivable by consumer on node B
2. **Global ordering (FIFO queues)**: Message groups maintain strict FIFO across nodes
3. **Visibility timeout coordination**: Message invisible on all nodes during processing
4. **DLQ routing**: Consistent receive count tracking across nodes for DLQ decisions
5. **Queue metadata sync**: Configuration, attributes, message counts replicated
6. **Node failure tolerance**: System remains available if subset of nodes fail

### Non-Functional Requirements

1. **Consistency**: At-least-once delivery for standard queues, exactly-once for FIFO
2. **Latency**: Cross-node send-to-receive latency < 100ms (p99)
3. **Throughput**: System should scale horizontally (add nodes → increase capacity)
4. **Availability**: No single point of failure, graceful degradation under partition
5. **Operational simplicity**: Minimize external dependencies, reduce ops complexity

## State That Must Be Replicated

### Per-Message State

- Message metadata (ID, body, attributes, timestamps)
- Visibility deadline (which node holds the lock, when it expires)
- Receive count (for DLQ routing decision)
- Current location (which node(s) store the message)

### Per-Queue State

- Queue configuration (visibility timeout, retention, DLQ policy)
- Approximate message counts (visible, in-flight, delayed)
- FIFO sequence numbers and deduplication cache

### Per-Node State

- Node health (alive, partitioned, draining)
- Load metrics (messages/sec, queue depth per node)

## Consistency Guarantees Analysis

### Standard Queues (At-Least-Once)

- **Eventual consistency acceptable**: Duplicate delivery is allowed
- **Visibility conflicts tolerable**: Rare double-delivery under partition
- **Bias toward availability**: Better to over-deliver than lose messages

### FIFO Queues (Exactly-Once)

- **Strong consistency required**: No duplicates, strict ordering within group
- **Visibility must be exclusive**: Only one node can deliver a message
- **Partition handling**: FIFO groups on partitioned side become unavailable (CAP theorem)

## Architecture Options

---

### Option A: Distributed-Core Library (Original Plan)

**Description**: Use the `distributed-core` library (assumed to be a CRDT-based or Raft-based replication layer) as a shared state backend.

**Architecture**:
```
┌─────────┐     ┌─────────┐     ┌─────────┐
│ Node A  │────▶│DistCore │◀────│ Node B  │
│ + Queue │     │ Cluster │     │ + Queue │
└─────────┘     └─────────┘     └─────────┘
      ▲              │              ▲
      └──────────────┴──────────────┘
           Replicated State
```

**Pros**:
- Consistent with original README plan
- If `distributed-core` is well-tested, leverages existing work
- Potentially supports both standard and FIFO queues

**Cons**:
- **Dependency unknown**: No evidence `distributed-core` exists or is production-ready
- **Coupling risk**: If `distributed-core` is immature, blocks entire project
- **Learning curve**: Team must learn `distributed-core` API and semantics
- **Operational complexity**: Additional component to deploy, monitor, debug

**Consistency**: Depends on `distributed-core` implementation (Raft → strong, CRDT → eventual)

**Latency**: 50-100ms cross-node (one network hop + consensus)

**Recommendation**: Only if `distributed-core` is proven and documented.

---

### Option B: Redis as Coordination Backend

**Description**: Use Redis (or KeyDB, Dragonfly) as a shared state store for queue metadata and message index. Nodes are stateless queue processors.

**Architecture**:
```
┌─────────┐     ┌─────────┐
│ Node A  │────▶│  Redis  │◀────│ Node B  │
│ (stateless) │ │ Cluster │     │ (stateless) │
└─────────┘     └─────────┘     └─────────┘
                     ▲
                Message store + index
```

**Pros**:
- **Mature ecosystem**: Redis is battle-tested, widely deployed
- **Strong primitives**: Lua scripting for atomic operations, Pub/Sub for notifications
- **Operational familiarity**: Most teams already run Redis
- **Horizontal scaling**: Redis Cluster for multi-TB datasets
- **Simple failure model**: Node failures don't affect state (stateless processors)

**Cons**:
- **Single point of failure**: Redis becomes critical dependency (mitigate with Redis Sentinel or Cluster)
- **Latency overhead**: Every operation is a network round-trip to Redis
- **Memory pressure**: All message metadata must fit in Redis memory
- **Not a queue natively**: Must build queue semantics on top of Redis primitives

**Consistency**: Strong (single Redis instance) or eventual (Redis Cluster)

**Latency**: 1-5ms to Redis (local network), 10-50ms cross-region

**Implementation sketch**:
- Queue: Redis LIST (LPUSH/RPOP) or Sorted Set (by timestamp)
- Visibility: Redis key with TTL (expire = timeout)
- FIFO groups: Redis LIST per group + lock per group
- DLQ routing: HINCRBY for receive count, Lua script for conditional move

**Recommendation**: Strong choice if team is comfortable with Redis ops and latency is acceptable.

---

### Option C: etcd or Consul for Distributed State

**Description**: Use etcd or Consul as a strongly-consistent CP (Consistency + Partition-tolerance) store for queue metadata. Messages stored locally or in object storage.

**Architecture**:
```
┌─────────┐     ┌─────────┐     ┌─────────┐
│ Node A  │────▶│  etcd   │◀────│ Node B  │
│ + local │     │ Cluster │     │ + local │
│ storage │     │ (Raft)  │     │ storage │
└─────────┘     └─────────┘     └─────────┘
```

**Pros**:
- **Strong consistency**: Raft consensus guarantees linearizability
- **Leader election**: Built-in for FIFO message group locks
- **Watch API**: Real-time notifications on state changes
- **Production-grade**: etcd powers Kubernetes, Consul used by HashiCorp ecosystem

**Cons**:
- **Not designed for high-throughput**: etcd write limit ~10k ops/sec cluster-wide
- **Small value size**: etcd recommends <1.5MB per key (messages must be stored elsewhere)
- **Operational complexity**: Raft cluster requires careful tuning, 3-5 nodes minimum
- **Latency**: 10-50ms for write operations (Raft quorum)

**Consistency**: Strong (linearizable reads/writes)

**Latency**: 10-50ms for writes, 1-10ms for local reads

**Implementation sketch**:
- Queue metadata: etcd key per queue (config, counts)
- Message index: etcd directory per queue, keys = message IDs
- Message bodies: Local disk or S3 (etcd stores pointer)
- FIFO group lock: etcd lease per message group
- Visibility timeout: etcd lease per in-flight message

**Recommendation**: Good for FIFO queues needing strong consistency, but throughput ceiling may be limiting.

---

### Option D: Custom Gossip Protocol (e.g., SWIM, Memberlist)

**Description**: Nodes form a peer-to-peer mesh and replicate queue state via gossip. No central coordinator.

**Architecture**:
```
┌─────────┐────┬────┌─────────┐
│ Node A  │    │    │ Node B  │
│ + Queue │◀───┼───▶│ + Queue │
└─────────┘    │    └─────────┘
         ▲     │     ▲
         │     │     │
         └─────┴─────┘
          Gossip mesh
```

**Pros**:
- **No external dependency**: Self-contained, zero ops overhead
- **Partition tolerance**: AP system, remains available under network split
- **Scalability**: Gossip protocols scale to hundreds of nodes
- **Low latency**: Direct peer-to-peer communication

**Cons**:
- **Eventual consistency only**: Not suitable for FIFO queues without additional coordination
- **Complexity**: Must implement gossip protocol, conflict resolution, and anti-entropy
- **Testing difficulty**: Distributed systems bugs are hard to reproduce and fix
- **Reinventing wheel**: Mature gossip libraries exist, but integrating them is nontrivial

**Consistency**: Eventual (CRDT-style merge or last-write-wins)

**Latency**: 5-20ms direct node-to-node

**Implementation sketch**:
- Use HashiCorp Memberlist or similar library for membership
- CRDT counters for message counts
- Vector clocks or Lamport timestamps for causal ordering
- Hinted handoff for partitioned nodes

**Recommendation**: Only if team has distributed systems expertise and wants zero external dependencies. High implementation risk.

---

## Comparison Matrix

| Criteria | A: Distributed-Core | B: Redis | C: etcd/Consul | D: Gossip |
|----------|---------------------|----------|----------------|-----------|
| **Consistency** | Unknown | Strong (single) / Eventual (cluster) | Strong (Raft) | Eventual |
| **Latency (p99)** | 50-100ms | 10-50ms | 10-50ms | 5-20ms |
| **Throughput** | Unknown | 100k+ ops/sec | 10k ops/sec | 50k+ ops/sec |
| **Ops Complexity** | Medium | Low | Medium-High | High |
| **External Deps** | 1 (distributed-core) | 1 (Redis) | 1 (etcd/Consul) | 0 |
| **FIFO Support** | Unknown | Good (Lua locks) | Excellent (Raft) | Poor (eventual) |
| **Standard Queue** | Unknown | Excellent | Good | Excellent |
| **Maturity** | Unknown | Proven | Proven | Experimental |
| **Team Familiarity** | Low | High (assumed) | Medium | Low |
| **Implementation LOC** | 500-1000 | 800-1500 | 1000-2000 | 3000-5000 |

---

## Conflict Resolution Strategies

### Standard Queues (At-Least-Once)

- **Duplicate delivery acceptable**: No conflict resolution needed
- **Visibility conflicts**: If two nodes deliver same message, both consumers proceed (idempotent consumers assumed)
- **Receive count**: CRDTs (grow-only counter) or last-write-wins with vector clocks

### FIFO Queues (Exactly-Once)

- **Lock-based**: Use distributed lock (Redis SETNX, etcd lease, Raft leader) for message group
- **Partition handling**: Unavailable-over-inconsistent (reject operations on partitioned side)
- **Sequence number coordination**: Single writer per message group (enforced by lock)

---

## Recommended Architecture

**For MVP / Initial Implementation**: **Option B (Redis)**

**Rationale**:
1. **Lowest risk**: Redis is mature, well-understood, and widely deployed.
2. **Balanced trade-offs**: Good consistency, acceptable latency, high throughput.
3. **Operational simplicity**: Most teams already run Redis; monitoring and tooling are standard.
4. **Incremental path**: Start with single Redis instance, scale to Redis Cluster later.
5. **Escape hatch**: If Redis becomes a bottleneck, can migrate to etcd (FIFO) or gossip (standard queues) later.

**Rationale against others**:
- **Option A (Distributed-Core)**: Unknown maturity; blocks project if library is incomplete.
- **Option C (etcd)**: Throughput ceiling (10k ops/sec) may limit scale; best reserved for FIFO-only systems.
- **Option D (Gossip)**: Too high implementation risk for MVP; revisit if zero-dependency is critical.

**Phase 1 Architecture** (Redis-backed):
```
┌──────────────┐       ┌──────────────┐
│   Node A     │       │   Node B     │
│  (stateless) │       │  (stateless) │
│              │       │              │
│ - HTTP API   │       │ - HTTP API   │
│ - Queue Ops  │       │ - Queue Ops  │
└──────┬───────┘       └──────┬───────┘
       │                      │
       └──────────┬───────────┘
                  │
          ┌───────▼────────┐
          │  Redis         │
          │  (single inst) │
          │                │
          │ - Message idx  │
          │ - Visibility   │
          │ - Config       │
          └────────────────┘
```

**Phase 2** (if needed): Redis Cluster for horizontal scale, or etcd for FIFO-only deployments.

---

## Implementation Notes

### Redis-Specific Design

**Queue representation**:
- Standard queue: Redis LIST (`queue:{name}:messages`)
- FIFO queue: Redis Sorted Set per message group (`queue:{name}:group:{id}`, score = sequence number)

**Visibility timeout**:
- In-flight set: Redis Sorted Set (`queue:{name}:inflight`, score = expiry timestamp)
- Background job: Periodically scan for expired entries, move back to queue

**DLQ routing**:
- Receive count: Redis Hash (`message:{id}:metadata`, field `receive_count`)
- Atomic check-and-move: Lua script
```lua
local count = redis.call('HINCRBY', KEYS[1], 'receive_count', 1)
if count > tonumber(ARGV[1]) then
  redis.call('LPUSH', KEYS[2], ARGV[2])  -- DLQ
  return 'dlq'
else
  redis.call('ZADD', KEYS[3], ARGV[3], ARGV[2])  -- inflight
  return 'ok'
end
```

**FIFO message group lock**:
- Redis key: `queue:{name}:group:{id}:lock` with TTL
- Set via `SET ... NX EX {timeout}`, release via `DEL`

---

## Future Considerations

1. **Hybrid approach**: Redis for standard queues, etcd for FIFO queues (different consistency needs)
2. **Message storage tiering**: Recent messages in Redis, older messages in S3 (reduce memory pressure)
3. **Regional replication**: Multi-region Redis with async replication for DR
4. **Observability**: Distributed tracing across nodes (OpenTelemetry spans for send → receive path)

---

## Decision Log

| Date | Decision | Rationale |
|------|----------|-----------|
| 2026-05-04 | Recommend Redis (Option B) for MVP | Lowest risk, mature tooling, team familiarity |
| TBD | Revisit if throughput > 50k ops/sec | Consider etcd (FIFO) or gossip (standard) |
| TBD | Evaluate distributed-core if documented | If library proves mature, reconsider Option A |
