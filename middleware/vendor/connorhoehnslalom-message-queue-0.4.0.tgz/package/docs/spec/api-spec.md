# Message Queue API Specification

**Version**: 0.1.0  
**Status**: Draft  
**Last Updated**: 2026-05-04

## Overview

This document specifies a language-agnostic API for a message queue system with SQS-compliant semantics. The API supports:
- Standard queue operations (send, receive, delete)
- Visibility timeout for exclusive message processing
- Dead-letter queues for poison message handling
- FIFO ordering with message groups and deduplication
- Multi-node coordination for distributed deployments

## Core Concepts

### Message

A unit of data transmitted through the queue.

**Structure**:
```
Message {
  message_id: String          // Unique identifier (UUID v4)
  body: String                // Message payload (UTF-8 or base64-encoded binary)
  attributes: Map<String, String>  // User-defined key-value metadata
  system_attributes: Map<String, String>  // System-managed metadata
  md5_of_body: String         // MD5 hash for integrity verification
  receipt_handle: String      // Opaque token for delete/visibility operations
  
  // Timestamps (ISO 8601 UTC)
  sent_timestamp: String      
  first_receive_timestamp: String?
  approximate_receive_count: Integer
  
  // FIFO-specific (optional)
  message_group_id: String?
  message_deduplication_id: String?
  sequence_number: String?
}
```

**System Attributes** (set by queue, read-only):
- `ApproximateReceiveCount`: Number of times message has been received
- `SentTimestamp`: Unix epoch milliseconds when message was sent
- `SenderId`: Identity of sender (implementation-specific)
- `ApproximateFirstReceiveTimestamp`: Unix epoch ms of first receive

### Queue Configuration

```
QueueConfiguration {
  queue_name: String                    // Alphanumeric + hyphens, max 80 chars
  visibility_timeout_seconds: Integer   // Default: 30, range: 0-43200 (12 hours)
  message_retention_period_seconds: Integer  // Default: 345600 (4 days), range: 60-1209600 (14 days)
  max_message_size_bytes: Integer       // Default: 262144 (256 KB), max: 262144
  receive_wait_time_seconds: Integer    // Long polling, default: 0, range: 0-20
  delay_seconds: Integer                // Delivery delay, default: 0, range: 0-900 (15 min)
  
  // Dead-letter queue
  redrive_policy: RedrivePolicy?
  
  // FIFO-specific
  fifo_queue: Boolean                   // Default: false
  content_based_deduplication: Boolean  // Default: false (only for FIFO)
  deduplication_scope: String           // "queue" | "messageGroup" (FIFO only)
  fifo_throughput_limit: String         // "perQueue" | "perMessageGroupId" (FIFO only)
}

RedrivePolicy {
  dead_letter_target_arn: String        // Queue identifier for DLQ
  max_receive_count: Integer            // Threshold before DLQ routing, range: 1-1000
}
```

## API Operations

### 1. SendMessage

Delivers a message to the specified queue.

**Request**:
```
SendMessageRequest {
  queue_name: String                    // REQUIRED
  message_body: String                  // REQUIRED, max size per queue config
  message_attributes: Map<String, MessageAttributeValue>?
  delay_seconds: Integer?               // Override queue default, range: 0-900
  
  // FIFO-specific
  message_group_id: String?             // REQUIRED for FIFO queues
  message_deduplication_id: String?     // REQUIRED if content_based_deduplication=false
}

MessageAttributeValue {
  string_value: String?
  binary_value: Bytes?
  data_type: String                     // "String" | "Number" | "Binary"
}
```

**Response**:
```
SendMessageResponse {
  message_id: String
  md5_of_message_body: String
  md5_of_message_attributes: String?
  sequence_number: String?              // FIFO only
}
```

**Errors**:
- `InvalidMessageBody`: Body exceeds size limit or contains invalid characters
- `InvalidParameterValue`: Invalid attribute or configuration value
- `QueueDoesNotExist`: Specified queue not found
- `DuplicateMessage`: FIFO deduplication rejected (within 5-minute window)

---

### 2. ReceiveMessage

Retrieves one or more messages from the queue. Messages become invisible to other consumers for the visibility timeout duration.

**Request**:
```
ReceiveMessageRequest {
  queue_name: String                    // REQUIRED
  max_number_of_messages: Integer?      // Default: 1, range: 1-10
  visibility_timeout: Integer?          // Override queue default, range: 0-43200
  wait_time_seconds: Integer?           // Long polling, range: 0-20
  attribute_names: List<String>?        // System attributes to include ("All" | specific names)
  message_attribute_names: List<String>?  // User attributes to include ("All" | specific names)
  
  // FIFO-specific
  receive_request_attempt_id: String?   // Idempotency token for FIFO
}
```

**Response**:
```
ReceiveMessageResponse {
  messages: List<Message>               // Empty if no messages available
}
```

**Behavior**:
- **Standard queues**: Approximately FIFO ordering, at-least-once delivery
- **FIFO queues**: Strict FIFO within message group, exactly-once delivery
- **Long polling**: If `wait_time_seconds > 0`, blocks up to N seconds for messages to arrive
- **Visibility timeout**: Received messages invisible until timeout expires or explicitly deleted

**Errors**:
- `QueueDoesNotExist`: Specified queue not found
- `InvalidParameterValue`: Invalid timeout or message count

---

### 3. DeleteMessage

Removes a message from the queue. Must be called after successful processing to prevent redelivery.

**Request**:
```
DeleteMessageRequest {
  queue_name: String                    // REQUIRED
  receipt_handle: String                // REQUIRED, from ReceiveMessage response
}
```

**Response**:
```
DeleteMessageResponse {
  success: Boolean
}
```

**Errors**:
- `InvalidReceiptHandle`: Receipt handle invalid, expired, or already used
- `QueueDoesNotExist`: Specified queue not found

---

### 4. ChangeMessageVisibility

Extends or shortens the visibility timeout of a received message.

**Request**:
```
ChangeMessageVisibilityRequest {
  queue_name: String                    // REQUIRED
  receipt_handle: String                // REQUIRED
  visibility_timeout: Integer           // REQUIRED, range: 0-43200
}
```

**Response**:
```
ChangeMessageVisibilityResponse {
  success: Boolean
}
```

**Use cases**:
- Extend timeout if processing takes longer than expected
- Set to 0 to make message immediately visible for retry

**Errors**:
- `InvalidReceiptHandle`: Receipt handle invalid or expired
- `QueueDoesNotExist`: Specified queue not found
- `InvalidParameterValue`: Visibility timeout out of range

---

### 5. CreateQueue

Creates a new queue with specified configuration.

**Request**:
```
CreateQueueRequest {
  queue_name: String                    // REQUIRED, unique within account/namespace
  configuration: QueueConfiguration
}
```

**Response**:
```
CreateQueueResponse {
  queue_url: String                     // Identifier for future operations
  queue_arn: String                     // Unique resource name
}
```

**Errors**:
- `QueueAlreadyExists`: Queue with this name exists
- `InvalidParameterValue`: Invalid configuration

---

### 6. DeleteQueue

Permanently deletes a queue and all messages within it.

**Request**:
```
DeleteQueueRequest {
  queue_name: String                    // REQUIRED
}
```

**Response**:
```
DeleteQueueResponse {
  success: Boolean
}
```

**Errors**:
- `QueueDoesNotExist`: Queue not found

---

### 7. GetQueueAttributes

Retrieves queue configuration and statistics.

**Request**:
```
GetQueueAttributesRequest {
  queue_name: String                    // REQUIRED
  attribute_names: List<String>?        // "All" or specific attributes
}
```

**Response**:
```
GetQueueAttributesResponse {
  attributes: Map<String, String>
}
```

**Available Attributes**:
- `ApproximateNumberOfMessages`: Visible messages count
- `ApproximateNumberOfMessagesNotVisible`: In-flight messages count
- `ApproximateNumberOfMessagesDelayed`: Delayed messages count
- `CreatedTimestamp`: Queue creation time (Unix epoch seconds)
- `LastModifiedTimestamp`: Last configuration change
- `QueueArn`: Queue ARN
- All `QueueConfiguration` fields

---

### 8. PurgeQueue

Deletes all messages in the queue. Messages in-flight are not affected.

**Request**:
```
PurgeQueueRequest {
  queue_name: String                    // REQUIRED
}
```

**Response**:
```
PurgeQueueResponse {
  success: Boolean
}
```

**Errors**:
- `QueueDoesNotExist`: Queue not found
- `PurgeQueueInProgress`: Another purge operation is active (60-second cooldown)

---

## FIFO Queue Specifics

### Message Group ID

Messages with the same `message_group_id` are:
- Strictly ordered (sent order = receive order)
- Processed sequentially (only one message per group visible at a time)

Messages with different group IDs can be processed in parallel.

### Message Deduplication

Two mechanisms:
1. **Content-based**: MD5 hash of message body used as deduplication ID
2. **Explicit**: Caller provides `message_deduplication_id`

Duplicate sends within a 5-minute window are rejected with `DuplicateMessage` error.

### Sequence Numbers

Each message receives a unique, increasing `sequence_number` within its message group. Gaps in sequence indicate deleted messages.

---

## Dead-Letter Queue (DLQ)

When a message's `approximate_receive_count` exceeds `redrive_policy.max_receive_count`:
- Message is automatically moved to the DLQ
- Original message metadata is preserved
- `approximate_receive_count` is reset to 0 in the DLQ

DLQs are regular queues and can be read/deleted normally.

---

## Error Handling

All errors follow this structure:

```
ErrorResponse {
  error_code: String
  error_message: String
  request_id: String?
}
```

**Common Error Codes**:
- `InvalidParameterValue`: Parameter out of range or invalid format
- `QueueDoesNotExist`: Queue not found
- `InvalidReceiptHandle`: Receipt handle invalid, expired, or reused
- `MessageTooLarge`: Message exceeds size limit
- `DuplicateMessage`: FIFO deduplication rejected
- `ThrottlingException`: Rate limit exceeded

**HTTP Status Codes**:
- `200`: Success
- `400`: Client error (invalid parameters)
- `404`: Queue not found
- `409`: Conflict (duplicate, purge in progress)
- `429`: Rate limit exceeded
- `500`: Server error
- `503`: Service unavailable

---

## Limits and Quotas

| Resource | Limit | Notes |
|----------|-------|-------|
| Message size | 256 KB | Configurable per queue, hard max 256 KB |
| Message retention | 14 days | Configurable, min 1 minute |
| Visibility timeout | 12 hours | Configurable, 0-43200 seconds |
| Messages per ReceiveMessage | 10 | Max batch size |
| Queue name length | 80 chars | Alphanumeric + hyphens only |
| FIFO throughput | 300 TPS | Per message group (configurable) |
| Standard throughput | Unlimited | Best-effort |
| Deduplication window | 5 minutes | FIFO only |
| Attribute name length | 256 chars | User attributes |
| Attribute value length | 256 KB | User attributes |

---

## Notes for Implementers

1. **Receipt handles** must be cryptographically secure, time-limited tokens. Do not use sequential IDs.
2. **Visibility timeout** requires background job or lazy evaluation to restore message visibility.
3. **Message ordering** in standard queues is best-effort; FIFO queues must guarantee strict ordering.
4. **At-least-once delivery** in standard queues means duplicates are possible; consumers must be idempotent.
5. **Long polling** reduces empty receives and API costs; prefer it over short polling.
6. **DLQ routing** should preserve original message timestamps and attributes for debugging.
7. **Content-based deduplication** is cheaper than requiring explicit IDs, but less flexible.

---

## Future Considerations

- **Batch operations**: SendMessageBatch, DeleteMessageBatch for efficiency
- **Server-side encryption**: At-rest encryption with KMS integration
- **Message filtering**: Receive only messages matching attribute filters
- **Priority queues**: Weighted delivery instead of strict FIFO
- **Scheduled messages**: Delivery at specific timestamp (beyond delay_seconds)
