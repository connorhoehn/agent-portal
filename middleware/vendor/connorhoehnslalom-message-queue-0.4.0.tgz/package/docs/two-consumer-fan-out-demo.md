# Two-Consumer Fan-Out Demo

Demonstrates the "MQ becomes load-bearing" scenario: a single queue with two independent consumer groups, each maintaining its own durable offset cursor.

## The pattern

```
Producer (platform-api)
        │
        ▼
  activity.recorded queue
        │  (fan-out at send time — QueueInstance copies each message
        │   into every registered group's shadow queue)
        ├──────────────────────────────────┐
        ▼                                  ▼
 platform-api-group                 orgiq-analytics-group
 cursor: 0 → N                      cursor: 0 → N
 (reads, acks, commits)             (reads, acks, commits independently)
```

Each group gets every message. Advancing one group's cursor does not affect the other.

## API call sequence

### 1. Create the queue (once, at startup)

```http
POST /api/v1/queues
{ "queue_name": "activity.recorded" }
```

### 2. Create consumer groups (once per group, before first join)

```http
POST /api/v1/consumer-groups/platform-api-group
{ "strategy": "range", "queue_name": "activity.recorded" }

POST /api/v1/consumer-groups/orgiq-analytics-group
{ "strategy": "range", "queue_name": "activity.recorded" }
```

Creating a group before any join pre-registers the shadow queue on the
`QueueInstance`. Messages sent after this point are fanned out immediately.
Messages sent before registration are NOT retroactively delivered —
register groups before the producer starts.

### 3. Join (per consumer instance, on startup)

```http
POST /api/v1/consumer-groups/platform-api-group/join
{ "consumer_id": "api-worker-1", "strategy": "range", "queue_name": "activity.recorded" }
```

Returns partition assignments. With one consumer the group holds all
partitions. With two consumers the `RangeAssignor` splits them.

### 4. Heartbeat (every ~10 s, less than `sessionTimeoutMs` = 30 s)

```http
POST /api/v1/consumer-groups/platform-api-group/heartbeat
{ "consumer_id": "api-worker-1" }
```

Response: `{ "alive": true }`. A `false` means the consumer was evicted
and must re-join.

### 5. Consume messages

```http
POST /api/v1/queues/activity.recorded/messages/receive
{
  "max_number_of_messages": 10,
  "consumer_group_id": "platform-api-group"
}
```

MQ serves from the group's shadow queue. Each message includes a
`receipt_handle` scoped to the group.

### 6. Commit offsets (after processing each batch)

```http
POST /api/v1/consumer-groups/platform-api-group/offsets
{ "partition": 0, "offset": 42 }
```

Offsets are stored in `ConsumerOffsetStore` (in-memory by default;
`DdbConsumerOffsetStore` when DDB is wired). A consumer that restarts
fetches the last committed offset and resumes from there.

### 7. Fetch committed offsets (on restart, to resume)

```http
GET /api/v1/consumer-groups/platform-api-group/offsets
```

Response: `{ "offsets": { "0": 42, "1": 17 } }`.

### 8. Leave (on graceful shutdown)

```http
POST /api/v1/consumer-groups/platform-api-group/leave
{ "consumer_id": "api-worker-1" }
```

When the last member leaves, the group's shadow queue is unregistered
and fan-out delivery stops. Re-joining recreates it.

## Failure modes covered by the integration test

| Scenario | What happens | Test verifying it |
|----------|-------------|-------------------|
| Group A never consumes | Group B still drains all N messages; A's cursor stays at 0 | `consumer group failure does not block sibling group progress` |
| Consumer crashes mid-batch | Offset not committed; on rejoin it resumes from last committed offset | `rejoining group resumes from last committed offset` |
| Both groups consume all N messages | Each group's cursor independently reaches N; message bodies are identical | `both groups receive every message; offsets are independent` |

## When MQ becomes load-bearing

A plain Redis pub/sub channel (`publish` + `subscribe`) cannot support
two independent consumers because:

- There is no per-subscriber cursor. If subscriber B is slow, fast
  messages are lost from B's perspective as soon as they leave the
  channel buffer.
- There is no offset commit / resume. After a crash, B has no way to
  replay from its last acknowledged position.
- There is no delivery guarantee. Offline subscribers miss all messages
  published while they are down.

MQ is required the moment any of these constraints applies:

1. **Two or more consumers need the same message** — e.g. `platform-api`
   processes activity for billing while `orgiq-analytics-group` aggregates
   it for dashboards. Each must receive every event exactly once.

2. **A consumer must survive restarts** — offset cursors are durable
   (DDB-backed in production), so a restarted worker picks up exactly
   where it left off.

3. **Processing is slow or bursty** — the shadow queue absorbs spikes
   without dropping messages. Redis pub/sub has no backpressure; MQ has
   configurable `backpressure_threshold` and retry semantics via the DLQ.

`activity.recorded` is the first queue in the platform that has a
realistic second consumer (`orgiq-analytics-group`). Registering
`ACTIVITY_RECORDED` as a constant in `event-catalog/src/queue-names.ts`
makes that multi-consumer topology first-class and prevents silent string
drift between producer and consumer configuration.
