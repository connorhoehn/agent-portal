# managed-nosql-store smoke test

This runbook validates that message-queue's existing `Ddb*Store.ts`
adapters work **unchanged** against `managed-nosql-store`, a
DynamoDB-compatible service, simply by repointing `DYNAMODB_ENDPOINT`.

The smoke test is **env-gated** and **does not run in CI** by default.

## Files

- `docker-compose.smoke.yml` — boots `managed-nosql-store` on `:8000`.
- `test/integration/managed-nosql-smoke.test.ts` — jest suite, skipped
  unless `MQ_MNS_SMOKE=true`.

## Env-var contract

| Var | Required | Default | Purpose |
|---|---|---|---|
| `MQ_MNS_SMOKE` | yes | _unset_ → skip | Master gate for the suite. Only `true` opts in. |
| `MQ_MNS_ENDPOINT` | no | `http://localhost:8000` | URL of the managed-nosql-store DDB-compat endpoint. |
| `MESSAGE_QUEUE_STORE` | yes | — | Must be `ddb` to activate the durable adapters. |
| `MESSAGE_QUEUE_TABLE` | yes | — | Table name to use (e.g. `mq-smoke`). Auto-created. |

When `MQ_MNS_SMOKE` is unset the test prints a one-line skip notice and
records `describe.skip` — `jest` exits green with no executed
assertions, so this file is safe to leave in the repo without
polluting CI.

## Running it

```bash
# 1. Boot the managed-nosql-store container.
docker compose -f docker-compose.smoke.yml up -d

# 2. Run the smoke suite.
MQ_MNS_SMOKE=true \
  MESSAGE_QUEUE_STORE=ddb \
  MESSAGE_QUEUE_TABLE=mq-smoke \
  MQ_MNS_ENDPOINT=http://localhost:8000 \
  npx jest test/integration/managed-nosql-smoke.test.ts

# 3. Tear down.
docker compose -f docker-compose.smoke.yml down -v
```

## What the suite asserts

1. `ListTables` against `MQ_MNS_ENDPOINT` returns successfully — proves
   the endpoint speaks the DDB wire protocol.
2. `createQueue` + `sendMessageBatch x 10` durably persists 10 rows
   through the standard `QueueService` → `DdbMessageStore` path.
3. `receiveMessage` + `deleteMessage` for all 10 returns the same 10
   bodies and removes every persisted row
   (`approximateMessageCount == 0`).
4. `DdbDlqStore.listDlqRecords` returns `[]` — no spurious DLQ
   side-effects from the happy-path lifecycle.
5. `deleteQueue` clears the queue's config row plus any residual
   payload rows.

If all of those pass, the adapters work unchanged against the
DynamoDB-compatible endpoint: no `src/` changes are needed to swap the
durable backend.

## Default-off proof

Run the suite with no env-vars set to confirm it skips cleanly:

```bash
NODE_OPTIONS='--experimental-vm-modules --max-old-space-size=1536' \
  npx jest --workerIdleMemoryLimit=512MB --maxWorkers=1 \
  test/integration/managed-nosql-smoke.test.ts
```

Expected: one skipped `describe`, zero failed assertions, `PASS`.
