# Performance Benchmarks

This directory contains performance benchmark results for the message queue service.

## Running Benchmarks

```bash
npm run benchmark
```

## Benchmark Suites

### 1. Single Message Send Throughput
- **Scenario**: Send 1000 individual messages sequentially
- **Metric**: Messages per second
- **Baseline**: > 100 msg/s

### 2. Batch Message Send Throughput
- **Scenario**: Send 100 batches of 10 messages each (1000 total)
- **Metric**: Messages per second
- **Baseline**: > 500 msg/s
- **Note**: Batching provides significant throughput improvement

### 3. Message Receive Throughput
- **Scenario**: Receive and delete 500 messages (max 10 per call)
- **Metric**: Messages per second
- **Baseline**: > 50 msg/s
- **Note**: Includes deletion time

### 4. Message Delete Throughput
- **Scenario**: Delete 500 pre-received messages individually
- **Metric**: Deletes per second
- **Baseline**: > 100 deletes/s

### 5. Concurrent Consumers
- **Scenario**: 2 concurrent consumers processing 200 messages
- **Metric**: Messages per second (total and per-consumer)
- **Baseline**: > 50 msg/s total
- **Note**: Tests parallelism and work distribution

### 6. Large Message Payload
- **Scenario**: Send 100 messages with 128KB payload each
- **Metric**: Messages/second and MB/second
- **Baseline**: > 10 msg/s
- **Note**: Tests performance with maximum allowed message size

## Batched-queue primitive benchmark

`scripts/benchmark-batched-queue.ts` measures the underlying `InMemoryBatchedQueue`
(send via `enqueueBatch`, receive via `leaseBatch` and `completeBatch`) at batch
sizes from 1 to 1000. Run it with:

```bash
npx tsx scripts/benchmark-batched-queue.ts
```

It writes its results table to `docs/benchmarks/batched-queue-baseline.md`.
Throughput depends on the hardware, so compare runs from the same machine.

## Performance Characteristics

### In-memory queue
- **Strengths**: Very high throughput for all operations, low latency
- **Limitations**: No persistence, messages lost on restart
- **Use Case**: Testing, development, ephemeral workloads

### Durable stores
- Durable stores add a storage round trip per operation, so expect lower
  throughput than the in-memory queue. See `managed-nosql-smoke.md` for running
  against a DynamoDB-compatible endpoint.

## Capacity Planning

Based on benchmark results, calculate capacity for your workload:

1. **Peak throughput**: Use batch send results for bulk ingestion
2. **Sustained throughput**: Use single message send for typical load
3. **Consumer scaling**: Linear scaling up to message rate / consumer throughput
4. **Message size impact**: Throughput decreases with message size

## Optimization Tips

1. **Use batch operations** when sending multiple messages
2. **Receive multiple messages** per call (max_messages=10)
3. **Parallel consumers** for high-throughput scenarios
4. **Visibility timeout** should match processing time to minimize redelivery
5. **Connection pooling** for high-concurrency HTTP clients

## Known Bottlenecks

1. **Sequential operations**: Single-threaded operations limit throughput
2. **Synchronous I/O**: HTTP round-trips add latency
3. **Memory allocation**: Large payloads increase GC pressure
4. **Storage round trips**: durable stores add latency to every operation

## Monitoring in Production

Key metrics to watch:
- `dc_queue_messages_sent_total` - Message ingestion rate
- `dc_queue_messages_received_total` - Message consumption rate
- `dc_queue_depth` - Queue backlog
- API latency percentiles (p50, p95, p99)

See `/metrics` endpoint for Prometheus metrics.
