# Event-Catalog Binding

**Status:** Stable
**Audience:** event-catalog operators wiring `DurableTransport` to
message-queue; any other consumer that probes message-queue's health
and posts events through `/api/v1/queues/{name}`.

> **Note:** Earlier revisions of this doc described a cluster-mode
> response shape for `/health` and `/ready` (a `cluster` object with
> node, leader and quorum fields, plus 503 not-ready paths). That shape
> was never shipped and the cluster facade has been removed. This doc
> describes the contract the service implements today.

## Purpose

This document is the consumer-facing contract for talking to a
running message-queue instance. The probe and URL conventions below
are covered by `test/integration/health-ready-contract.test.ts`, so
if you pin to them you can rely on them surviving routine
message-queue releases.

## `MESSAGE_QUEUE_URL` convention

`MESSAGE_QUEUE_URL` is the **bare origin** of the message-queue
service — no path, no trailing slash.

- Single-node dev: `http://localhost:3000`
- Compose: `http://message-queue:3000`
- Kubernetes service: `http://message-queue.default.svc.cluster.local:3000`

The `/api/v1` prefix is **not** part of `MESSAGE_QUEUE_URL`. It lives
in the consumer's route paths instead. Consumer code composes URLs
like this:

```ts
const queueOps = `${MESSAGE_QUEUE_URL}/api/v1/queues/${queueName}`;
const health   = `${MESSAGE_QUEUE_URL}/health`;
const ready    = `${MESSAGE_QUEUE_URL}/ready`;
```

This split keeps operators out of versioning churn. When a future
`/api/v2` ships, consumers bump their pinned dep and the
in-consumer path constant changes; deployments don't have to update
`MESSAGE_QUEUE_URL` everywhere.

## Probe contract — `GET /health`

Used by event-catalog (and other consumers) to decide whether
message-queue is reachable and serving traffic.

```json
{ "status": "healthy" }
```

- **Status code:** `200 OK`.
- **Body:** exactly `{"status":"healthy"}`. No `cluster` field is
  present; consumers MUST NOT require any other field.

## Probe contract — `GET /ready`

Used by orchestrators / load balancers to decide whether traffic can
be routed to this instance.

```json
{ "status": "ready" }
```

- **Status code:** `200 OK`.
- **Body:** exactly `{"status":"ready"}`. The single-node service
  does not currently emit a `503 not_ready` from this endpoint;
  consumers SHOULD still tolerate `503` defensively (with retry +
  backoff) since future ownership schemes may reintroduce it.

## Queue operations consumed by `DurableTransport`

The probe contract above gates traffic; the actual durable transport
work happens against:

- `POST   ${MESSAGE_QUEUE_URL}/api/v1/queues` — create a queue.
- `PUT    ${MESSAGE_QUEUE_URL}/api/v1/queues/{name}` — idempotent
  create/update (safe to re-call with the same body).
- `POST   ${MESSAGE_QUEUE_URL}/api/v1/queues/{name}/messages` — enqueue
  one envelope.
- `GET    ${MESSAGE_QUEUE_URL}/api/v1/queues/{name}/messages` — receive
  up to `maxMessages` (default 10) with lease.
- `DELETE ${MESSAGE_QUEUE_URL}/api/v1/queues/{name}/messages/{receipt}`
  — ack a leased message.

See `docs/spec/api-spec.md` for the full operation list and SQS-style
request / response shapes. Schema validation behavior (when
`SCHEMA_VALIDATION_ENABLED=true`) is documented separately in
`docs/spec/`.

## Stability guarantees

The shapes documented in this file are pinned by
`test/integration/health-ready-contract.test.ts`. Specifically:

- Status codes for `/health` and `/ready` will not change without a
  major-version bump.
- The `status` field in the success-path bodies will not be renamed
  or removed without a major-version bump.
- New optional fields MAY be added; consumers MUST tolerate unknown
  keys (no strict-shape decoding). In particular, future ownership
  schemes may reintroduce a `cluster` field — consumers reading this
  doc against today's single-node service MUST treat the absence of
  `cluster` as expected, not an error.

If you find a divergence between this document and the live service,
file an issue against message-queue — the test should have caught it.
