import { rmSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const repository = fileURLToPath(new URL('../', import.meta.url));
// tsc overwrites current outputs but does not remove outputs of deleted sources.
// Never publish retired modules through a long-lived checkout's dist directory.
rmSync(join(repository, 'dist'), { recursive: true, force: true });
execFileSync(process.execPath, [join(repository, 'node_modules/typescript/bin/tsc')], {
  cwd: repository,
  stdio: 'inherit',
});
