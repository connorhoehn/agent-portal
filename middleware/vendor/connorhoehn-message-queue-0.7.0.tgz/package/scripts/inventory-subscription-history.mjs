import { HttpMessageQueue } from "../dist/client/index.cjs";

// Read-only, bounded, body-free inventory. No import, replay or reset operations.
const [queue, maxPagesText = "1000"] = process.argv.slice(2);
const maxPages = Number(maxPagesText);
if (
  !queue ||
  !process.env.MESSAGE_QUEUE_URL ||
  !Number.isSafeInteger(maxPages) ||
  maxPages < 1 ||
  maxPages > 10000
) {
  throw new Error(
    "Usage: MESSAGE_QUEUE_URL=<origin> node scripts/inventory-subscription-history.mjs <queue> [maxPages:1..10000]",
  );
}
const client = new HttpMessageQueue({
  baseUrl: process.env.MESSAGE_QUEUE_URL,
  serviceId: process.env.MQ_SERVICE_AUTH_ID,
  secret: process.env.MQ_SERVICE_AUTH_SECRET,
  requestHeaders: () =>
    process.env.MQ_API_KEY ? { "x-api-key": process.env.MQ_API_KEY } : {},
});
const summary = {
  queue,
  queueGeneration: undefined,
  throughSequence: undefined,
  cursor: 0,
  pages: 0,
  retained: 0,
  expired: 0,
  missingEligibility: 0,
  pending: true,
};
for (; summary.pages < maxPages && summary.pending; summary.pages++) {
  const page = await client.inventorySubscriptionHistory(queue, {
    queueGeneration: summary.queueGeneration,
    throughSequence: summary.throughSequence,
    cursor: summary.cursor,
  });
  Object.assign(summary, {
    queueGeneration: page.queueGeneration,
    throughSequence: page.throughSequence,
    cursor: page.cursor,
    pending: page.pending,
  });
  summary.retained += page.retained;
  summary.expired += page.expired;
  summary.missingEligibility += page.missingEligibilitySequences.length;
}
console.log(JSON.stringify(summary, null, 2));
// Incomplete/incompatible history must not look like a successful migration check.
if (summary.pending || summary.missingEligibility) process.exitCode = 2;
