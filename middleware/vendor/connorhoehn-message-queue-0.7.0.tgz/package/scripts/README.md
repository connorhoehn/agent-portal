# scripts/

Operational scripts for the message-queue repo. Each is invokable from
the repo root.

## `audit-standalone.sh`

Proves the package installs and tests cleanly from a clean slate (no
node_modules, no sibling-repo rsync). Mirrors what a fresh-clone CI run
or a downstream consumer would experience.

```bash
npm run audit:standalone
# or
bash scripts/audit-standalone.sh
```

Skips DDB-gated suites (no `MQ_DDB_INTEGRATION=1`), so it runs without
any external services.

## `test-ddb-integration.sh`

Boots `docker-compose.smoke.yml` (managed-nosql-store v0.12.0 on
`:8000`, drop-in DDB-wire backend), runs the six gated integration
suites against it, then tears the container down. Exits non-zero on
the first failure (compose-up, health-wait timeout, or jest failure);
teardown runs unconditionally via an `EXIT` trap.

```bash
bash scripts/test-ddb-integration.sh
```

### Suites covered

- `test/integration/ddb-store.test.ts`
- `test/integration/ddb-lease-store.test.ts`
- `test/integration/ddb-dlq-store.test.ts`
- `test/integration/ddb-queue-metadata-store.test.ts`
- `test/integration/ddb-consumer-offset-store.test.ts`
- `test/integration/managed-nosql-smoke.test.ts`

The five `ddb-*-store` suites are gated on `MQ_DDB_INTEGRATION=1`;
`managed-nosql-smoke` is gated on `MQ_MNS_SMOKE=true`. Without those
gates a normal `npm test` skips all of them — running the script is
how you opt in.

### Tunable env vars

- `MQ_SMOKE_HEALTH_TIMEOUT_S` (default `60`) — seconds to wait for the
  managed-nosql-store container's healthcheck to flip to `healthy`
  before failing the run.
- `COMPOSE_PROJECT_NAME` (default `mq-ddb-smoke`) — compose project
  name. Override when running multiple smoke harnesses in parallel.

### Prerequisites

- Docker + Docker Compose v2 on the host.
- `docker login ghcr.io` access. The compose file pins
  `ghcr.io/connorhoehn/managed-nosql-store:v0.12.0`, which is in a
  private registry. Pull access is required.
- `node_modules` installed (`npm ci`).

### Idempotency

The script pre-cleans any leftover container/volume from a prior run
before booting, and tears down on exit. Reruns do not accumulate state.

## `benchmark-batched-queue.ts`

Standalone throughput benchmark for the `BatchedQueue` primitive.
Run via `npx tsx scripts/benchmark-batched-queue.ts`.
