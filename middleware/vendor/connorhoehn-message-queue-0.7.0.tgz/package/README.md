# @connorhoehn/message-queue

A durable message queue with SQS-style semantics, built on `distributed-core`.
It supports standard and FIFO queues, visibility timeouts, dead-letter queues,
delay queues, consumer groups and durable subscriptions. You can use it as a
library, run it as an HTTP and WebSocket service, or ship it as a container
image. Storage is in memory by default, or a DynamoDB-compatible table for
durability.

## What's in the repo

- `src/` - the service. `api/` (HTTP routes, metrics, service auth), `server/` (Express app and entry point), `services/` (queues, consumer groups, webhooks, WebSocket), `storage/` (in-memory and DynamoDB-backed stores), `runtime/` (storage profile checks), `cli/` (command-line tool), `client/` (HTTP client), `admin/` (React admin UI).
- `test/` - unit, integration, property, stress, chaos and benchmark tests.
- `docs/` - API spec, architecture notes, runbooks, Grafana dashboard and Prometheus alerts.
- `scripts/` - build script, benchmark, migration and inventory tools, test harnesses.
- `helm/` - Helm chart for Kubernetes.
- Root files: `Dockerfile`, `docker-compose.yml` (service), `docker-compose.smoke.yml` (test backends), `Tiltfile` (local Kubernetes loop), and `coverage/` (generated coverage report).

## Getting started

Requires Node 20 or later. Two dependencies (`distributed-core` and
`@connorhoehn/service-runtime`) come from GitHub, so your SSH key needs read
access to the `connorhoehn` repositories.

**Use it as a dependency**

```bash
# From git (the package builds itself on install)
npm install github:connorhoehn/message-queue#<tag-or-commit>

# Or from a packed tarball: run `npm pack` here, then in the consumer
npm install ./connorhoehn-message-queue-*.tgz
```

The package root exports `QueueService` and its types. The `/client` entry point
exports `HttpMessageQueue`, a client for a running service (it works from both
ESM and CommonJS). The `/types` entry point has types only. A `message-queue`
command-line tool is installed as a bin.

**Run the service locally**

```bash
npm install
npm run dev                  # watch mode on http://localhost:3000
npm run build && npm start   # compiled build
```

Out of the box the service stores messages in memory, needs no authentication
outside production, and tries to reach an event-catalog schema service. Set
`SCHEMA_VALIDATION_ENABLED=false` to skip that. Try it:

```bash
curl -X POST localhost:3000/api/v1/queues -H 'Content-Type: application/json' \
  -d '{"queue_name": "demo", "configuration": {}}'
curl -X POST localhost:3000/api/v1/queues/demo/messages -H 'Content-Type: application/json' \
  -d '{"message_body": "hello"}'
curl localhost:3000/api/v1/queues/demo/messages
```

Settings that matter most (`PORT`, default 3000, sets the listen port):

- `MESSAGE_QUEUE_STORE`: `memory` (default), `ddb` or `ddb-v2`. `ddb` uses `MESSAGE_QUEUE_TABLE`; `ddb-v2` uses `MESSAGE_QUEUE_DELIVERY_TABLE`. Provision the table first (string keys `pk` and `sk`). `DYNAMODB_ENDPOINT` points at a local DynamoDB-compatible service.
- `MESSAGE_QUEUE_PROFILE` and `MESSAGE_QUEUE_REPLICAS` declare how many processes share durable storage. Production startup refuses a profile the selected store cannot support.
- `INSECURE_DEV_MODE=true` (ignored when `NODE_ENV=production`) is the one switch that opens local-development shortcuts: no service-auth secret needed, `CORS_ORIGINS` defaults to `*`, queue ACLs default off. Without it the server answers 503 until the secret is set, CORS allows no origin, ACLs are on and `HOST` defaults to `127.0.0.1` (the image sets `0.0.0.0`). `npm run dev` and `docker-compose.yml` set it. `/health` adds `insecureDevMode: true` while it is on.
- `MQ_SERVICE_AUTH_SECRET` and `MQ_SERVICE_AUTH_ALLOWED_SERVICES`: required unless `INSECURE_DEV_MODE=true`. Every route except `/health` and `/ready` then needs a signed `X-Service-Auth` header.
- `REDIS_URL` (optional) shares WebSocket fan-out between processes.
- `AUTH_ENABLED=true` or `MQ_ADMIN_TOKEN` turns on per-queue access lists (token in `X-API-Key` or `Authorization: Bearer`). A queue with no access list is then closed, `/api/v1/admin/acls` needs `MQ_ADMIN_TOKEN`, and the ACL routes report counts, never tokens. Queue create/put, quota, audit and schema-read routes also need `MQ_ADMIN_TOKEN`; `GET /queues` lists only the caller's queues; consumer groups are authorised against the queue they were first created or joined under. Set `EVENT_CATALOG_AUTH_TOKEN` so the schema lookup can read from an authenticated event-catalog. The Helm chart turns this on, reads both secrets from a Kubernetes Secret (`auth.existingSecret`, default `<release>-message-queue-auth`) and defaults `auth.allowedServices` to the known internal callers (`event-catalog`, `orgiq-middleware`, `platform-api`, `realtime-examples`) and refuses to render only if you empty it.

The admin UI is in `src/admin` (`npm run admin:install`, then `npm run admin:dev` on :5179); the container image serves a built copy at `/admin`.

**Container image**

```bash
docker build --ssh default -t message-queue .   # the build clones the GitHub dependencies over SSH
docker compose up --build                       # service on http://localhost:3000
```

`GET /health` reports liveness and `GET /ready` reports readiness. The Helm
chart in `helm/message-queue` deploys it to Kubernetes (`npm run test:helm`
lints it); `tilt up` builds the image and applies the chart locally.

**Build, test, lint**

```bash
npm run build           # compile to dist/
npm test                # Jest; build first, the client tests use built output
npm run lint            # also `lint:fix`, `format` and `format:check`
npm run benchmark       # throughput benchmark
```

CI: `.github/workflows/ci.yml` runs typecheck and tests on push; it has not run yet (no GitHub access from the machine that wrote it).

Integration suites that need a DynamoDB-compatible service are skipped unless
you opt in. `bash scripts/test-ddb-integration.sh` starts one in a container and
runs them.

## Related repositories

- `connorhoehn/distributed-core` - queue primitives, retry and tracing helpers, transport (dependency).
- `connorhoehn/service-runtime` - logging, service-to-service request signing and graceful shutdown (dependency).
- `connorhoehn/event-catalog` - sends durable events here through `MESSAGE_QUEUE_URL`, and owns the event schemas (consumer).
- `connorhoehn/aws-agentcore` - builds the container image from this repo for its local and deployed stacks (consumer).

## Documentation

- [API specification](docs/spec/api-spec.md) - queues, messages, errors and limits.
- [Multi-node architecture](docs/spec/multi-node-architecture.md) - analysis of options for coordinating several nodes.
- [Event-catalog binding](docs/event-catalog-binding.md) - URL convention and health and readiness contract for consumers.
- [Observability](docs/observability.md) - metrics, labels and alert examples; see also `docs/grafana` and `docs/prometheus`.
- [Two-consumer fan-out](docs/two-consumer-fan-out-demo.md) - one queue read independently by two consumer groups.
- [Benchmarks](docs/benchmarks/README.md), [throughput runbook](docs/benchmarks/throughput-runbook.md) and [managed-nosql-store smoke test](docs/benchmarks/managed-nosql-smoke.md).
- [Scripts](scripts/README.md) and the [changelog](CHANGELOG.md).

## License

MIT
